#!/usr/bin/env python3
"""
Simple integration test for Claude 4 Sonnet Gomoku AI
"""

import sys
import os

# Add the game engine path
sys.path.insert(0, '/data/CATArena/GamesEnv/games/gomoku')
sys.path.insert(0, '/data/CATArena/AI_Candidate/gomoku/round1/minimal_claude_4_sonnet/gomoku_1')

try:
    from ai_player import Claude4SonnetGomokuAI
    from game_engine import GomokuEngine
    print("✅ Successfully imported AI and game engine")
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)

def test_ai_integration():
    """Test AI integration with game engine"""
    print("\n🧪 Testing AI integration with game engine...")
    
    try:
        # Initialize AI
        ai = Claude4SonnetGomokuAI()
        print(f"✅ AI initialized: {ai.name}")
        
        # Test AI info
        info = ai.get_info()
        print(f"✅ AI info: {info['ai_id']}")
        
        # Create a simple game state
        board = [[0 for _ in range(15)] for _ in range(15)]
        game_state = {
            'board': board,
            'current_player': 'black',
            'my_color': 'black',
            'move_history': [],
            'game_id': 'test_game',
            'round_number': 1
        }
        
        # Test first move
        move = ai.make_move(game_state)
        print(f"✅ First move: {move}")
        
        # Validate move
        if not isinstance(move, list) or len(move) != 2:
            raise ValueError("Invalid move format")
        
        x, y = move
        if not (0 <= x < 15 and 0 <= y < 15):
            raise ValueError("Move out of bounds")
        
        if board[x][y] != 0:
            raise ValueError("Move on occupied position")
        
        # Test second move
        board[x][y] = 1  # Place first move
        board[7][8] = 2  # Opponent move
        
        game_state['board'] = board
        game_state['round_number'] = 3
        game_state['move_history'] = [[x, y], [7, 8]]
        
        move2 = ai.make_move(game_state)
        print(f"✅ Second move: {move2}")
        
        # Validate second move
        x2, y2 = move2
        if board[x2][y2] != 0:
            raise ValueError("Second move on occupied position")
        
        print("✅ All integration tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Integration test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Main test function"""
    print("Claude 4 Sonnet Gomoku AI Integration Test")
    print("=" * 50)
    
    success = test_ai_integration()
    
    if success:
        print("\n🎉 Integration test completed successfully!")
        print("The AI is ready for tournament play.")
    else:
        print("\n❌ Integration test failed!")
        print("Please check the AI implementation.")
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())