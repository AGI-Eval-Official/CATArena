# Claude 4 Sonnet Gomoku Master AI

An advanced Gomoku AI implementation using minimax with alpha-beta pruning, pattern recognition, and threat detection for competitive play.

## Overview

This AI is designed to compete at an expert level in Gomoku tournaments. It combines multiple strategic approaches to make intelligent moves:

- **Immediate Threat Detection**: Identifies winning moves and critical blocks
- **Pattern Recognition**: Evaluates board positions based on stone patterns
- **Minimax Search**: Uses minimax algorithm with alpha-beta pruning for strategic planning
- **Adaptive Depth**: Adjusts search depth based on game complexity
- **Move Ordering**: Optimizes search efficiency through intelligent move ordering

## Key Features

### 1. Strategic Decision Making
- Prioritizes winning moves when available
- Blocks opponent winning threats immediately
- Uses minimax search for complex position evaluation
- Considers both offensive and defensive patterns

### 2. Pattern Recognition
The AI recognizes and evaluates various stone patterns:
- **Live Four**: Four stones with both ends open (highest priority)
- **Dead Four**: Four stones with one end blocked
- **Live Three**: Three stones with both ends open
- **Dead Three**: Three stones with one end blocked
- **Live Two**: Two stones with both ends open
- **Dead Two**: Two stones with one end blocked

### 3. Performance Optimization
- **Alpha-Beta Pruning**: Reduces search space significantly
- **Move Ordering**: Evaluates promising moves first
- **Adaptive Search Depth**: Balances depth with time constraints
- **Candidate Move Selection**: Focuses search on relevant positions

### 4. Robust Error Handling
- Validates all inputs and game states
- Provides fallback moves in error conditions
- Handles edge cases gracefully
- Ensures moves are always legal

## Technical Specifications

- **Language**: Python 3.7+
- **Dependencies**: None (uses only standard library)
- **Board Size**: 15x15 (standard Gomoku)
- **Search Depth**: Adaptive (2-6 levels)
- **Timeout**: 15 seconds per move
- **Memory Usage**: Minimal (no persistent storage)

## Algorithm Details

### Minimax with Alpha-Beta Pruning
The core decision-making algorithm uses minimax search with alpha-beta pruning:

1. **Move Generation**: Identifies candidate moves around existing stones
2. **Move Ordering**: Sorts moves by heuristic evaluation for better pruning
3. **Recursive Search**: Explores game tree to specified depth
4. **Position Evaluation**: Scores positions based on pattern recognition
5. **Best Move Selection**: Returns the move with highest evaluation

### Pattern Evaluation
Each position is evaluated based on:
- Stone patterns in all four directions (horizontal, vertical, diagonal)
- Pattern strength (live vs. dead patterns)
- Center control bonus
- Threat creation and blocking potential

### Adaptive Features
- **Dynamic Depth**: Adjusts search depth based on position complexity
- **Candidate Pruning**: Focuses on moves near existing stones
- **Time Management**: Balances search depth with time constraints

## Usage

### Basic Usage
```python
from ai_player import Claude4SonnetGomokuAI

# Initialize the AI
ai = Claude4SonnetGomokuAI()

# Get AI information
info = ai.get_info()
print(f"AI: {info['name']} v{info['version']}")

# Make a move
game_state = {
    'board': board,  # 15x15 board (0=empty, 1=black, 2=white)
    'current_player': 'black',
    'my_color': 'black',
    'move_history': [],
    'game_id': 'game_1',
    'round_number': 1
}

move = ai.make_move(game_state)
print(f"AI chooses position: {move}")
```

### Testing
Run the test suite to verify functionality:
```bash
python test_ai.py
```

## Configuration

The AI behavior can be customized through the configuration file `ai_config.yaml`:

- **Search Parameters**: Adjust search depth and candidate radius
- **Pattern Weights**: Modify evaluation weights for different patterns
- **Performance Settings**: Configure timeout and optimization flags

## Performance Characteristics

- **Strength**: Expert level (designed for competitive play)
- **Speed**: Typically decides within 1-8 seconds
- **Memory**: Low memory footprint
- **Scalability**: Handles complex positions efficiently

## Development Notes

This AI was developed with the following principles:
1. **Correctness**: Always produces legal moves
2. **Performance**: Optimized for tournament play
3. **Robustness**: Handles edge cases and errors gracefully
4. **Maintainability**: Clean, well-documented code structure

## Tournament Readiness

The AI is designed for competitive tournament play with:
- Strict adherence to game rules
- Reliable performance under time pressure
- Consistent strategic play
- Comprehensive error handling

## Future Enhancements

Potential improvements for future versions:
- Opening book integration
- Endgame tablebase
- Machine learning pattern recognition
- Advanced threat detection algorithms
- Parallel search implementation

---

**Author**: Claude 4 Sonnet  
**Version**: 1.0  
**License**: MIT  
**Created**: 2025-11-20