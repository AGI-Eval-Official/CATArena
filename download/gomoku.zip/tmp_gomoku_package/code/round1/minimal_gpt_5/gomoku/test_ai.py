#!/usr/bin/env python3
"""
Basic tests for minimal_gpt_5_AI gomoku player
"""
import os, sys, time, yaml
from typing import Any, Dict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ai_player import minimal_gpt_5_AI


def run_basic_tests() -> bool:
    ai = minimal_gpt_5_AI()

    info = ai.get_info()
    assert isinstance(info, dict)
    assert info["ai_id"] == "minimal_gpt_5_AI_gomoku"
    assert info["name"] == "minimal_gpt_5_AI"

    # Empty board -> center
    board = [[0 for _ in range(15)] for _ in range(15)]
    game_state = {
        "board": board,
        "current_player": "black",
        "my_color": "black",
        "round_number": 1,
    }
    mv = ai.make_move(game_state)
    assert mv == [7, 7], f"Expected center [7,7], got {mv}"

    # Immediate win detection
    board = [[0 for _ in range(15)] for _ in range(15)]
    for i in range(4):
        board[5][5 + i] = 1
    game_state = {"board": board, "current_player": "black", "my_color": "black"}
    mv = ai.make_move(game_state)
    assert mv in ([5, 4], [5, 9], [5, 5], [5, 8]), f"Should complete five, got {mv}"

    # Immediate block detection
    board = [[0 for _ in range(15)] for _ in range(15)]
    for i in range(4):
        board[10][2 + i] = 2
    game_state = {"board": board, "current_player": "black", "my_color": "black"}
    mv = ai.make_move(game_state)
    assert mv in ([10, 1], [10, 6]), f"Should block opponent four, got {mv}"

    # Performance sanity
    board = [[0 for _ in range(15)] for _ in range(15)]
    board[7][7] = 1
    board[7][8] = 2
    board[8][7] = 1
    game_state = {"board": board, "current_player": "black", "my_color": "black"}
    t0 = time.time()
    mv = ai.make_move(game_state)
    assert isinstance(mv, list) and len(mv) == 2
    assert 0 <= mv[0] < 15 and 0 <= mv[1] < 15
    assert board[mv[0]][mv[1]] == 0
    assert time.time() - t0 <= ai.timeout

    print("All minimal_gpt_5_AI basic tests passed.")
    return True


def validate_config() -> bool:
    cfg_path = os.path.join(os.path.dirname(__file__), "ai_config.yaml")
    assert os.path.exists(cfg_path)
    with open(cfg_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    for key in [
        "ai_id",
        "ai_name",
        "version",
        "description",
        "category",
        "capabilities",
        "author",
        "created_at",
        "timeout",
        "difficulty",
    ]:
        assert key in cfg, f"Missing required config field: {key}"
    assert cfg["ai_id"] == "minimal_gpt_5_AI_gomoku"
    assert isinstance(cfg["capabilities"], list)
    assert isinstance(cfg["timeout"], int) and cfg["timeout"] > 0
    print("Config validation passed.")
    return True


if __name__ == "__main__":
    ok = run_basic_tests() and validate_config()
    sys.exit(0 if ok else 1)
