"""
minimal_gpt_5 Gomoku AI

Strategic Gomoku AI combining:
- Immediate win/block detection
- Pattern-based evaluation (live/dead lines)
- Candidate move generation near stones
- Shallow minimax with alpha-beta pruning
"""

import random
from typing import List, Dict, Tuple, Optional, Any


class minimal_gpt_5_AI:
    """Competitive Gomoku AI with pattern evaluation and shallow search."""

    def __init__(self):
        # Required identity fields
        self.ai_id = "minimal_gpt_5_AI_gomoku"
        self.name = "minimal_gpt_5_AI"
        self.version = "1.0.0"
        self.board_size = 15
        self.description = (
            "Pattern-evaluation + alpha-beta minimax Gomoku AI with strong threat detection"
        )
        self.author = "minimal_gpt_5"
        self.difficulty = "hard"
        self.timeout = 10

        # Search and heuristic configuration
        self.max_search_depth = 2  # full plies
        self.search_width = 12     # top-N ordered candidates per node
        self.candidate_radius = 3

        # Pattern weights (heuristic scoring)
        self.pattern_weights = {
            'win': 100000,
            'live_four': 50000,
            'dead_four': 5000,
            'live_three': 6000,
            'dead_three': 600,
            'live_two': 600,
            'dead_two': 60,
            'center_bonus': 40,
        }

    def get_info(self) -> Dict[str, Any]:
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "difficulty": self.difficulty,
            "timeout": self.timeout,
            "capabilities": [
                "position_evaluation",
                "threat_detection",
                "winning_move_detection",
                "blocking_strategy",
                "minimax",
                "alpha_beta_pruning",
                "pattern_recognition",
            ],
        }

    def make_move(self, game_state: Dict[str, Any]) -> List[int]:
        try:
            self._validate_game_state(game_state)
            board = game_state.get('board', [])
            my_color = game_state.get('my_color', 'black')
            current_player = game_state.get('current_player', 'black')

            if current_player != my_color:
                raise ValueError(f"Not my turn: current={current_player}, mine={my_color}")

            # First move: take center
            if self._is_first_move(board):
                c = self.board_size // 2
                return [c, c]

            my_value = 1 if my_color == "black" else 2
            opp_value = 2 if my_color == "black" else 1

            # Immediate win
            win = self._find_winning_move(board, my_value)
            if win:
                return win
            # Immediate block
            block = self._find_winning_move(board, opp_value)
            if block:
                return block

            # Tactical threats: prefer creating open fours or dual threes
            tactical = self._find_strong_tactical_move(board, my_value, opp_value)
            if tactical:
                return tactical

            # Shallow minimax on ordered candidates
            best = self._minimax_search(board, my_value, opp_value)
            self._validate_move(board, best)
            return best
        except Exception as e:
            print(f"AI decision error: {e}")
            return self._get_safe_random_move(game_state.get('board', []))

    # --- Core helpers ---

    def _validate_game_state(self, game_state: Dict[str, Any]) -> None:
        if not isinstance(game_state, dict):
            raise ValueError("Game state must be dict")
        if 'board' not in game_state:
            raise ValueError("Missing board in game_state")
        board = game_state['board']
        if not isinstance(board, list) or len(board) != self.board_size:
            raise ValueError(f"Invalid board size; expected {self.board_size}")
        for row in board:
            if not isinstance(row, list) or len(row) != self.board_size:
                raise ValueError(f"Invalid row size; expected {self.board_size}")

    def _is_first_move(self, board: List[List[int]]) -> bool:
        for r in board:
            for c in r:
                if c != 0:
                    return False
        return True

    def _find_winning_move(self, board: List[List[int]], player_value: int) -> Optional[List[int]]:
        for x, y in self._get_candidate_positions(board):
            if board[x][y] != 0:
                continue
            board[x][y] = player_value
            if self._check_win(board, x, y, player_value):
                board[x][y] = 0
                return [x, y]
            board[x][y] = 0
        return None

    def _check_win(self, board: List[List[int]], x: int, y: int, player_value: int) -> bool:
        dirs = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for dx, dy in dirs:
            cnt = 1
            nx, ny = x + dx, y + dy
            while 0 <= nx < self.board_size and 0 <= ny < self.board_size and board[nx][ny] == player_value:
                cnt += 1
                nx, ny = nx + dx, ny + dy
            nx, ny = x - dx, y - dy
            while 0 <= nx < self.board_size and 0 <= ny < self.board_size and board[nx][ny] == player_value:
                cnt += 1
                nx, ny = nx - dx, ny - dy
            if cnt >= 5:
                return True
        return False

    def _find_strong_tactical_move(self, board: List[List[int]], my_value: int, opp_value: int) -> Optional[List[int]]:
        candidates = self._get_candidate_positions(board)
        scored: List[Tuple[Tuple[int, int], float]] = []
        for x, y in candidates:
            if board[x][y] != 0:
                continue
            s = self._evaluate_position_heuristic(board, x, y, my_value, opp_value)
            scored.append(((x, y), s))
        if not scored:
            return None
        scored.sort(key=lambda t: t[1], reverse=True)
        top = scored[0][0]
        return [top[0], top[1]]

    def _minimax_search(self, board: List[List[int]], my_value: int, opp_value: int) -> List[int]:
        candidates = self._get_candidate_positions(board)
        if not candidates:
            return self._get_safe_random_move(board)
        ordered: List[Tuple[Tuple[int, int], float]] = []
        for x, y in candidates:
            if board[x][y] != 0:
                continue
            score = self._evaluate_position_heuristic(board, x, y, my_value, opp_value)
            ordered.append(((x, y), score))
        if not ordered:
            return self._get_safe_random_move(board)
        ordered.sort(key=lambda t: t[1], reverse=True)
        top_candidates = [pos for (pos, _s) in ordered[: self.search_width]]

        best_score = -float('inf')
        best_moves: List[Tuple[int, int]] = []
        alpha, beta = -float('inf'), float('inf')

        for x, y in top_candidates:
            board[x][y] = my_value
            score = self._minimax(
                board=board,
                depth=self.max_search_depth - 1,
                maximizing=False,
                current_player_value=opp_value,
                my_value=my_value,
                alpha=alpha,
                beta=beta,
                last_move=(x, y),
            )
            board[x][y] = 0
            if score > best_score:
                best_score = score
                best_moves = [(x, y)]
                alpha = max(alpha, best_score)
            elif score == best_score:
                best_moves.append((x, y))
            if beta <= alpha:
                break

        if not best_moves:
            return self._get_safe_random_move(board)
        m = random.choice(best_moves)
        return [m[0], m[1]]

    def _minimax(
        self,
        board: List[List[int]],
        depth: int,
        maximizing: bool,
        current_player_value: int,
        my_value: int,
        alpha: float,
        beta: float,
        last_move: Optional[Tuple[int, int]],
    ) -> float:
        # Terminal check: last move win
        if last_move is not None:
            lx, ly = last_move
            if self._check_win(board, lx, ly, current_player_value):
                return (self.pattern_weights['win'] + depth) if current_player_value == my_value else (-self.pattern_weights['win'] - depth)
        if depth == 0:
            return self._evaluate_board(board, my_value, 3 - my_value)

        # Generate ordered candidates
        cand = self._get_candidate_positions(board)
        if not cand:
            return self._evaluate_board(board, my_value, 3 - my_value)
        scored: List[Tuple[Tuple[int, int], float]] = []
        eval_perspective = my_value if maximizing else (3 - my_value)
        for x, y in cand:
            if board[x][y] != 0:
                continue
            s = self._evaluate_position_heuristic(board, x, y, eval_perspective, 3 - eval_perspective)
            scored.append(((x, y), s))
        if not scored:
            return self._evaluate_board(board, my_value, 3 - my_value)
        scored.sort(key=lambda t: t[1], reverse=maximizing)
        moves = [pos for (pos, _s) in scored[: self.search_width]]

        next_value = 3 - current_player_value
        if maximizing:
            val = -float('inf')
            for x, y in moves:
                board[x][y] = current_player_value
                val = max(val, self._minimax(board, depth - 1, False, next_value, my_value, alpha, beta, (x, y)))
                board[x][y] = 0
                alpha = max(alpha, val)
                if beta <= alpha:
                    break
            return val
        else:
            val = float('inf')
            for x, y in moves:
                board[x][y] = current_player_value
                val = min(val, self._minimax(board, depth - 1, True, next_value, my_value, alpha, beta, (x, y)))
                board[x][y] = 0
                beta = min(beta, val)
                if beta <= alpha:
                    break
            return val

    # --- Evaluation ---

    def _evaluate_board(self, board: List[List[int]], my_value: int, opp_value: int) -> float:
        my_score = self._calculate_player_score(board, my_value)
        opp_score = self._calculate_player_score(board, opp_value)
        return my_score - opp_score

    def _calculate_player_score(self, board: List[List[int]], player_value: int) -> float:
        score = 0.0
        center = self.board_size // 2
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == player_value:
                    # slight center bias
                    dist = abs(i - center) + abs(j - center)
                    score += max(0, self.pattern_weights['center_bonus'] - dist * 2)
                    # patterns in 4 dirs
                    for dx, dy in ((0, 1), (1, 0), (1, 1), (1, -1)):
                        score += self._evaluate_pattern(board, i, j, dx, dy, player_value)
        return score

    def _evaluate_pattern(self, board: List[List[int]], x: int, y: int, dx: int, dy: int, pv: int) -> float:
        cnt = 1
        blocked = 0
        nx, ny = x + dx, y + dy
        while 0 <= nx < self.board_size and 0 <= ny < self.board_size:
            if board[nx][ny] == pv:
                cnt += 1
                nx, ny = nx + dx, ny + dy
            elif board[nx][ny] == 0:
                break
            else:
                blocked += 1
                break
        if not (0 <= nx < self.board_size and 0 <= ny < self.board_size):
            blocked += 1
        nx, ny = x - dx, y - dy
        while 0 <= nx < self.board_size and 0 <= ny < self.board_size:
            if board[nx][ny] == pv:
                cnt += 1
                nx, ny = nx - dx, ny - dy
            elif board[nx][ny] == 0:
                break
            else:
                blocked += 1
                break
        if not (0 <= nx < self.board_size and 0 <= ny < self.board_size):
            blocked += 1
        if cnt >= 5:
            return self.pattern_weights['win']
        if cnt == 4:
            return self.pattern_weights['live_four'] if blocked == 0 else self.pattern_weights['dead_four']
        if cnt == 3:
            return self.pattern_weights['live_three'] if blocked == 0 else self.pattern_weights['dead_three']
        if cnt == 2:
            return self.pattern_weights['live_two'] if blocked == 0 else self.pattern_weights['dead_two']
        return 0.0

    def _evaluate_position_heuristic(self, board: List[List[int]], x: int, y: int, my_value: int, opp_value: int) -> float:
        if board[x][y] != 0:
            return -1e6
        score = 0.0
        # center bias
        c = self.board_size // 2
        dist = abs(x - c) + abs(y - c)
        score += max(0, 50 - dist * 3)
        # place my piece and evaluate local effect
        board[x][y] = my_value
        if self._would_create_four_or_strong_three(board, x, y, my_value):
            score += 12000
        # block opponent threats
        board[x][y] = opp_value
        if self._would_create_four_or_strong_three(board, x, y, opp_value):
            score += 9000
        board[x][y] = 0
        # neighborhood density
        for dx in range(-2, 3):
            for dy in range(-2, 3):
                nx, ny = x + dx, y + dy
                if (dx or dy) and 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                    if board[nx][ny] == my_value:
                        score += 10
                    elif board[nx][ny] == opp_value:
                        score += 6
        return score

    def _would_create_four_or_strong_three(self, board: List[List[int]], x: int, y: int, pv: int) -> bool:
        dirs = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for dx, dy in dirs:
            cnt = 1
            empties = 0
            nx, ny = x + dx, y + dy
            while 0 <= nx < self.board_size and 0 <= ny < self.board_size and (board[nx][ny] == pv or (board[nx][ny] == 0 and empties < 1)):
                if board[nx][ny] == pv:
                    cnt += 1
                else:
                    empties += 1
                nx, ny = nx + dx, ny + dy
            nx, ny = x - dx, y - dy
            while 0 <= nx < self.board_size and 0 <= ny < self.board_size and (board[nx][ny] == pv or (board[nx][ny] == 0 and empties < 1)):
                if board[nx][ny] == pv:
                    cnt += 1
                else:
                    empties += 1
                nx, ny = nx - dx, ny - dy
            if cnt >= 4 and empties <= 1:
                return True
        return False

    # --- Move generation & safety ---

    def _get_candidate_positions(self, board: List[List[int]]) -> List[Tuple[int, int]]:
        candidates = set()
        radius = self.candidate_radius
        pieces = sum(1 for row in board for v in row if v != 0)
        if pieces < 10:
            radius = max(radius, 4)
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] != 0:
                    for di in range(-radius, radius + 1):
                        for dj in range(-radius, radius + 1):
                            ni, nj = i + di, j + dj
                            if 0 <= ni < self.board_size and 0 <= nj < self.board_size and board[ni][nj] == 0:
                                candidates.add((ni, nj))
        if not candidates:
            for i in range(self.board_size):
                for j in range(self.board_size):
                    if board[i][j] == 0:
                        candidates.add((i, j))
        return list(candidates)

    def _validate_move(self, board: List[List[int]], move: List[int]) -> None:
        if not isinstance(move, list) or len(move) != 2:
            raise ValueError("Move must be a list of length 2")
        x, y = move
        if not (0 <= x < self.board_size and 0 <= y < self.board_size):
            raise ValueError(f"Move out of range: ({x}, {y})")
        if board[x][y] != 0:
            raise ValueError(f"Cell occupied: ({x}, {y})")

    def _get_safe_random_move(self, board: List[List[int]]) -> List[int]:
        empties: List[Tuple[int, int]] = []
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == 0:
                    empties.append((i, j))
        if not empties:
            c = self.board_size // 2
            return [c, c]
        c = self.board_size // 2
        empties.sort(key=lambda p: abs(p[0] - c) + abs(p[1] - c))
        e = empties[0]
        return [e[0], e[1]]


__all__ = ["minimal_gpt_5_AI"]
