import unittest
from ai_player import MinimalDeepSeekV3AI

class TestMinimalDeepSeekV3AI(unittest.TestCase):
    def setUp(self):
        self.ai = MinimalDeepSeekV3AI()
        self.board = [[0 for _ in range(15)] for _ in range(15)]
        
    def test_initial_move(self):
        game_state = {
            'board': self.board,
            'my_color': 1,
            'round_number': 1
        }
        move = self.ai.make_move(game_state)
        self.assertEqual(move, [7, 7])  # Should prioritize center
        
    def test_block_opponent(self):
        # Simulate opponent's potential winning move
        self.board[7][7] = 2
        self.board[7][8] = 2
        self.board[7][9] = 2
        self.board[7][10] = 2
        
        game_state = {
            'board': self.board,
            'my_color': 1,
            'round_number': 1
        }
        move = self.ai.make_move(game_state)
        self.assertEqual(move, [7, 11])  # Should block opponent
        
    def test_fallback_move(self):
        # Fill the board except for one spot
        for i in range(15):
            for j in range(15):
                self.board[i][j] = 1
        self.board[0][0] = 0
        
        game_state = {
            'board': self.board,
            'my_color': 1,
            'round_number': 1
        }
        move = self.ai.make_move(game_state)
        self.assertEqual(move, [0, 0])  # Should find the only empty spot

if __name__ == "__main__":
    unittest.main()