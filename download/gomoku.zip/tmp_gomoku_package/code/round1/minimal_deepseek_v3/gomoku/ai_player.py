class MinimalDeepSeekV3AI:
    def __init__(self):
        self.ai_id = "minimal_deepseek_v3_AI"
        self.name = "Minimal DeepSeek V3 AI"

    def make_move(self, game_state):
        board = game_state['board']
        my_color = game_state['my_color']
        
        # Implement a basic strategy: prioritize center and block opponent
        best_move = self._find_best_move(board, my_color)
        
        return best_move
    
    def _find_best_move(self, board, my_color):
        # Simple strategy: prioritize center and block opponent
        center = [7, 7]
        if board[center[0]][center[1]] == 0:
            return center
        
        # Find opponent's potential winning moves and block
        opponent_color = 1 if my_color == 2 else 2
        for i in range(15):
            for j in range(15):
                if board[i][j] == 0:
                    # Check if placing here blocks opponent
                    board[i][j] = opponent_color
                    if self._check_win(board, opponent_color):
                        board[i][j] = 0
                        return [i, j]
                    board[i][j] = 0
        
        # Default: find first empty spot
        for i in range(15):
            for j in range(15):
                if board[i][j] == 0:
                    return [i, j]
        
        return [0, 0]  # Fallback
    
    def _check_win(self, board, color):
        # Check horizontal, vertical, and diagonal for five in a row
        for i in range(15):
            for j in range(15):
                if board[i][j] == color:
                    # Horizontal
                    if j <= 10 and all(board[i][j + k] == color for k in range(5)):
                        return True
                    # Vertical
                    if i <= 10 and all(board[i + k][j] == color for k in range(5)):
                        return True
                    # Diagonal (top-left to bottom-right)
                    if i <= 10 and j <= 10 and all(board[i + k][j + k] == color for k in range(5)):
                        return True
                    # Diagonal (bottom-left to top-right)
                    if i >= 4 and j <= 10 and all(board[i - k][j + k] == color for k in range(5)):
                        return True
        return False