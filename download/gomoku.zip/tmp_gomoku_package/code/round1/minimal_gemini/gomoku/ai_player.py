
import random

class minimal_gemini_AI:
    def __init__(self):
        self.ai_id = "minimal_gemini_gomoku_2"
        self.name = "minimal_gemini_AI"
        self.version = "1.0"
        self.author = "minimal_gemini"
        self.board_size = 15

    def get_info(self):
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "author": self.author,
        }

    def make_move(self, game_state):
        board = game_state['board']
        my_color_str = game_state['my_color']
        my_color = 1 if my_color_str == 'black' else 2
        
        empty_cells = []
        for r in range(self.board_size):
            for c in range(self.board_size):
                if board[r][c] == 0:
                    empty_cells.append((r, c))
        
        if not empty_cells:
            return None

        # Prioritize center if available
        center = self.board_size // 2
        if (center, center) in empty_cells:
            return [center, center]

        # Simple heuristic: find a move near existing pieces
        for r_start, c_start in empty_cells:
            for dr in range(-1, 2):
                for dc in range(-1, 2):
                    if dr == 0 and dc == 0:
                        continue
                    
                    r, c = r_start + dr, c_start + dc
                    if 0 <= r < self.board_size and 0 <= c < self.board_size and board[r][c] != 0:
                        return [r_start, c_start]

        return list(random.choice(empty_cells))
