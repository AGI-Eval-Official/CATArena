
import unittest
import os
import sys

# Add the parent directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from ai_player import minimal_gemini_AI

class TestMinimalGeminiAI(unittest.TestCase):

    def setUp(self):
        self.ai = minimal_gemini_AI()

    def test_ai_initialization(self):
        self.assertEqual(self.ai.ai_id, "minimal_gemini_gomoku_2")
        self.assertEqual(self.ai.name, "minimal_gemini_AI")
        self.assertEqual(self.ai.version, "1.0")
        self.assertEqual(self.ai.author, "minimal_gemini")
        self.assertEqual(self.ai.board_size, 15)

    def test_get_info(self):
        info = self.ai.get_info()
        self.assertEqual(info["ai_id"], "minimal_gemini_gomoku_2")
        self.assertEqual(info["name"], "minimal_gemini_AI")
        self.assertEqual(info["version"], "1.0")
        self.assertEqual(info["author"], "minimal_gemini")

    def test_make_move_empty_board(self):
        board = [[0] * 15 for _ in range(15)]
        game_state = {'board': board, 'my_color': 'black'}
        move = self.ai.make_move(game_state)
        self.assertEqual(move, [7, 7])

    def test_make_move_center_taken(self):
        board = [[0] * 15 for _ in range(15)]
        board[7][7] = 1
        game_state = {'board': board, 'my_color': 'white'}
        move = self.ai.make_move(game_state)
        self.assertNotEqual(move, [7, 7])
        self.assertTrue(0 <= move[0] < 15)
        self.assertTrue(0 <= move[1] < 15)

    def test_make_move_near_piece(self):
        board = [[0] * 15 for _ in range(15)]
        board[7][7] = 2  # Opponent takes center
        board[5][5] = 1
        game_state = {'board': board, 'my_color': 'white'}
        move = self.ai.make_move(game_state)
        
        # The move should be adjacent to (5, 5)
        self.assertTrue(abs(move[0] - 5) <= 1 and abs(move[1] - 5) <= 1)
        self.assertNotEqual(move, [5,5])


if __name__ == '__main__':
    unittest.main()
