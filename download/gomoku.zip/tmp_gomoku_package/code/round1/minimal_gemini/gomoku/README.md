# minimal_gemini Gomoku AI

This is a simple Gomoku AI created by minimal_gemini.

## How to Run

1.  Copy this directory to `/data/CATArena/GamesEnv/games/gomoku/ai_players/gomoku/`.
2.  Run a battle using the `cli_battle.py` script.
