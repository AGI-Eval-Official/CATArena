"""
Claude Gomoku Master AI
======================

Advanced Gomoku AI implementation using minimax with alpha-beta pruning,
pattern recognition, and threat detection for competitive play.
"""

import random
import math
from typing import List, Dict, Tuple, Optional, Any
from functools import lru_cache


class GomokuAITemplate:
    """
    Base template for Gomoku AI players.
    """
    
    def __init__(self):
        """Initialize the AI player."""
        self.ai_id = ""
        self.name = ""
        self.version = "1.0"
        self.board_size = 15
        self.description = ""
        self.author = ""
        self.difficulty = "medium"
        self.timeout = 10
    
    def get_info(self) -> Dict[str, Any]:
        """Get AI information."""
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "difficulty": self.difficulty,
            "timeout": self.timeout,
            "capabilities": []
        }
    
    def make_move(self, game_state: Dict[str, Any]) -> List[int]:
        """Make a move based on the game state."""
        raise NotImplementedError("Subclasses must implement make_move method")


class MinimalClaudeAI(GomokuAITemplate):
    """
    Advanced Gomoku AI using minimax with alpha-beta pruning and pattern recognition.
    
    This AI implements:
    - Immediate threat detection (wins and blocks)
    - Pattern-based evaluation function
    - Minimax search with alpha-beta pruning
    - Efficient candidate move selection
    - Adaptive search depth
    """
    
    def __init__(self):
        """Initialize the AI player with configuration."""
        super().__init__()
        # 【Required Field】AI unique identifier
        self.ai_id = "minimal_claude_3_7_sonnet_AI"
        
        # 【Required Field】AI display name
        self.name = "Claude Gomoku Master"
        
        # 【Required Field】AI version
        self.version = "1.0"
        
        # 【Required Field】Board size
        self.board_size = 15
        
        # 【Optional Field】AI description
        self.description = "Advanced Gomoku AI using minimax with alpha-beta pruning and pattern recognition"
        
        # 【Optional Field】AI author
        self.author = "Claude 3.7 Sonnet"
        
        # 【Optional Field】AI difficulty
        self.difficulty = "expert"
        
        # 【Optional Field】AI timeout
        self.timeout = 15
        
        # Internal state
        self.move_count = 0
        self.max_search_depth = 4
        self.candidate_radius = 3
        
        # Pattern weights for evaluation
        self.pattern_weights = {
            'five': 100000,
            'open_four': 50000,
            'four': 5000,
            'open_three': 5000,
            'three': 500,
            'open_two': 500,
            'two': 50,
            'center_bonus': 50
        }
    
    def get_info(self) -> Dict[str, Any]:
        """
        Get basic information of the AI player.
        
        Returns:
            Dict containing AI basic information.
        """
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "difficulty": self.difficulty,
            "timeout": self.timeout,
            "capabilities": [
                "position_evaluation",
                "threat_detection", 
                "winning_move_detection",
                "blocking_strategy",
                "pattern_recognition",
                "minimax",
                "alpha_beta_pruning"
            ]
        }
    
    def make_move(self, game_state: Dict[str, Any]) -> List[int]:
        """
        Make a move decision based on the current game state.
        
        Args:
            game_state: Current game state dictionary
            
        Returns:
            Move position [x, y]
        """
        try:
            # Validate game state
            self._validate_game_state(game_state)
            
            board = game_state.get('board', [])
            my_color = game_state.get('my_color', 'black')
            current_player = game_state.get('current_player', 'black')
            self.move_count = game_state.get('round_number', 1)
            
            # Check if it's my turn
            if current_player != my_color:
                raise ValueError(f"Not my turn: current_player={current_player}, my_color={my_color}")
            
            # Convert colors to values
            my_value = 1 if my_color == "black" else 2
            opponent_value = 2 if my_color == "black" else 1
            
            # If it's the first move, choose the center
            if self._is_first_move(board):
                center = self.board_size // 2
                return [center, center]
            
            # Check for immediate winning moves
            winning_move = self._find_winning_move(board, my_value)
            if winning_move:
                return winning_move
            
            # Check for immediate blocking moves
            blocking_move = self._find_winning_move(board, opponent_value)
            if blocking_move:
                return blocking_move
            
            # Use minimax search for strategic decision
            best_move = self._minimax_search(board, my_value, opponent_value)
            
            # Validate the move
            self._validate_move(board, best_move)
            
            return best_move
            
        except Exception as e:
            # Fallback to safe random move on error
            return self._get_safe_random_move(game_state.get('board', []))
    
    def _validate_game_state(self, game_state: Dict[str, Any]) -> None:
        """Validate the game state."""
        if not isinstance(game_state, dict):
            raise ValueError("Game state must be a dict")
        
        if 'board' not in game_state:
            raise ValueError("Game state is missing board information")
        
        board = game_state['board']
        if not isinstance(board, list) or len(board) != self.board_size:
            raise ValueError(f"Invalid board size; expected {self.board_size}x{self.board_size}")
        
        for row in board:
            if not isinstance(row, list) or len(row) != self.board_size:
                raise ValueError(f"Invalid row size; expected {self.board_size}")
    
    def _is_first_move(self, board: List[List[int]]) -> bool:
        """Check if it is the first move."""
        for row in board:
            for cell in row:
                if cell != 0:
                    return False
        return True
    
    def _find_winning_move(self, board: List[List[int]], player_value: int) -> Optional[List[int]]:
        """
        Find a move that results in an immediate win.
        
        Args:
            board: Board state
            player_value: Player value (1=black, 2=white)
            
        Returns:
            Winning position [x, y], or None if none exists
        """
        candidates = self._get_candidate_positions(board)
        
        for x, y in candidates:
            if board[x][y] == 0:
                board[x][y] = player_value
                if self._check_win(board, x, y, player_value):
                    board[x][y] = 0
                    return [x, y]
                board[x][y] = 0
        
        return None
    
    def _check_win(self, board: List[List[int]], x: int, y: int, player_value: int) -> bool:
        """
        Check if placing at the specified position results in a win.
        
        Args:
            board: Board state
            x, y: Position to check
            player_value: Player value
            
        Returns:
            True if it results in a win
        """
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        
        for dx, dy in directions:
            count = 1
            
            # Forward direction
            nx, ny = x + dx, y + dy
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
                   board[nx][ny] == player_value):
                count += 1
                nx, ny = nx + dx, ny + dy
            
            # Reverse direction
            nx, ny = x - dx, y - dy
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
                   board[nx][ny] == player_value):
                count += 1
                nx, ny = nx - dx, ny - dy
            
            if count >= 5:
                return True
        
        return False
    
    def _minimax_search(self, board: List[List[int]], my_value: int, opponent_value: int) -> List[int]:
        """
        Perform minimax search with alpha-beta pruning to find the best move.
        
        Args:
            board: Current board state
            my_value: My piece value
            opponent_value: Opponent piece value
            
        Returns:
            Best move position [x, y]
        """
        best_score = -float('inf')
        best_move = None
        candidates = self._get_candidate_positions(board)
        
        # Order moves by heuristic value for better pruning
        candidate_scores = []
        for x, y in candidates:
            if board[x][y] == 0:
                score = self._evaluate_position_heuristic(board, x, y, my_value, opponent_value)
                candidate_scores.append((score, (x, y)))
        
        # Sort by score in descending order (best moves first)
        candidate_scores.sort(key=lambda x: x[0], reverse=True)
        ordered_candidates = [pos for _, pos in candidate_scores]
        
        # Determine search depth based on game stage
        search_depth = self._get_adaptive_depth(len(candidates))
        
        # Try the best candidate first without deep search for efficiency
        if ordered_candidates:
            best_move = list(ordered_candidates[0])
            
            # Only do deep search if we have enough candidates and time
            if len(ordered_candidates) > 5 and search_depth > 1:
                alpha = -float('inf')
                beta = float('inf')
                
                for x, y in ordered_candidates:
                    if board[x][y] == 0:
                        board[x][y] = my_value
                        score = self._minimax(
                            board, search_depth - 1, False, alpha, beta, 
                            my_value, opponent_value
                        )
                        board[x][y] = 0
                        
                        if score > best_score:
                            best_score = score
                            best_move = [x, y]
                            alpha = max(alpha, best_score)
                            
                        # Alpha-beta pruning
                        if beta <= alpha:
                            break
        
        return best_move if best_move else self._get_safe_random_move(board)
    
    def _get_adaptive_depth(self, num_candidates: int) -> int:
        """Get adaptive search depth based on number of candidate moves."""
        if num_candidates <= 10:
            return min(self.max_search_depth + 1, 6)
        elif num_candidates <= 20:
            return self.max_search_depth
        else:
            return max(self.max_search_depth - 1, 2)
    
    def _minimax(self, board: List[List[int]], depth: int, maximizing: bool, 
                 alpha: float, beta: float, my_value: int, opponent_value: int) -> float:
        """
        Minimax algorithm with alpha-beta pruning.
        
        Args:
            board: Current board state
            depth: Remaining search depth
            maximizing: Whether this is a maximizing node
            alpha: Alpha value for pruning
            beta: Beta value for pruning
            my_value: My piece value
            opponent_value: Opponent piece value
            
        Returns:
            Evaluation score
        """
        if depth == 0:
            return self._evaluate_board(board, my_value, opponent_value)
        
        current_value = my_value if maximizing else opponent_value
        candidates = self._get_candidate_positions(board)
        
        if maximizing:
            max_eval = -float('inf')
            for x, y in candidates:
                if board[x][y] == 0:
                    board[x][y] = current_value
                    
                    # Check for terminal states
                    if self._check_win(board, x, y, current_value):
                        board[x][y] = 0
                        return float('inf')
                    
                    eval_score = self._minimax(
                        board, depth - 1, False, alpha, beta, my_value, opponent_value
                    )
                    board[x][y] = 0
                    
                    max_eval = max(max_eval, eval_score)
                    alpha = max(alpha, eval_score)
                    
                    if beta <= alpha:
                        break
                        
            return max_eval
        else:
            min_eval = float('inf')
            for x, y in candidates:
                if board[x][y] == 0:
                    board[x][y] = current_value
                    
                    # Check for terminal states
                    if self._check_win(board, x, y, current_value):
                        board[x][y] = 0
                        return -float('inf')
                    
                    eval_score = self._minimax(
                        board, depth - 1, True, alpha, beta, my_value, opponent_value
                    )
                    board[x][y] = 0
                    
                    min_eval = min(min_eval, eval_score)
                    beta = min(beta, eval_score)
                    
                    if beta <= alpha:
                        break
                        
            return min_eval
    
    def _evaluate_board(self, board: List[List[int]], my_value: int, opponent_value: int) -> float:
        """
        Evaluate the entire board state.
        
        Args:
            board: Board state
            my_value: My piece value
            opponent_value: Opponent piece value
            
        Returns:
            Board evaluation score
        """
        my_score = self._calculate_player_score(board, my_value)
        opponent_score = self._calculate_player_score(board, opponent_value)
        return my_score - opponent_score * 0.9  # Slightly favor offensive play
    
    def _calculate_player_score(self, board: List[List[int]], player_value: int) -> float:
        """
        Calculate score for a specific player based on patterns.
        
        Args:
            board: Board state
            player_value: Player value
            
        Returns:
            Player score
        """
        score = 0.0
        
        # Count patterns in all directions
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == player_value:
                    # Add center bonus
                    center_x, center_y = self.board_size // 2, self.board_size // 2
                    distance_to_center = abs(i - center_x) + abs(j - center_y)
                    score += max(0, self.pattern_weights['center_bonus'] - distance_to_center * 2)
                    
                    # Check patterns in all directions
                    directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
                    for dx, dy in directions:
                        pattern_score = self._evaluate_pattern_in_direction(
                            board, i, j, dx, dy, player_value
                        )
                        score += pattern_score
        
        return score
    
    def _evaluate_pattern_in_direction(self, board: List[List[int]], x: int, y: int, 
                                     dx: int, dy: int, player_value: int) -> float:
        """
        Evaluate patterns in a specific direction from a position.
        
        Args:
            board: Board state
            x, y: Starting position
            dx, dy: Direction vector
            player_value: Player value
            
        Returns:
            Pattern score
        """
        # Count consecutive pieces in both directions
        count = 1
        blocked_ends = 0
        
        # Forward direction
        nx, ny = x + dx, y + dy
        while (0 <= nx < self.board_size and 0 <= ny < self.board_size):
            if board[nx][ny] == player_value:
                count += 1
                nx, ny = nx + dx, ny + dy
            elif board[nx][ny] == 0:
                break
            else:  # opponent piece
                blocked_ends += 1
                break
        
        # Check if forward end is blocked by board edge
        if not (0 <= nx < self.board_size and 0 <= ny < self.board_size):
            blocked_ends += 1
        
        # Reverse direction
        nx, ny = x - dx, y - dy
        while (0 <= nx < self.board_size and 0 <= ny < self.board_size):
            if board[nx][ny] == player_value:
                count += 1
                nx, ny = nx - dx, ny - dy
            elif board[nx][ny] == 0:
                break
            else:  # opponent piece
                blocked_ends += 1
                break
        
        # Check if reverse end is blocked by board edge
        if not (0 <= nx < self.board_size and 0 <= ny < self.board_size):
            blocked_ends += 1
        
        # Calculate pattern score based on count and blocked ends
        if count >= 5:
            return self.pattern_weights['five']  # Win
        elif count == 4:
            if blocked_ends == 0:
                return self.pattern_weights['open_four']
            elif blocked_ends == 1:
                return self.pattern_weights['four']
        elif count == 3:
            if blocked_ends == 0:
                return self.pattern_weights['open_three']
            elif blocked_ends == 1:
                return self.pattern_weights['three']
        elif count == 2:
            if blocked_ends == 0:
                return self.pattern_weights['open_two']
            elif blocked_ends == 1:
                return self.pattern_weights['two']
        
        return 0.0
    
    def _evaluate_position_heuristic(self, board: List[List[int]], x: int, y: int, 
                                   my_value: int, opponent_value: int) -> float:
        """
        Fast heuristic evaluation for move ordering.
        
        Args:
            board: Board state
            x, y: Position to evaluate
            my_value: My piece value
            opponent_value: Opponent piece value
            
        Returns:
            Heuristic score
        """
        if board[x][y] != 0:
            return -1000000
        
        score = 0.0
        
        # Center bonus
        center_x, center_y = self.board_size // 2, self.board_size // 2
        distance_to_center = abs(x - center_x) + abs(y - center_y)
        score += max(0, 50 - distance_to_center * 3)
        
        # Check immediate threats and opportunities
        temp_board = [row[:] for row in board]
        temp_board[x][y] = my_value
        
        # Check if this creates a winning opportunity
        if self._check_win(temp_board, x, y, my_value):
            score += 100000
        
        # Check if this creates a four-in-a-row
        if self._would_create_four(temp_board, x, y, my_value):
            score += 10000
        
        # Check if this blocks opponent threats
        temp_board[x][y] = opponent_value
        if self._check_win(temp_board, x, y, opponent_value):
            score += 90000
        
        # Check if this blocks opponent's four-in-a-row
        if self._would_create_four(temp_board, x, y, opponent_value):
            score += 8000
        
        temp_board[x][y] = 0
        
        # Check nearby pieces
        for dx in range(-2, 3):
            for dy in range(-2, 3):
                nx, ny = x + dx, y + dy
                if (0 <= nx < self.board_size and 0 <= ny < self.board_size and
                    (dx != 0 or dy != 0)):
                    if board[nx][ny] == my_value:
                        score += 10
                    elif board[nx][ny] == opponent_value:
                        score += 5
        
        return score
    
    def _would_create_four(self, board: List[List[int]], x: int, y: int, player_value: int) -> bool:
        """Check if placing at (x,y) would create a four-in-a-row threat."""
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        
        for dx, dy in directions:
            count = 1
            
            # Forward
            nx, ny = x + dx, y + dy
            empty_count = 0
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
                   (board[nx][ny] == player_value or (board[nx][ny] == 0 and empty_count < 1))):
                if board[nx][ny] == player_value:
                    count += 1
                elif board[nx][ny] == 0:
                    empty_count += 1
                nx, ny = nx + dx, ny + dy
            
            # Reverse
            nx, ny = x - dx, y - dy
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
                   (board[nx][ny] == player_value or (board[nx][ny] == 0 and empty_count < 1))):
                if board[nx][ny] == player_value:
                    count += 1
                elif board[nx][ny] == 0:
                    empty_count += 1
                nx, ny = nx - dx, ny - dy
            
            if count >= 4 and empty_count <= 1:
                return True
        
        return False
    
    def _get_candidate_positions(self, board: List[List[int]]) -> List[Tuple[int, int]]:
        """
        Get candidate move positions around existing pieces.
        
        Args:
            board: Board state
            
        Returns:
            List of candidate positions
        """
        candidates = set()
        radius = self.candidate_radius
        
        # If board is mostly empty, expand search radius
        piece_count = sum(sum(1 for cell in row if cell != 0) for row in board)
        if piece_count < 10:
            radius = max(radius, 4)
        
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] != 0:
                    for di in range(-radius, radius + 1):
                        for dj in range(-radius, radius + 1):
                            ni, nj = i + di, j + dj
                            if (0 <= ni < self.board_size and 
                                0 <= nj < self.board_size and 
                                board[ni][nj] == 0):
                                candidates.add((ni, nj))
        
        # If no candidates found (shouldn't happen in normal games), add all empty positions
        if not candidates:
            for i in range(self.board_size):
                for j in range(self.board_size):
                    if board[i][j] == 0:
                        candidates.add((i, j))
        
        return list(candidates)
    
    def _validate_move(self, board: List[List[int]], move: List[int]) -> None:
        """Validate the move position."""
        if not isinstance(move, list) or len(move) != 2:
            raise ValueError("Move must be a list of length 2")
        
        x, y = move
        if not (0 <= x < self.board_size and 0 <= y < self.board_size):
            raise ValueError(f"Move out of board range: ({x}, {y})")
        
        if board[x][y] != 0:
            raise ValueError(f"Move position already occupied: ({x}, {y})")
    
    def _get_safe_random_move(self, board: List[List[int]]) -> List[int]:
        """Get a safe random move position."""
        empty_positions = []
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == 0:
                    empty_positions.append([i, j])
        
        if empty_positions:
            # Prefer center positions for random moves
            center = self.board_size // 2
            empty_positions.sort(
                key=lambda pos: abs(pos[0] - center) + abs(pos[1] - center)
            )
            return empty_positions[0]
        else:
            center = self.board_size // 2
            return [center, center]