"""
Test script for Claude Gomoku Master AI
"""

import sys
import os
import time
from typing import List, Dict, Any

# Add the current directory to the path so we can import the AI
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import the AI
from ai_player import MinimalClaudeAI

def test_ai_initialization():
    """Test AI initialization"""
    print("Testing AI initialization...")
    ai = MinimalClaudeAI()
    assert ai.ai_id == "minimal_claude_3_7_sonnet_AI", f"AI ID mismatch: {ai.ai_id}"
    assert ai.name == "Claude Gomoku Master", f"AI name mismatch: {ai.name}"
    assert ai.board_size == 15, f"Board size mismatch: {ai.board_size}"
    print("AI initialization test passed!")

def test_ai_info():
    """Test AI info method"""
    print("Testing AI info method...")
    ai = MinimalClaudeAI()
    info = ai.get_info()
    assert isinstance(info, dict), "Info should be a dictionary"
    assert "ai_id" in info, "Info missing ai_id"
    assert "name" in info, "Info missing name"
    assert "capabilities" in info, "Info missing capabilities"
    print("AI info test passed!")

def test_first_move():
    """Test AI first move"""
    print("Testing AI first move...")
    ai = MinimalClaudeAI()
    board = [[0 for _ in range(15)] for _ in range(15)]
    game_state = {
        "board": board,
        "current_player": "black",
        "my_color": "black",
        "round_number": 1
    }
    
    start_time = time.time()
    move = ai.make_move(game_state)
    end_time = time.time()
    
    assert isinstance(move, list), "Move should be a list"
    assert len(move) == 2, "Move should have 2 elements"
    assert 0 <= move[0] < 15 and 0 <= move[1] < 15, f"Move out of bounds: {move}"
    
    # First move should be the center
    assert move == [7, 7], f"First move should be center [7, 7], got {move}"
    
    print(f"First move test passed! Decision time: {end_time - start_time:.3f}s")

def test_winning_move():
    """Test AI winning move detection"""
    print("Testing AI winning move detection...")
    ai = MinimalClaudeAI()
    
    # Create a board with 4 in a row for black
    board = [[0 for _ in range(15)] for _ in range(15)]
    for i in range(4):
        board[5][i+5] = 1  # Black pieces at (5,5), (5,6), (5,7), (5,8)
    
    game_state = {
        "board": board,
        "current_player": "black",
        "my_color": "black",
        "round_number": 5
    }
    
    start_time = time.time()
    move = ai.make_move(game_state)
    end_time = time.time()
    
    assert move == [5, 9], f"AI should detect winning move at [5, 9], got {move}"
    
    print(f"Winning move test passed! Decision time: {end_time - start_time:.3f}s")

def test_blocking_move():
    """Test AI blocking move detection"""
    print("Testing AI blocking move detection...")
    ai = MinimalClaudeAI()
    
    # Create a board with 4 in a row for white
    board = [[0 for _ in range(15)] for _ in range(15)]
    for i in range(4):
        board[i+5][5] = 2  # White pieces at (5,5), (6,5), (7,5), (8,5)
    
    game_state = {
        "board": board,
        "current_player": "black",
        "my_color": "black",
        "round_number": 5
    }
    
    start_time = time.time()
    move = ai.make_move(game_state)
    end_time = time.time()
    
    assert move == [9, 5], f"AI should detect blocking move at [9, 5], got {move}"
    
    print(f"Blocking move test passed! Decision time: {end_time - start_time:.3f}s")

def test_strategic_move():
    """Test AI strategic move"""
    print("Testing AI strategic move...")
    ai = MinimalClaudeAI()
    
    # Create a board with some pieces
    board = [[0 for _ in range(15)] for _ in range(15)]
    board[7][7] = 1  # Black at center
    board[7][8] = 2  # White
    board[8][7] = 1  # Black
    
    game_state = {
        "board": board,
        "current_player": "black",
        "my_color": "black",
        "round_number": 3
    }
    
    start_time = time.time()
    move = ai.make_move(game_state)
    end_time = time.time()
    
    assert isinstance(move, list), "Move should be a list"
    assert len(move) == 2, "Move should have 2 elements"
    assert 0 <= move[0] < 15 and 0 <= move[1] < 15, f"Move out of bounds: {move}"
    assert board[move[0]][move[1]] == 0, f"Position {move} is already occupied"
    
    print(f"Strategic move test passed! Decision time: {end_time - start_time:.3f}s")
    print(f"AI chose move: {move}")

def test_performance():
    """Test AI performance"""
    print("Testing AI performance...")
    ai = MinimalClaudeAI()
    
    # Create a mid-game board
    board = [[0 for _ in range(15)] for _ in range(15)]
    # Add some random pieces
    pieces = [(7, 7, 1), (7, 8, 2), (8, 7, 1), (8, 8, 2), 
              (6, 6, 1), (6, 7, 2), (6, 8, 1), (9, 9, 2)]
    for x, y, v in pieces:
        board[x][y] = v
    
    game_state = {
        "board": board,
        "current_player": "black",
        "my_color": "black",
        "round_number": 9
    }
    
    start_time = time.time()
    move = ai.make_move(game_state)
    end_time = time.time()
    
    decision_time = end_time - start_time
    print(f"Performance test: Decision time: {decision_time:.3f}s")
    assert decision_time < 10, f"Decision took too long: {decision_time:.3f}s"

def run_all_tests():
    """Run all tests"""
    test_ai_initialization()
    test_ai_info()
    test_first_move()
    test_winning_move()
    test_blocking_move()
    test_strategic_move()
    test_performance()
    print("\nAll tests passed!")

if __name__ == "__main__":
    run_all_tests()