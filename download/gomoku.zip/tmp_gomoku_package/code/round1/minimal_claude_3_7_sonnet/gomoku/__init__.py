# __init__.py for minimal_claude_3_7_sonnet_AI module
from .ai_player import MinimalClaudeAI