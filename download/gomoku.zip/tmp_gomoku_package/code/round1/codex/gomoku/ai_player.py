"""
GPT-5.1 Tactical Gomoku AI

This AI focuses on:
- Fast winning / blocking detection
- Strong pattern-based evaluation (live/blocked 2–4, center control)
- Adaptive candidate generation based on board density
- Depth-adaptive minimax search with alpha-beta pruning and move ordering
"""

import random
import time
from typing import List, Dict, Tuple, Optional, Any


class GPT_5_1_Tactical_AI:
    """
    Competitive Gomoku AI player.

    The engine discovers this class because its name ends with "AI"
    and it implements a `make_move` method.
    """

    def __init__(self) -> None:
        # Required fields
        self.ai_id = "gpt_5_1_tactical_ai"
        self.name = "GPT 5.1 Tactical AI"
        self.version = "1.0"
        self.board_size = 15
        self.description = (
            "Competitive Gomoku AI with pattern-based evaluation and "
            "depth-adaptive minimax search with alpha-beta pruning"
        )
        self.author = "GPT-5.1"
        self.difficulty = "expert"
        self.timeout = 10

        # Search parameters (tuned for 10s timeout)
        self.max_search_depth = 3
        self.search_width_root = 12
        self.search_width_inner = 8

        # Pattern scores used in evaluation
        self.pattern_scores: Dict[str, int] = {
            "five": 100000,
            "open_four": 60000,
            "four": 12000,
            "open_three": 6000,
            "three": 1500,
            "open_two": 600,
            "two": 150,
            "center": 40,
        }

        # Directions for line checks: horizontal, vertical, two diagonals
        self.directions: List[Tuple[int, int]] = [
            (1, 0),
            (0, 1),
            (1, 1),
            (1, -1),
        ]

    # ------------------------------------------------------------------
    # Required public interface
    # ------------------------------------------------------------------

    def get_info(self) -> Dict[str, Any]:
        """Return AI metadata required by the engine."""
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "difficulty": self.difficulty,
            "timeout": self.timeout,
            "capabilities": [
                "position_evaluation",
                "threat_detection",
                "winning_move_detection",
                "blocking_strategy",
                "pattern_recognition",
                "minimax_search",
                "alpha_beta_pruning",
            ],
        }

    def make_move(self, game_state: Dict[str, Any]) -> List[int]:
        """
        Decide the next move based on current game state.

        Args:
            game_state: dict with at least:
                - board: 15x15 list of lists (0 empty, 1 black, 2 white)
                - my_color: "black" or "white"
                - current_player: whose turn it is

        Returns:
            [x, y]: coordinates of the chosen move.
        """
        try:
            start_time = time.time()

            board = game_state.get("board", [])
            my_color = game_state.get("my_color", "black")
            current_player = game_state.get("current_player", "black")

            if current_player != my_color:
                raise ValueError(
                    f"Not my turn: current_player={current_player}, my_color={my_color}"
                )

            if not board or len(board) != self.board_size:
                raise ValueError("Invalid board state")

            my_value = 1 if my_color == "black" else 2
            opponent_value = 3 - my_value

            # Adaptive depth: go deeper in mid/late game
            stones = sum(1 for row in board for cell in row if cell != 0)
            if stones >= 40:
                self.max_search_depth = 4
            else:
                self.max_search_depth = 3

            # First move: play center
            if self._is_first_move(board):
                center = self.board_size // 2
                return [center, center]

            # Second move: respond near center to keep symmetry
            if self._is_second_move(board):
                center = self.board_size // 2
                offsets = [
                    (1, 0),
                    (0, 1),
                    (1, 1),
                    (-1, 0),
                    (0, -1),
                    (-1, -1),
                    (1, -1),
                    (-1, 1),
                ]
                for dx, dy in offsets:
                    x, y = center + dx, center + dy
                    if 0 <= x < self.board_size and 0 <= y < self.board_size:
                        if board[x][y] == 0:
                            return [x, y]

            # Immediate winning move
            move = self._find_winning_move(board, my_value)
            if move:
                return move

            # Immediate block against opponent winning
            move = self._find_winning_move(board, opponent_value)
            if move:
                return move

            # Threat creation / open-four opportunities
            move = self._find_threat_move(board, my_value, opponent_value)
            if move:
                return move

            # Minimax search with alpha-beta pruning
            move = self._minimax_root(
                board, my_value, opponent_value, start_time=start_time
            )
            if move:
                return move

            # Fallback: best single-step evaluation
            move = self._best_by_static_eval(board, my_value, opponent_value)
            if move:
                return move

            # Last resort: safe random
            return self._get_safe_random_move(board)

        except Exception as exc:
            print(f"GPT_5_1_Tactical_AI decision error: {exc}")
            return self._get_safe_random_move(game_state.get("board", []))

    # ------------------------------------------------------------------
    # High-level helpers
    # ------------------------------------------------------------------

    def _is_first_move(self, board: List[List[int]]) -> bool:
        for row in board:
            for cell in row:
                if cell != 0:
                    return False
        return True

    def _is_second_move(self, board: List[List[int]]) -> bool:
        stones = 0
        for row in board:
            for cell in row:
                if cell != 0:
                    stones += 1
                    if stones > 1:
                        return False
        return stones == 1

    def _find_winning_move(
        self, board: List[List[int]], player_value: int
    ) -> Optional[List[int]]:
        """Find a move that results in an immediate win for `player_value`."""
        candidates = self._candidate_positions(board, distance=2)
        for x, y in candidates:
            if board[x][y] != 0:
                continue
            board[x][y] = player_value
            try:
                if self._check_win(board, x, y, player_value):
                    return [x, y]
            finally:
                board[x][y] = 0
        return None

    def _find_threat_move(
        self, board: List[List[int]], my_value: int, opponent_value: int
    ) -> Optional[List[int]]:
        """
        Look for strong threat-creating moves, primarily open-fours.

        1. Prefer moves that create open-four for us.
        2. Then block opponent moves that would create open-four.
        """
        candidates = self._candidate_positions(board, distance=2)

        # 1. Create our own open-four
        for x, y in candidates:
            if board[x][y] != 0:
                continue
            board[x][y] = my_value
            try:
                if self._count_open_fours(board, x, y, my_value) > 0:
                    return [x, y]
            finally:
                board[x][y] = 0

        # 2. Block opponent's open-four
        for x, y in candidates:
            if board[x][y] != 0:
                continue
            board[x][y] = opponent_value
            try:
                if self._count_open_fours(board, x, y, opponent_value) > 0:
                    return [x, y]
            finally:
                board[x][y] = 0

        return None

    # ------------------------------------------------------------------
    # Minimax search
    # ------------------------------------------------------------------

    def _minimax_root(
        self,
        board: List[List[int]],
        my_value: int,
        opponent_value: int,
        start_time: float,
    ) -> Optional[List[int]]:
        """Root of minimax search with alpha-beta pruning."""
        best_score = -float("inf")
        best_move: Optional[List[int]] = None
        alpha = -float("inf")
        beta = float("inf")

        candidates = self._candidate_positions(board, distance=2)

        # Order by static evaluation (descending)
        scored: List[Tuple[float, int, int]] = []
        for x, y in candidates:
            if board[x][y] != 0:
                continue
            score = self._evaluate_move(board, x, y, my_value, opponent_value)
            scored.append((score, x, y))
        scored.sort(reverse=True, key=lambda t: t[0])

        limit = self.search_width_root

        for score, x, y in scored[:limit]:
            # Time guard
            if time.time() - start_time > self.timeout * 0.8:
                break

            board[x][y] = my_value
            try:
                # Early win shortcut
                if self._check_win(board, x, y, my_value):
                    return [x, y]

                value = self._minimax(
                    board=board,
                    depth=self.max_search_depth - 1,
                    alpha=alpha,
                    beta=beta,
                    is_maximizing=False,
                    my_value=my_value,
                    opponent_value=opponent_value,
                    start_time=start_time,
                )
            finally:
                board[x][y] = 0

            if value > best_score:
                best_score = value
                best_move = [x, y]
                alpha = max(alpha, value)

        return best_move

    def _minimax(
        self,
        board: List[List[int]],
        depth: int,
        alpha: float,
        beta: float,
        is_maximizing: bool,
        my_value: int,
        opponent_value: int,
        start_time: float,
    ) -> float:
        """Recursive minimax search with alpha-beta pruning."""
        # Timeout guard
        if time.time() - start_time > self.timeout * 0.8:
            return 0.0

        if depth == 0:
            return self._evaluate_board(board, my_value, opponent_value)

        candidates = self._candidate_positions(board, distance=1)
        if not candidates:
            return 0.0

        # Move ordering
        scored_candidates: List[Tuple[float, int, int]] = []
        for x, y in candidates:
            if board[x][y] != 0:
                continue
            s = self._evaluate_move(board, x, y, my_value, opponent_value)
            scored_candidates.append((s, x, y))
        scored_candidates.sort(reverse=True, key=lambda t: t[0])
        scored_candidates = scored_candidates[: self.search_width_inner]

        if is_maximizing:
            value = -float("inf")
            for _, x, y in scored_candidates:
                board[x][y] = my_value
                try:
                    if self._check_win(board, x, y, my_value):
                        return float("inf")
                    score = self._minimax(
                        board,
                        depth - 1,
                        alpha,
                        beta,
                        False,
                        my_value,
                        opponent_value,
                        start_time,
                    )
                finally:
                    board[x][y] = 0

                value = max(value, score)
                alpha = max(alpha, score)
                if beta <= alpha:
                    break
            return value
        else:
            value = float("inf")
            for _, x, y in scored_candidates:
                board[x][y] = opponent_value
                try:
                    if self._check_win(board, x, y, opponent_value):
                        return -float("inf")
                    score = self._minimax(
                        board,
                        depth - 1,
                        alpha,
                        beta,
                        True,
                        my_value,
                        opponent_value,
                        start_time,
                    )
                finally:
                    board[x][y] = 0

                value = min(value, score)
                beta = min(beta, score)
                if beta <= alpha:
                    break
            return value

    # ------------------------------------------------------------------
    # Evaluation helpers
    # ------------------------------------------------------------------

    def _evaluate_board(
        self, board: List[List[int]], my_value: int, opponent_value: int
    ) -> float:
        """Evaluate the whole board from my perspective."""
        my_score = 0.0
        opp_score = 0.0

        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == my_value:
                    my_score += self._evaluate_patterns(board, i, j, my_value)
                elif board[i][j] == opponent_value:
                    opp_score += self._evaluate_patterns(board, i, j, opponent_value)

        # Weight opponent score slightly higher to stay defensive
        return my_score - opp_score * 1.05

    def _evaluate_move(
        self,
        board: List[List[int]],
        x: int,
        y: int,
        my_value: int,
        opponent_value: int,
    ) -> float:
        """Static evaluation of a single move (place at x,y as me)."""
        if board[x][y] != 0:
            return -1e9

        board[x][y] = my_value
        try:
            score_me = self._evaluate_patterns(board, x, y, my_value)
        finally:
            board[x][y] = 0

        board[x][y] = opponent_value
        try:
            score_opp = self._evaluate_patterns(board, x, y, opponent_value)
        finally:
            board[x][y] = 0

        # Combine offensive and defensive value
        return score_me * 1.1 + score_opp

    def _evaluate_patterns(
        self, board: List[List[int]], x: int, y: int, player_value: int
    ) -> float:
        """Evaluate patterns centered around (x, y) for player_value."""
        score = 0.0

        # Center control bonus
        center = self.board_size // 2
        distance_center = abs(x - center) + abs(y - center)
        score += max(0, self.pattern_scores["center"] - distance_center * 3)

        for dx, dy in self.directions:
            line = self._collect_line(board, x, y, dx, dy, player_value)
            score += self._score_line(line)

        return score

    def _collect_line(
        self,
        board: List[List[int]],
        x: int,
        y: int,
        dx: int,
        dy: int,
        player_value: int,
        length: int = 9,
    ) -> List[int]:
        """
        Collect values in one direction (both sides) around (x, y).
        Returns a line of up to `length` cells centered at (x,y).
        """
        values: List[int] = [player_value]

        # Forward direction
        nx, ny = x + dx, y + dy
        while (
            0 <= nx < self.board_size
            and 0 <= ny < self.board_size
            and len(values) < length
        ):
            values.append(board[nx][ny])
            nx += dx
            ny += dy

        # Reverse direction
        reverse: List[int] = []
        nx, ny = x - dx, y - dy
        while (
            0 <= nx < self.board_size
            and 0 <= ny < self.board_size
            and len(values) + len(reverse) < length
        ):
            reverse.append(board[nx][ny])
            nx -= dx
            ny -= dy

        reverse.reverse()
        return reverse + values

    def _score_line(self, line: List[int]) -> float:
        """
        Score a line segment for the player.
        Uses simple pattern counting: live/blocked 2–4 and five.
        """
        if len(line) < 5:
            return 0.0

        score = 0.0
        n = len(line)

        for i in range(n - 4):
            window = line[i : i + 5]
            stones = sum(1 for v in window if v == 1 or v == 2)
            empties = window.count(0)

            if stones == 0:
                continue

            # Position of the five-segment in the original line
            left_blocked = i > 0 and line[i - 1] not in (0, window[0])
            right_blocked = i + 5 < n and line[i + 5] not in (0, window[-1])

            if stones == 5:
                score += self.pattern_scores["five"]
            elif stones == 4 and empties == 1:
                if not left_blocked and not right_blocked:
                    score += self.pattern_scores["open_four"]
                else:
                    score += self.pattern_scores["four"]
            elif stones == 3 and empties == 2:
                if not left_blocked and not right_blocked:
                    score += self.pattern_scores["open_three"]
                else:
                    score += self.pattern_scores["three"]
            elif stones == 2 and empties == 3:
                if not left_blocked and not right_blocked:
                    score += self.pattern_scores["open_two"]
                else:
                    score += self.pattern_scores["two"]

        return score

    def _count_open_fours(
        self, board: List[List[int]], x: int, y: int, player_value: int
    ) -> int:
        """Count open-four patterns created by placing at (x,y)."""
        count_open = 0
        for dx, dy in self.directions:
            count = 1
            front_empty = False
            back_empty = False

            nx, ny = x + dx, y + dy
            while 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                if board[nx][ny] == player_value:
                    count += 1
                    nx += dx
                    ny += dy
                elif board[nx][ny] == 0:
                    front_empty = True
                    break
                else:
                    break

            nx, ny = x - dx, y - dy
            while 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                if board[nx][ny] == player_value:
                    count += 1
                    nx -= dx
                    ny -= dy
                elif board[nx][ny] == 0:
                    back_empty = True
                    break
                else:
                    break

            if count == 4 and front_empty and back_empty:
                count_open += 1

        return count_open

    # ------------------------------------------------------------------
    # Board / move utilities
    # ------------------------------------------------------------------

    def _check_win(
        self, board: List[List[int]], x: int, y: int, player_value: int
    ) -> bool:
        """Check whether move at (x, y) for `player_value` yields 5 in a row."""
        for dx, dy in self.directions:
            count = 1

            nx, ny = x + dx, y + dy
            while (
                0 <= nx < self.board_size
                and 0 <= ny < self.board_size
                and board[nx][ny] == player_value
            ):
                count += 1
                nx += dx
                ny += dy

            nx, ny = x - dx, y - dy
            while (
                0 <= nx < self.board_size
                and 0 <= ny < self.board_size
                and board[nx][ny] == player_value
            ):
                count += 1
                nx -= dx
                ny -= dy

            if count >= 5:
                return True

        return False

    def _candidate_positions(
        self, board: List[List[int]], distance: int = 2
    ) -> List[Tuple[int, int]]:
        """
        Return empty positions within `distance` of existing stones.

        This significantly reduces branching versus checking the full board.
        """
        candidates = set()

        radius = distance
        stones = sum(1 for row in board for cell in row if cell != 0)
        if stones < 10:
            radius = max(radius, 4)

        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] != 0:
                    for di in range(-radius, radius + 1):
                        for dj in range(-radius, radius + 1):
                            ni, nj = i + di, j + dj
                            if (
                                0 <= ni < self.board_size
                                and 0 <= nj < self.board_size
                                and board[ni][nj] == 0
                            ):
                                candidates.add((ni, nj))

        if not candidates:
            center = self.board_size // 2
            if board[center][center] == 0:
                return [(center, center)]
            for i in range(max(0, center - 2), min(self.board_size, center + 3)):
                for j in range(max(0, center - 2), min(self.board_size, center + 3)):
                    if board[i][j] == 0:
                        candidates.add((i, j))

        return list(candidates)

    def _best_by_static_eval(
        self, board: List[List[int]], my_value: int, opponent_value: int
    ) -> Optional[List[int]]:
        """Pure static evaluation fallback (no deep search)."""
        candidates = self._candidate_positions(board, distance=2)
        best_score = -float("inf")
        best_moves: List[Tuple[int, int]] = []

        for x, y in candidates:
            if board[x][y] != 0:
                continue
            score = self._evaluate_move(board, x, y, my_value, opponent_value)
            if score > best_score:
                best_score = score
                best_moves = [(x, y)]
            elif score == best_score:
                best_moves.append((x, y))

        if not best_moves:
            return None

        return list(random.choice(best_moves))

    def _get_safe_random_move(self, board: List[List[int]]) -> List[int]:
        """Return a random empty cell, preferring the central region."""
        if not board or len(board) != self.board_size:
            center = self.board_size // 2
            return [center, center]

        empties: List[Tuple[int, int]] = []
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == 0:
                    empties.append((i, j))

        if not empties:
            center = self.board_size // 2
            return [center, center]

        center = self.board_size // 2
        empties.sort(key=lambda pos: abs(pos[0] - center) + abs(pos[1] - center))
        x, y = empties[0]
        return [x, y]

    # Optional callbacks; currently no-op but kept for compatibility

    def on_game_start(self, game_info: Dict[str, Any]) -> None:
        pass

    def on_game_end(self, game_result: Dict[str, Any]) -> None:
        pass

    def on_opponent_move(self, move: List[int], board: List[List[int]]) -> None:
        pass


__all__ = ["GPT_5_1_Tactical_AI"]

