"""
Basic test suite for GPT_5_1_Tactical_AI.

These tests validate:
- initialization and metadata
- basic move generation
- winning and blocking behavior
- performance within timeout
"""

import sys
import time
from typing import List

from ai_player import GPT_5_1_Tactical_AI


def _new_board() -> List[List[int]]:
    return [[0 for _ in range(15)] for _ in range(15)]


def test_initialization() -> GPT_5_1_Tactical_AI:
    print("Testing initialization...")
    ai = GPT_5_1_Tactical_AI()
    assert ai.board_size == 15
    assert hasattr(ai, "make_move")
    info = ai.get_info()
    assert info["ai_id"] == "gpt_5_1_tactical_ai"
    print("  ✓ initialization ok")
    return ai


def test_get_info(ai: GPT_5_1_Tactical_AI) -> None:
    print("Testing get_info...")
    info = ai.get_info()
    required = ["ai_id", "name", "version", "description", "author", "difficulty", "timeout"]
    for key in required:
        assert key in info, f"missing field: {key}"
    assert isinstance(info.get("capabilities", []), list)
    print("  ✓ get_info ok")


def test_first_move(ai: GPT_5_1_Tactical_AI) -> None:
    print("Testing first move (empty board)...")
    board = _new_board()
    game_state = {
        "board": board,
        "my_color": "black",
        "current_player": "black",
        "move_history": [],
        "game_id": "test_game",
        "round_number": 1,
    }
    move = ai.make_move(game_state)
    assert isinstance(move, list) and len(move) == 2
    assert 0 <= move[0] < 15 and 0 <= move[1] < 15
    print(f"  move={move}")
    print("  ✓ first move ok")


def test_winning_move(ai: GPT_5_1_Tactical_AI) -> None:
    print("Testing winning move detection...")
    board = _new_board()
    # Four in a row for black; AI should complete five
    board[7][7] = 1
    board[7][8] = 1
    board[7][9] = 1
    board[7][10] = 1
    game_state = {
        "board": board,
        "my_color": "black",
        "current_player": "black",
        "move_history": [],
        "game_id": "test_game",
        "round_number": 5,
    }
    move = ai.make_move(game_state)
    assert move in ([7, 6], [7, 11]), f"expected winning move at [7,6] or [7,11], got {move}"
    print(f"  winning move={move}")
    print("  ✓ winning move detection ok")


def test_blocking_move(ai: GPT_5_1_Tactical_AI) -> None:
    print("Testing blocking opponent win...")
    board = _new_board()
    # White is about to win horizontally; black must block
    board[7][7] = 2
    board[7][8] = 2
    board[7][9] = 2
    board[7][10] = 2
    game_state = {
        "board": board,
        "my_color": "black",
        "current_player": "black",
        "move_history": [],
        "game_id": "test_game",
        "round_number": 5,
    }
    move = ai.make_move(game_state)
    assert move in ([7, 6], [7, 11]), f"expected block at [7,6] or [7,11], got {move}"
    print(f"  blocking move={move}")
    print("  ✓ blocking move ok")


def test_performance(ai: GPT_5_1_Tactical_AI) -> None:
    print("Testing performance (decision time)...")
    board = _new_board()
    for i in range(5):
        board[7 + i][7 + i] = 1 if i % 2 == 0 else 2
    game_state = {
        "board": board,
        "my_color": "black",
        "current_player": "black",
        "move_history": [],
        "game_id": "test_game",
        "round_number": 6,
    }
    start = time.time()
    move = ai.make_move(game_state)
    elapsed = time.time() - start
    assert isinstance(move, list) and len(move) == 2
    assert elapsed < ai.timeout, f"AI took too long: {elapsed:.3f}s"
    print(f"  move={move}, time={elapsed:.3f}s")
    print("  ✓ performance ok")


def run_all_tests() -> bool:
    print("=" * 60)
    print("GPT 5.1 Tactical Gomoku AI - Test Suite")
    print("=" * 60)
    try:
        ai = test_initialization()
        test_get_info(ai)
        test_first_move(ai)
        test_winning_move(ai)
        test_blocking_move(ai)
        test_performance(ai)
        print("\nAll tests passed.")
        return True
    except AssertionError as exc:
        print(f"Test failed: {exc}")
        return False
    except Exception as exc:
        print(f"Unexpected error: {exc}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    ok = run_all_tests()
    sys.exit(0 if ok else 1)

