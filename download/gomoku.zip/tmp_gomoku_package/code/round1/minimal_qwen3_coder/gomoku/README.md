# Minimal Qwen3 Coder Gomoku AI Development Guide
==============================================

This is a standard development template for a Gomoku AI player. It provides a complete development framework and detailed documentation for building AI players.

## 📁 File Structure

```
gomoku_0/
├── README.md           # This documentation
├── ai_player.py        # AI player implementation
├── ai_config.yaml      # AI configuration file
└── test_ai.py          # AI test script
```

## 🚀 Quick Start

### 1. AI Implementation

The AI implementation is in `ai_player.py` and includes:

- `MinimalQwen3CoderGomokuAI` class with all required methods
- Immediate threat detection (wins and blocks)
- Pattern-based evaluation function
- Efficient candidate move selection
- Center-biased positioning

### 2. Configuration

Edit the `ai_config.yaml` file to update AI information:

```yaml
ai_id: "minimal_qwen3_coder_gomoku"     # Unique AI identifier
ai_name: "Minimal Qwen3 Coder Gomoku AI" # Display name
author: "Minimal Qwen3 Coder"            # Author information
description: "Minimal but effective Gomoku AI..."  # AI description
```

### 3. Testing

Run the test script to verify the AI implementation:

```bash
python test_ai.py
```

## 📋 Required Interfaces

### Core Methods

#### 1. `__init__(self)`
Initializes the AI player with basic information.

#### 2. `get_info(self) -> Dict[str, Any]`
Returns basic AI information.

#### 3. `make_move(self, game_state: Dict[str, Any]) -> List[int]`
Decides the next move based on the game state.

### Optional Methods

The AI also implements optional methods for enhanced functionality:
- `on_game_start()` - Callback when the game starts
- `on_game_end()` - Callback when the game ends
- `on_opponent_move()` - Callback when the opponent makes a move

## 🎯 AI Algorithm Guide

### Basic Strategy

1. Winning Detection: prioritize moves that win immediately
2. Blocking Strategy: prevent the opponent from winning
3. Threat Creation: create multiple simultaneous threats
4. Position Evaluation: assess the value of each position

### Advanced Strategy

1. Pattern Recognition: detect common offensive/defensive patterns
2. Opening Book: use predefined opening moves
3. Heuristic Evaluation: fast position evaluation for move ordering

## 🧪 Testing Guide

### Basic Test

Run `test_ai.py` for basic functionality tests:

```bash
python test_ai.py
```

Test coverage includes:
- AI initialization correctness
- `get_info()` return format
- Basic functionality of `make_move()`
- Configuration file validation

### Performance Test

```python
# Measure decision time
import time

start_time = time.time()
move = ai.make_move(game_state)
end_time = time.time()

print(f"Decision time: {end_time - start_time:.3f}s")
```

## 🔧 Development Tips

### 1. Debugging Tips

```python
def make_move(self, game_state):
    # Add debug output
    print(f"Current round: {game_state.get('round_number', 0)}")
    print(f"My color: {game_state.get('my_color', 'unknown')}")
    
    # Visualize board
    self._print_board(game_state['board'])
    
    # Your decision logic
    move = self._find_best_move(board, my_color)
    
    print(f"Chosen position: ({move[0]}, {move[1]})")
    return move
```

### 2. Performance Optimization

```python
# Use efficient data structures and algorithms
# Limit search depth based on time constraints
# Cache evaluation results when possible
```

### 3. Error Handling

```python
def make_move(self, game_state):
    try:
        # Your decision logic
        return self._find_best_move(board, my_color)
    except Exception as e:
        print(f"Decision error: {e}")
        return self._get_safe_random_move(game_state.get('board', []))
```