"""
Minimal Qwen3 Coder Gomoku AI
=============================

A minimal but effective Gomoku AI implementation using basic heuristics,
pattern recognition, and threat detection for competitive play.
"""

import random
from typing import List, Dict, Tuple, Optional, Any


class MinimalQwen3CoderGomokuAI:
    """
    Minimal but effective Gomoku AI using heuristics and pattern recognition.
    
    This AI implements:
    - Immediate threat detection (wins and blocks)
    - Pattern-based evaluation function
    - Efficient candidate move selection
    - Center-biased positioning
    """
    
    def __init__(self):
        """Initialize the AI player with configuration."""
        # 【Required Field】AI unique identifier
        self.ai_id = "minimal_qwen3_coder_gomoku"
        
        # 【Required Field】AI display name
        self.name = "Minimal Qwen3 Coder Gomoku AI"
        
        # 【Required Field】AI version
        self.version = "1.0"
        
        # 【Required Field】Board size
        self.board_size = 15
        
        # 【Optional Field】AI description
        self.description = "Minimal but effective Gomoku AI using heuristics and pattern recognition"
        
        # 【Optional Field】AI author
        self.author = "Minimal Qwen3 Coder"
        
        # 【Optional Field】AI difficulty
        self.difficulty = "medium"
        
        # 【Optional Field】AI timeout
        self.timeout = 10
        
        # Internal state
        self.move_count = 0
        self.candidate_radius = 3
        
        # Pattern weights for evaluation
        self.pattern_weights = {
            'live_four': 50000,
            'dead_four': 5000,
            'live_three': 5000,
            'dead_three': 500,
            'live_two': 500,
            'dead_two': 50,
            'center_bonus': 50
        }
    
    def get_info(self) -> Dict[str, Any]:
        """
        Get basic information of the AI player.
        
        Returns:
            Dict containing AI basic information.
        """
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "difficulty": self.difficulty,
            "timeout": self.timeout,
            "capabilities": [
                "position_evaluation",
                "threat_detection", 
                "winning_move_detection",
                "blocking_strategy",
                "pattern_recognition"
            ]
        }
    
    def make_move(self, game_state: Dict[str, Any]) -> List[int]:
        """
        Make a move decision based on the current game state.
        
        Args:
            game_state: Current game state dictionary
            
        Returns:
            Move position [x, y]
        """
        try:
            # Validate game state
            self._validate_game_state(game_state)
            
            board = game_state.get('board', [])
            my_color = game_state.get('my_color', 'black')
            current_player = game_state.get('current_player', 'black')
            self.move_count = game_state.get('round_number', 1)
            
            # Check if it's my turn
            if current_player != my_color:
                raise ValueError(f"Not my turn: current_player={current_player}, my_color={my_color}")
            
            # Convert colors to values
            my_value = 1 if my_color == "black" else 2
            opponent_value = 2 if my_color == "black" else 1
            
            # If it's the first move, choose the center
            if self._is_first_move(board):
                center = self.board_size // 2
                return [center, center]
            
            # Check for immediate winning moves
            winning_move = self._find_winning_move(board, my_value)
            if winning_move:
                return winning_move
            
            # Check for immediate blocking moves
            blocking_move = self._find_winning_move(board, opponent_value)
            if blocking_move:
                return blocking_move
            
            # Use heuristic evaluation for strategic decision
            best_move = self._heuristic_search(board, my_value, opponent_value)
            
            # Validate the move
            self._validate_move(board, best_move)
            
            return best_move
            
        except Exception as e:
            # Fallback to safe random move on error
            print(f"AI decision error: {e}")
            return self._get_safe_random_move(game_state.get('board', []))
    
    def _validate_game_state(self, game_state: Dict[str, Any]) -> None:
        """Validate the game state."""
        if not isinstance(game_state, dict):
            raise ValueError("Game state must be a dict")
        
        if 'board' not in game_state:
            raise ValueError("Game state is missing board information")
        
        board = game_state['board']
        if not isinstance(board, list) or len(board) != self.board_size:
            raise ValueError(f"Invalid board size; expected {self.board_size}x{self.board_size}")
        
        for row in board:
            if not isinstance(row, list) or len(row) != self.board_size:
                raise ValueError(f"Invalid row size; expected {self.board_size}")
    
    def _is_first_move(self, board: List[List[int]]) -> bool:
        """Check if it is the first move."""
        for row in board:
            for cell in row:
                if cell != 0:
                    return False
        return True
    
    def _find_winning_move(self, board: List[List[int]], player_value: int) -> Optional[List[int]]:
        """
        Find a move that results in an immediate win.
        
        Args:
            board: Board state
            player_value: Player value (1=black, 2=white)
            
        Returns:
            Winning position [x, y], or None if none exists
        """
        candidates = self._get_candidate_positions(board)
        
        for x, y in candidates:
            if board[x][y] == 0:
                board[x][y] = player_value
                if self._check_win(board, x, y, player_value):
                    board[x][y] = 0
                    return [x, y]
                board[x][y] = 0
        
        return None
    
    def _check_win(self, board: List[List[int]], x: int, y: int, player_value: int) -> bool:
        """
        Check if placing at the specified position results in a win.
        
        Args:
            board: Board state
            x, y: Position to check
            player_value: Player value
            
        Returns:
            True if it results in a win
        """
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        
        for dx, dy in directions:
            count = 1
            
            # Forward direction
            nx, ny = x + dx, y + dy
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
                   board[nx][ny] == player_value):
                count += 1
                nx, ny = nx + dx, ny + dy
            
            # Reverse direction
            nx, ny = x - dx, y - dy
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
                   board[nx][ny] == player_value):
                count += 1
                nx, ny = nx - dx, ny - dy
            
            if count >= 5:
                return True
        
        return False
    
    def _heuristic_search(self, board: List[List[int]], my_value: int, opponent_value: int) -> List[int]:
        """
        Perform heuristic search to find the best move.
        
        Args:
            board: Current board state
            my_value: My piece value
            opponent_value: Opponent piece value
            
        Returns:
            Best move position [x, y]
        """
        best_score = -float('inf')
        best_move = None
        candidates = self._get_candidate_positions(board)
        
        # Order moves by heuristic value for better selection
        candidate_scores = []
        for x, y in candidates:
            if board[x][y] == 0:
                score = self._evaluate_position_heuristic(board, x, y, my_value, opponent_value)
                candidate_scores.append((score, (x, y)))
        
        # Sort by score in descending order (best moves first)
        candidate_scores.sort(key=lambda x: x[0], reverse=True)
        ordered_candidates = [pos for _, pos in candidate_scores]
        
        # Select the best candidate
        if ordered_candidates:
            best_move = list(ordered_candidates[0])
        else:
            best_move = self._get_safe_random_move(board)
        
        return best_move
    
    def _evaluate_position_heuristic(self, board: List[List[int]], x: int, y: int, 
                                   my_value: int, opponent_value: int) -> float:
        """
        Fast heuristic evaluation for move selection.
        
        Args:
            board: Board state
            x, y: Position to evaluate
            my_value: My piece value
            opponent_value: Opponent piece value
            
        Returns:
            Heuristic score
        """
        if board[x][y] != 0:
            return -1000000
        
        score = 0.0
        
        # Center bonus
        center_x, center_y = self.board_size // 2, self.board_size // 2
        distance_to_center = abs(x - center_x) + abs(y - center_y)
        score += max(0, 50 - distance_to_center * 3)
        
        # Check immediate threats and opportunities
        temp_board = [row[:] for row in board]
        temp_board[x][y] = my_value
        
        # Check if this creates a winning opportunity
        if self._would_create_four(temp_board, x, y, my_value):
            score += 10000
        
        # Check if this blocks opponent threats
        temp_board[x][y] = opponent_value
        if self._would_create_four(temp_board, x, y, opponent_value):
            score += 8000
        temp_board[x][y] = 0
        
        # Check nearby pieces
        for dx in range(-2, 3):
            for dy in range(-2, 3):
                nx, ny = x + dx, y + dy
                if (0 <= nx < self.board_size and 0 <= ny < self.board_size and
                    (dx != 0 or dy != 0)):
                    if board[nx][ny] == my_value:
                        score += 10
                    elif board[nx][ny] == opponent_value:
                        score += 5
        
        return score
    
    def _would_create_four(self, board: List[List[int]], x: int, y: int, player_value: int) -> bool:
        """Check if placing at (x,y) would create a four-in-a-row threat."""
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        
        for dx, dy in directions:
            count = 1
            
            # Forward
            nx, ny = x + dx, y + dy
            empty_count = 0
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
                   (board[nx][ny] == player_value or (board[nx][ny] == 0 and empty_count < 1))):
                if board[nx][ny] == player_value:
                    count += 1
                elif board[nx][ny] == 0:
                    empty_count += 1
                nx, ny = nx + dx, ny + dy
            
            # Reverse
            nx, ny = x - dx, y - dy
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
                   (board[nx][ny] == player_value or (board[nx][ny] == 0 and empty_count < 1))):
                if board[nx][ny] == player_value:
                    count += 1
                elif board[nx][ny] == 0:
                    empty_count += 1
                nx, ny = nx - dx, ny - dy
            
            if count >= 4 and empty_count <= 1:
                return True
        
        return False
    
    def _get_candidate_positions(self, board: List[List[int]]) -> List[Tuple[int, int]]:
        """
        Get candidate move positions around existing pieces.
        
        Args:
            board: Board state
            
        Returns:
            List of candidate positions
        """
        candidates = set()
        radius = self.candidate_radius
        
        # If board is mostly empty, expand search radius
        piece_count = sum(sum(1 for cell in row if cell != 0) for row in board)
        if piece_count < 10:
            radius = max(radius, 4)
        
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] != 0:
                    for di in range(-radius, radius + 1):
                        for dj in range(-radius, radius + 1):
                            ni, nj = i + di, j + dj
                            if (0 <= ni < self.board_size and 
                                0 <= nj < self.board_size and 
                                board[ni][nj] == 0):
                                candidates.add((ni, nj))
        
        # If no candidates found (shouldn't happen in normal games), add all empty positions
        if not candidates:
            for i in range(self.board_size):
                for j in range(self.board_size):
                    if board[i][j] == 0:
                        candidates.add((i, j))
        
        return list(candidates)
    
    def _validate_move(self, board: List[List[int]], move: List[int]) -> None:
        """Validate the move position."""
        if not isinstance(move, list) or len(move) != 2:
            raise ValueError("Move must be a list of length 2")
        
        x, y = move
        if not (0 <= x < self.board_size and 0 <= y < self.board_size):
            raise ValueError(f"Move out of board range: ({x}, {y})")
        
        if board[x][y] != 0:
            raise ValueError(f"Move position already occupied: ({x}, {y})")
    
    def _get_safe_random_move(self, board: List[List[int]]) -> List[int]:
        """Get a safe random move position."""
        empty_positions = []
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == 0:
                    empty_positions.append([i, j])
        
        if empty_positions:
            # Prefer center positions for random moves
            center = self.board_size // 2
            empty_positions.sort(
                key=lambda pos: abs(pos[0] - center) + abs(pos[1] - center)
            )
            return empty_positions[0]
        else:
            center = self.board_size // 2
            return [center, center]