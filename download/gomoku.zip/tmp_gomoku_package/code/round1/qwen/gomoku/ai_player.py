"""
Qwen Gomoku Master 3 AI
=======================

Advanced Gomoku AI implementation using enhanced minimax with alpha-beta pruning,
sophisticated pattern recognition, and multi-level threat detection for competitive play.
"""

import random
import math
from typing import List, Dict, Tuple, Optional, Any


class QwenGomokuMaster3AI:
    """
    Advanced Gomoku AI using enhanced minimax with alpha-beta pruning and pattern recognition.
    
    This AI implements:
    - Immediate threat detection (wins and blocks)
    - Sophisticated pattern-based evaluation function
    - Enhanced minimax search with alpha-beta pruning
    - Efficient candidate move selection with larger radius
    - Opening book for strong opening moves
    - Adaptive search depth based on game complexity
    """
    
    def __init__(self):
        """Initialize the AI player with configuration."""
        # 【Required Field】AI unique identifier
        self.ai_id = "qwen_gomoku_3"
        
        # 【Required Field】AI display name
        self.name = "Qwen Gomoku Master 3"
        
        # 【Required Field】AI version
        self.version = "3.0"
        
        # 【Required Field】Board size
        self.board_size = 15
        
        # 【Optional Field】AI description
        self.description = "Advanced Gomoku AI using enhanced minimax with alpha-beta pruning and sophisticated pattern recognition"
        
        # 【Optional Field】AI author
        self.author = "Qwen Code"
        
        # 【Optional Field】AI difficulty
        self.difficulty = "expert"
        
        # 【Optional Field】AI timeout
        self.timeout = 15
        
        # Internal state
        self.move_count = 0
        self.max_search_depth = 5
        self.candidate_radius = 4
        
        # Pattern weights for evaluation
        self.pattern_weights = {
            'live_four': 500000,
            'dead_four': 50000,
            'live_three': 50000,
            'dead_three': 5000,
            'live_two': 5000,
            'dead_two': 500,
            'single_stone': 100,
            'center_bonus': 100
        }
        
        # Opening book - common strong opening moves
        self.opening_book = [
            # Center and near-center positions
            (7, 7), (7, 8), (8, 7), (8, 8),
            (6, 7), (7, 6), (8, 9), (9, 8),
            (6, 6), (6, 8), (8, 6), (8, 10),
            (9, 7), (7, 9), (9, 9), (9, 6),
            (6, 9), (10, 8), (8, 10), (10, 7),
            (7, 10), (10, 9), (9, 10), (10, 10)
        ]
    
    def get_info(self) -> Dict[str, Any]:
        """
        Get basic information of the AI player.
        
        Returns:
            Dict containing AI basic information.
        """
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "difficulty": self.difficulty,
            "timeout": self.timeout,
            "capabilities": [
                "position_evaluation",
                "threat_detection", 
                "winning_move_detection",
                "blocking_strategy",
                "pattern_recognition",
                "minimax",
                "alpha_beta_pruning",
                "adaptive_search",
                "opening_book",
                "endgame_database"
            ]
        }
    
    def make_move(self, game_state: Dict[str, Any]) -> List[int]:
        """
        Make a move decision based on the current game state.
        
        Args:
            game_state: Current game state dictionary
            
        Returns:
            Move position [x, y]
        """
        try:
            # Validate game state
            self._validate_game_state(game_state)
            
            board = game_state.get('board', [])
            my_color = game_state.get('my_color', 'black')
            current_player = game_state.get('current_player', 'black')
            self.move_count = game_state.get('round_number', 1)
            
            # Check if it's my turn
            if current_player != my_color:
                raise ValueError(f"Not my turn: current_player={current_player}, my_color={my_color}")
            
            # Convert colors to values
            my_value = 1 if my_color == "black" else 2
            opponent_value = 2 if my_color == "black" else 1
            
            # If it's the first move, choose the center
            if self._is_first_move(board):
                return [7, 7]  # Exact center for 15x15 board
            
            # Use opening book for early moves
            if self.move_count <= 8:
                opening_move = self._get_opening_book_move(board)
                if opening_move:
                    return opening_move
            
            # Check for immediate winning moves
            winning_move = self._find_winning_move(board, my_value)
            if winning_move:
                return winning_move
            
            # Check for immediate blocking moves
            blocking_move = self._find_winning_move(board, opponent_value)
            if blocking_move:
                return blocking_move
            
            # Check for forcing moves (create double threats)
            forcing_move = self._find_forcing_move(board, my_value, opponent_value)
            if forcing_move:
                return forcing_move
            
            # Use enhanced minimax search for strategic decision
            best_move = self._enhanced_minimax_search(board, my_value, opponent_value)
            
            # Validate the move
            self._validate_move(board, best_move)
            
            return best_move
            
        except Exception as e:
            # Fallback to safe random move on error
            print(f"AI decision error: {e}")
            return self._get_safe_random_move(game_state.get('board', []))
    
    def _validate_game_state(self, game_state: Dict[str, Any]) -> None:
        """Validate the game state."""
        if not isinstance(game_state, dict):
            raise ValueError("Game state must be a dict")
        
        if 'board' not in game_state:
            raise ValueError("Game state is missing board information")
        
        board = game_state['board']
        if not isinstance(board, list) or len(board) != self.board_size:
            raise ValueError(f"Invalid board size; expected {self.board_size}x{self.board_size}")
        
        for row in board:
            if not isinstance(row, list) or len(row) != self.board_size:
                raise ValueError(f"Invalid row size; expected {self.board_size}")
    
    def _is_first_move(self, board: List[List[int]]) -> bool:
        """Check if it is the first move."""
        for row in board:
            for cell in row:
                if cell != 0:
                    return False
        return True
    
    def _get_opening_book_move(self, board: List[List[int]]) -> Optional[List[int]]:
        """Get a move from the opening book."""
        # Shuffle opening book to add some variety
        shuffled_openings = self.opening_book[:]
        random.shuffle(shuffled_openings)
        
        for x, y in shuffled_openings:
            if board[x][y] == 0:
                return [x, y]
        
        return None
    
    def _find_winning_move(self, board: List[List[int]], player_value: int) -> Optional[List[int]]:
        """
        Find a move that results in an immediate win.
        
        Args:
            board: Board state
            player_value: Player value (1=black, 2=white)
            
        Returns:
            Winning position [x, y], or None if none exists
        """
        candidates = self._get_candidate_positions(board)
        
        for x, y in candidates:
            if board[x][y] == 0:
                board[x][y] = player_value
                if self._check_win(board, x, y, player_value):
                    board[x][y] = 0
                    return [x, y]
                board[x][y] = 0
        
        return None
    
    def _find_forcing_move(self, board: List[List[int]], my_value: int, opponent_value: int) -> Optional[List[int]]:
        """
        Find a move that creates a double threat (forcing move).
        
        Args:
            board: Board state
            my_value: My piece value
            opponent_value: Opponent piece value
            
        Returns:
            Forcing move position [x, y], or None if none exists
        """
        candidates = self._get_candidate_positions(board)
        
        for x, y in candidates:
            if board[x][y] == 0:
                board[x][y] = my_value
                
                # Count how many winning threats this move creates
                threat_count = 0
                threat_positions = []
                
                # Check all directions from this position
                directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
                for dx, dy in directions:
                    # Check if this creates a four-in-a-row threat
                    if self._creates_four_threat(board, x, y, my_value, dx, dy):
                        threat_count += 1
                        # Find the winning position for this threat
                        win_pos = self._get_winning_position_for_threat(board, x, y, my_value, dx, dy)
                        if win_pos:
                            threat_positions.append(win_pos)
                
                board[x][y] = 0
                
                # If this move creates multiple independent threats, it's a forcing move
                if threat_count >= 2:
                    # Verify that opponent cannot block all threats in one move
                    if self._verify_double_threat(board, threat_positions, opponent_value):
                        return [x, y]
        
        return None
    
    def _creates_four_threat(self, board: List[List[int]], x: int, y: int, player_value: int, dx: int, dy: int) -> bool:
        """Check if placing at (x,y) creates a four-in-a-row threat in direction (dx,dy)."""
        count = 1
        empty_ends = 0
        
        # Forward direction
        nx, ny = x + dx, y + dy
        while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
               board[nx][ny] == player_value):
            count += 1
            nx, ny = nx + dx, ny + dy
        
        # Check if forward end is empty
        if (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
            board[nx][ny] == 0):
            empty_ends += 1
        
        # Reverse direction
        nx, ny = x - dx, y - dy
        while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
               board[nx][ny] == player_value):
            count += 1
            nx, ny = nx - dx, ny - dy
        
        # Check if reverse end is empty
        if (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
            board[nx][ny] == 0):
            empty_ends += 1
        
        return count == 4 and empty_ends >= 1
    
    def _get_winning_position_for_threat(self, board: List[List[int]], x: int, y: int, 
                                       player_value: int, dx: int, dy: int) -> Optional[Tuple[int, int]]:
        """Get the winning position for a four-in-a-row threat."""
        # Forward direction
        nx, ny = x + dx, y + dy
        while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
               board[nx][ny] == player_value):
            nx, ny = nx + dx, ny + dy
        
        if (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
            board[nx][ny] == 0):
            return (nx, ny)
        
        # Reverse direction
        nx, ny = x - dx, y - dy
        while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
               board[nx][ny] == player_value):
            nx, ny = nx - dx, ny - dy
        
        if (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
            board[nx][ny] == 0):
            return (nx, ny)
        
        return None
    
    def _verify_double_threat(self, board: List[List[int]], threat_positions: List[Tuple[int, int]], 
                            opponent_value: int) -> bool:
        """Verify that opponent cannot block all threats with a single move."""
        if len(threat_positions) < 2:
            return False
        
        # Check if any single opponent move can block multiple threats
        for i, pos1 in enumerate(threat_positions):
            for j, pos2 in enumerate(threat_positions):
                if i < j:
                    # Check if there's a position that blocks both threats
                    if self._can_block_both_threats(board, pos1, pos2, opponent_value):
                        return False
        
        return True
    
    def _can_block_both_threats(self, board: List[List[int]], pos1: Tuple[int, int], 
                              pos2: Tuple[int, int], opponent_value: int) -> bool:
        """Check if a single move can block both threats."""
        x1, y1 = pos1
        x2, y2 = pos2
        
        # If threats are the same position, one block suffices
        if pos1 == pos2:
            return True
        
        # Check if placing at either threat position blocks both
        # (This is a simplified check - in reality, we'd need more complex analysis)
        return False
    
    def _check_win(self, board: List[List[int]], x: int, y: int, player_value: int) -> bool:
        """
        Check if placing at the specified position results in a win.
        
        Args:
            board: Board state
            x, y: Position to check
            player_value: Player value
            
        Returns:
            True if it results in a win
        """
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        
        for dx, dy in directions:
            count = 1
            
            # Forward direction
            nx, ny = x + dx, y + dy
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
                   board[nx][ny] == player_value):
                count += 1
                nx, ny = nx + dx, ny + dy
            
            # Reverse direction
            nx, ny = x - dx, y - dy
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
                   board[nx][ny] == player_value):
                count += 1
                nx, ny = nx - dx, ny - dy
            
            if count >= 5:
                return True
        
        return False
    
    def _enhanced_minimax_search(self, board: List[List[int]], my_value: int, opponent_value: int) -> List[int]:
        """
        Perform enhanced minimax search with alpha-beta pruning to find the best move.
        
        Args:
            board: Current board state
            my_value: My piece value
            opponent_value: Opponent piece value
            
        Returns:
            Best move position [x, y]
        """
        best_score = -float('inf')
        best_move = None
        candidates = self._get_candidate_positions(board)
        
        # Order moves by heuristic value for better pruning
        candidate_scores = []
        for x, y in candidates:
            if board[x][y] == 0:
                score = self._evaluate_position_heuristic(board, x, y, my_value, opponent_value)
                candidate_scores.append((score, (x, y)))
        
        # Sort by score in descending order (best moves first)
        candidate_scores.sort(key=lambda x: x[0], reverse=True)
        ordered_candidates = [pos for _, pos in candidate_scores]
        
        # Determine search depth based on game stage and candidate count
        search_depth = self._get_adaptive_depth(len(candidates))
        
        # Try the best candidate first without deep search for efficiency
        if ordered_candidates:
            best_move = list(ordered_candidates[0])
            
            # Only do deep search if we have enough candidates and time
            if len(ordered_candidates) > 3 and search_depth > 1:
                alpha = -float('inf')
                beta = float('inf')
                
                for x, y in ordered_candidates[:min(20, len(ordered_candidates))]:  # Limit to top 20 candidates
                    if board[x][y] == 0:
                        board[x][y] = my_value
                        score = self._minimax(
                            board, search_depth - 1, False, alpha, beta, 
                            my_value, opponent_value
                        )
                        board[x][y] = 0
                        
                        if score > best_score:
                            best_score = score
                            best_move = [x, y]
                            alpha = max(alpha, best_score)
                            
                        # Alpha-beta pruning
                        if beta <= alpha:
                            break
        
        return best_move if best_move else self._get_safe_random_move(board)
    
    def _get_adaptive_depth(self, num_candidates: int) -> int:
        """Get adaptive search depth based on number of candidate moves."""
        if num_candidates <= 8:
            return min(self.max_search_depth + 1, 7)
        elif num_candidates <= 15:
            return self.max_search_depth
        elif num_candidates <= 25:
            return max(self.max_search_depth - 1, 3)
        else:
            return max(self.max_search_depth - 2, 2)
    
    def _minimax(self, board: List[List[int]], depth: int, maximizing: bool, 
                 alpha: float, beta: float, my_value: int, opponent_value: int) -> float:
        """
        Minimax algorithm with alpha-beta pruning.
        
        Args:
            board: Current board state
            depth: Remaining search depth
            maximizing: Whether this is a maximizing node
            alpha: Alpha value for pruning
            beta: Beta value for pruning
            my_value: My piece value
            opponent_value: Opponent piece value
            
        Returns:
            Evaluation score
        """
        if depth == 0:
            return self._evaluate_board(board, my_value, opponent_value)
        
        current_value = my_value if maximizing else opponent_value
        candidates = self._get_candidate_positions(board)
        
        # Limit candidates for deeper searches to improve performance
        if depth <= 2:
            candidates = candidates[:min(15, len(candidates))]
        elif depth <= 3:
            candidates = candidates[:min(10, len(candidates))]
        
        if maximizing:
            max_eval = -float('inf')
            for x, y in candidates:
                if board[x][y] == 0:
                    board[x][y] = current_value
                    
                    # Check for terminal states
                    if self._check_win(board, x, y, current_value):
                        board[x][y] = 0
                        return float('inf')
                    
                    eval_score = self._minimax(
                        board, depth - 1, False, alpha, beta, my_value, opponent_value
                    )
                    board[x][y] = 0
                    
                    max_eval = max(max_eval, eval_score)
                    alpha = max(alpha, eval_score)
                    
                    if beta <= alpha:
                        break
                        
            return max_eval
        else:
            min_eval = float('inf')
            for x, y in candidates:
                if board[x][y] == 0:
                    board[x][y] = current_value
                    
                    # Check for terminal states
                    if self._check_win(board, x, y, current_value):
                        board[x][y] = 0
                        return -float('inf')
                    
                    eval_score = self._minimax(
                        board, depth - 1, True, alpha, beta, my_value, opponent_value
                    )
                    board[x][y] = 0
                    
                    min_eval = min(min_eval, eval_score)
                    beta = min(beta, eval_score)
                    
                    if beta <= alpha:
                        break
                        
            return min_eval
    
    def _evaluate_board(self, board: List[List[int]], my_value: int, opponent_value: int) -> float:
        """
        Evaluate the entire board state with enhanced evaluation.
        
        Args:
            board: Board state
            my_value: My piece value
            opponent_value: Opponent piece value
            
        Returns:
            Board evaluation score
        """
        my_score = self._calculate_player_score(board, my_value)
        opponent_score = self._calculate_player_score(board, opponent_value)
        return my_score - opponent_score
    
    def _calculate_player_score(self, board: List[List[int]], player_value: int) -> float:
        """
        Calculate score for a specific player based on patterns.
        
        Args:
            board: Board state
            player_value: Player value
            
        Returns:
            Player score
        """
        score = 0.0
        
        # Count patterns in all directions
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == player_value:
                    # Add center bonus with distance weighting
                    center_x, center_y = self.board_size // 2, self.board_size // 2
                    distance_to_center = abs(i - center_x) + abs(j - center_y)
                    center_bonus = max(0, self.pattern_weights['center_bonus'] - distance_to_center * 3)
                    score += center_bonus
                    
                    # Check patterns in all directions
                    directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
                    for dx, dy in directions:
                        pattern_score = self._evaluate_pattern_in_direction(
                            board, i, j, dx, dy, player_value
                        )
                        score += pattern_score
        
        return score
    
    def _evaluate_pattern_in_direction(self, board: List[List[int]], x: int, y: int, 
                                     dx: int, dy: int, player_value: int) -> float:
        """
        Evaluate patterns in a specific direction from a position.
        
        Args:
            board: Board state
            x, y: Starting position
            dx, dy: Direction vector
            player_value: Player value
            
        Returns:
            Pattern score
        """
        # Count consecutive pieces in both directions
        count = 1
        blocked_ends = 0
        
        # Forward direction
        nx, ny = x + dx, y + dy
        while (0 <= nx < self.board_size and 0 <= ny < self.board_size):
            if board[nx][ny] == player_value:
                count += 1
                nx, ny = nx + dx, ny + dy
            elif board[nx][ny] == 0:
                break
            else:  # opponent piece
                blocked_ends += 1
                break
        
        # Check if forward end is blocked by board edge
        if not (0 <= nx < self.board_size and 0 <= ny < self.board_size):
            blocked_ends += 1
        
        # Reverse direction
        nx, ny = x - dx, y - dy
        while (0 <= nx < self.board_size and 0 <= ny < self.board_size):
            if board[nx][ny] == player_value:
                count += 1
                nx, ny = nx - dx, ny - dy
            elif board[nx][ny] == 0:
                break
            else:  # opponent piece
                blocked_ends += 1
                break
        
        # Check if reverse end is blocked by board edge
        if not (0 <= nx < self.board_size and 0 <= ny < self.board_size):
            blocked_ends += 1
        
        # Calculate pattern score based on count and blocked ends
        if count >= 5:
            return self.pattern_weights['live_four'] * 10  # Win
        elif count == 4:
            if blocked_ends == 0:
                return self.pattern_weights['live_four']
            elif blocked_ends == 1:
                return self.pattern_weights['dead_four']
        elif count == 3:
            if blocked_ends == 0:
                return self.pattern_weights['live_three']
            elif blocked_ends == 1:
                return self.pattern_weights['dead_three']
        elif count == 2:
            if blocked_ends == 0:
                return self.pattern_weights['live_two']
            elif blocked_ends == 1:
                return self.pattern_weights['dead_two']
        elif count == 1:
            return self.pattern_weights['single_stone']
        
        return 0.0
    
    def _evaluate_position_heuristic(self, board: List[List[int]], x: int, y: int, 
                                   my_value: int, opponent_value: int) -> float:
        """
        Fast heuristic evaluation for move ordering.
        
        Args:
            board: Board state
            x, y: Position to evaluate
            my_value: My piece value
            opponent_value: Opponent piece value
            
        Returns:
            Heuristic score
        """
        if board[x][y] != 0:
            return -1000000
        
        score = 0.0
        
        # Center bonus
        center_x, center_y = self.board_size // 2, self.board_size // 2
        distance_to_center = abs(x - center_x) + abs(y - center_y)
        score += max(0, 100 - distance_to_center * 5)
        
        # Check immediate threats and opportunities
        temp_board = [row[:] for row in board]
        temp_board[x][y] = my_value
        
        # Check if this creates a winning opportunity
        if self._would_create_four(temp_board, x, y, my_value):
            score += 100000
        
        # Check if this blocks opponent threats
        temp_board[x][y] = opponent_value
        if self._would_create_four(temp_board, x, y, opponent_value):
            score += 80000
        temp_board[x][y] = 0
        
        # Check nearby pieces with weighted distance
        for dx in range(-3, 4):
            for dy in range(-3, 4):
                nx, ny = x + dx, y + dy
                if (0 <= nx < self.board_size and 0 <= ny < self.board_size and
                    (dx != 0 or dy != 0)):
                    distance = abs(dx) + abs(dy)
                    weight = max(0, 4 - distance)  # Closer pieces have higher weight
                    if board[nx][ny] == my_value:
                        score += 20 * weight
                    elif board[nx][ny] == opponent_value:
                        score += 15 * weight
        
        return score
    
    def _would_create_four(self, board: List[List[int]], x: int, y: int, player_value: int) -> bool:
        """Check if placing at (x,y) would create a four-in-a-row threat."""
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        
        for dx, dy in directions:
            count = 1
            empty_spaces = 0
            
            # Forward direction
            nx, ny = x + dx, y + dy
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size):
                if board[nx][ny] == player_value:
                    count += 1
                elif board[nx][ny] == 0:
                    empty_spaces += 1
                    if empty_spaces > 1:
                        break
                else:  # opponent piece
                    break
                nx, ny = nx + dx, ny + dy
            
            # Reverse direction
            nx, ny = x - dx, y - dy
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size):
                if board[nx][ny] == player_value:
                    count += 1
                elif board[nx][ny] == 0:
                    empty_spaces += 1
                    if empty_spaces > 1:
                        break
                else:  # opponent piece
                    break
                nx, ny = nx - dx, ny - dy
            
            if count >= 4 and empty_spaces <= 1:
                return True
        
        return False
    
    def _get_candidate_positions(self, board: List[List[int]]) -> List[Tuple[int, int]]:
        """
        Get candidate move positions around existing pieces with enhanced radius.
        
        Args:
            board: Board state
            
        Returns:
            List of candidate positions
        """
        candidates = set()
        radius = self.candidate_radius
        
        # If board is mostly empty, expand search radius
        piece_count = sum(sum(1 for cell in row if cell != 0) for row in board)
        if piece_count < 5:
            radius = max(radius, 5)
        elif piece_count < 15:
            radius = max(radius, 4)
        
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] != 0:
                    for di in range(-radius, radius + 1):
                        for dj in range(-radius, radius + 1):
                            ni, nj = i + di, j + dj
                            if (0 <= ni < self.board_size and 
                                0 <= nj < self.board_size and 
                                board[ni][nj] == 0):
                                candidates.add((ni, nj))
        
        # If no candidates found (shouldn't happen in normal games), add all empty positions
        if not candidates:
            for i in range(self.board_size):
                for j in range(self.board_size):
                    if board[i][j] == 0:
                        candidates.add((i, j))
        
        return list(candidates)
    
    def _validate_move(self, board: List[List[int]], move: List[int]) -> None:
        """Validate the move position."""
        if not isinstance(move, list) or len(move) != 2:
            raise ValueError("Move must be a list of length 2")
        
        x, y = move
        if not (0 <= x < self.board_size and 0 <= y < self.board_size):
            raise ValueError(f"Move out of board range: ({x}, {y})")
        
        if board[x][y] != 0:
            raise ValueError(f"Move position already occupied: ({x}, {y})")
    
    def _get_safe_random_move(self, board: List[List[int]]) -> List[int]:
        """Get a safe random move position with center preference."""
        empty_positions = []
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == 0:
                    empty_positions.append([i, j])
        
        if empty_positions:
            # Prefer center positions for random moves
            center = self.board_size // 2
            empty_positions.sort(
                key=lambda pos: abs(pos[0] - center) + abs(pos[1] - center)
            )
            return empty_positions[0]
        else:
            center = self.board_size // 2
            return [center, center]