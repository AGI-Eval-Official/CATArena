#!/usr/bin/env python3
"""
Debug script to test candidate positions
"""

from ai_player import QwenGomokuMaster3AI

def test_candidates():
    ai = QwenGomokuMaster3AI()
    
    # Create test board with four in a row
    test_board = [[0 for _ in range(15)] for _ in range(15)]
    for i in range(4):
        test_board[7][7 + i] = 1  # Black stones at (7,7), (7,8), (7,9), (7,10)
    
    candidates = ai._get_candidate_positions(test_board)
    print(f"Number of candidates: {len(candidates)}")
    
    # Check if winning positions are in candidates
    winning_positions = [(7, 6), (7, 11)]
    for pos in winning_positions:
        if pos in candidates:
            print(f"Winning position {pos} is in candidates")
        else:
            print(f"Winning position {pos} is NOT in candidates")
    
    # Print some candidates near the winning area
    print("Candidates near winning positions:")
    for i in range(5, 13):
        for j in range(5, 13):
            if (i, j) in candidates and test_board[i][j] == 0:
                print(f"  ({i}, {j})")

if __name__ == "__main__":
    test_candidates()