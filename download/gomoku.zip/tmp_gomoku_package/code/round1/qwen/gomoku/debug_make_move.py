#!/usr/bin/env python3
"""
Debug script to test make_move with winning detection
"""

from ai_player import QwenGomokuMaster3AI

def test_make_move_winning():
    ai = QwenGomokuMaster3AI()
    
    # Create test board with four in a row
    test_board = [[0 for _ in range(15)] for _ in range(15)]
    for i in range(4):
        test_board[7][7 + i] = 1  # Black stones at (7,7), (7,8), (7,9), (7,10)
    
    test_game_state = {
        'board': test_board,
        'current_player': 'black',
        'my_color': 'black',
        'move_history': [],
        'game_id': 'test_game',
        'round_number': 5
    }
    
    move = ai.make_move(test_game_state)
    print(f"make_move returned: {move}")
    
    # Check if it's a winning move
    test_board[move[0]][move[1]] = 1
    is_win = ai._check_win(test_board, move[0], move[1], 1)
    print(f"Move {move} results in win: {is_win}")

if __name__ == "__main__":
    test_make_move_winning()