#!/usr/bin/env python3
"""
Gomoku AI Player Test Script for Qwen Gomoku Master 3
=====================================================

This script tests the Qwen Gomoku Master 3 AI implementation.
"""

import sys
import os
import yaml
import time
import traceback
from typing import Dict, List, Any

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from ai_player import QwenGomokuMaster3AI
except ImportError as e:
    print(f"❌ Failed to import AI module: {e}")
    print("Please ensure ai_player.py exists and the syntax is correct")
    sys.exit(1)


class AITester:
    """AI Player Tester for Qwen Gomoku Master 3"""
    
    def __init__(self):
        self.test_results = []
        self.ai_instance = None
    
    def log_test(self, test_name: str, passed: bool, message: str = ""):
        """Record test result"""
        status = "✅ Passed" if passed else "❌ Failed"
        result = {
            "test": test_name,
            "passed": passed,
            "message": message
        }
        self.test_results.append(result)
        print(f"{status} {test_name}: {message}")
    
    def test_ai_initialization(self) -> bool:
        """Test AI initialization"""
        print("\n🔧 Testing AI initialization...")
        
        try:
            ai = QwenGomokuMaster3AI()
            
            # Check required fields
            required_fields = [
                'ai_id', 'name', 'version', 'board_size', 
                'description', 'author', 'difficulty', 'timeout'
            ]
            
            for field in required_fields:
                if not hasattr(ai, field):
                    self.log_test("Initialization Check", False, f"Missing required field: {field}")
                    return False
                
                value = getattr(ai, field)
                if value is None or value == "":
                    self.log_test("Initialization Check", False, f"Field {field} cannot be empty")
                    return False
            
            # Check specific values
            if ai.ai_id != "qwen_gomoku_3":
                self.log_test("Initialization Check", False, f"Expected ai_id 'qwen_gomoku_3', got '{ai.ai_id}'")
                return False
            
            if ai.board_size != 15:
                self.log_test("Initialization Check", False, f"Expected board_size 15, got {ai.board_size}")
                return False
            
            self.ai_instance = ai
            self.log_test("Initialization Check", True, "All required fields are correctly set")
            return True
            
        except Exception as e:
            self.log_test("Initialization Check", False, f"Initialization error: {str(e)}")
            return False
    
    def test_get_info_method(self) -> bool:
        """Test get_info method"""
        print("\n📋 Testing get_info method...")
        
        if not self.ai_instance:
            self.log_test("get_info Method", False, "AI instance not initialized")
            return False
        
        try:
            info = self.ai_instance.get_info()
            
            # Check return type
            if not isinstance(info, dict):
                self.log_test("get_info Method", False, "Return value must be a dictionary")
                return False
            
            # Check required fields
            required_fields = [
                'ai_id', 'name', 'version', 'description', 
                'author', 'difficulty', 'timeout'
            ]
            
            for field in required_fields:
                if field not in info:
                    self.log_test("get_info Method", False, f"Returned dict missing field: {field}")
                    return False
            
            # Check specific values
            if info['ai_id'] != "qwen_gomoku_3":
                self.log_test("get_info Method", False, f"Expected ai_id 'qwen_gomoku_3', got '{info['ai_id']}'")
                return False
            
            if info['timeout'] != 15:
                self.log_test("get_info Method", False, f"Expected timeout 15, got {info['timeout']}")
                return False
            
            self.log_test("get_info Method", True, f"Returned correct AI info: {info['name']}")
            return True
            
        except Exception as e:
            self.log_test("get_info Method", False, f"Method call exception: {str(e)}")
            return False
    
    def test_make_move_method(self) -> bool:
        """Test make_move method"""
        print("\n🎯 Testing make_move method...")
        
        if not self.ai_instance:
            self.log_test("make_move Method", False, "AI instance not initialized")
            return False
        
        try:
            # Create test game state - empty board
            test_board = [[0 for _ in range(15)] for _ in range(15)]
            test_game_state = {
                'board': test_board,
                'current_player': 'black',
                'my_color': 'black',
                'move_history': [],
                'game_id': 'test_game',
                'round_number': 1
            }
            
            # First move (empty board)
            start_time = time.time()
            move = self.ai_instance.make_move(test_game_state)
            end_time = time.time()
            
            decision_time = end_time - start_time
            
            # Check return format
            if not isinstance(move, list) or len(move) != 2:
                self.log_test("make_move Method", False, "Return value must be a list of length 2")
                return False
            
            x, y = move
            if not isinstance(x, int) or not isinstance(y, int):
                self.log_test("make_move Method", False, "Coordinates must be integers")
                return False
            
            if not (0 <= x < 15 and 0 <= y < 15):
                self.log_test("make_move Method", False, f"Coordinates out of range: ({x}, {y})")
                return False
            
            if test_board[x][y] != 0:
                self.log_test("make_move Method", False, f"Selected a non-empty position: ({x}, {y})")
                return False
            
            # Check that first move is center
            if x != 7 or y != 7:
                self.log_test("make_move Method", False, f"First move should be center (7,7), got ({x}, {y})")
                return False
            
            # Check decision time
            if decision_time > self.ai_instance.timeout:
                self.log_test("make_move Method", False, f"Decision time exceeded: {decision_time:.3f}s")
                return False
            
            self.log_test("make_move Method", True, 
                         f"Returned valid center position ({x}, {y}) in {decision_time:.3f}s")
            
            # Test complex scenarios
            return self._test_complex_scenarios()
            
        except Exception as e:
            self.log_test("make_move Method", False, f"Method call exception: {str(e)}")
            traceback.print_exc()
            return False
    
    def _test_complex_scenarios(self) -> bool:
        """Test complex scenarios"""
        print("\n🧩 Testing complex scenarios...")
        
        # Scenario 1: Board with stones
        test_board = [[0 for _ in range(15)] for _ in range(15)]
        test_board[7][7] = 1  # Black
        test_board[7][8] = 2  # White
        
        test_game_state = {
            'board': test_board,
            'current_player': 'black',
            'my_color': 'black',
            'move_history': [[7, 7], [7, 8]],
            'game_id': 'test_game',
            'round_number': 3
        }
        
        try:
            move = self.ai_instance.make_move(test_game_state)
            x, y = move
            
            if test_board[x][y] != 0:
                self.log_test("Complex Scenario Test", False, f"Selected an occupied position: ({x}, {y})")
                return False
            
            self.log_test("Complex Scenario Test", True, f"Correctly handled complex situation, chose ({x}, {y})")
            
        except Exception as e:
            self.log_test("Complex Scenario Test", False, f"Complex scenario handling exception: {str(e)}")
            return False
        
        # Scenario 2: Winning opportunity detection
        return self._test_winning_detection()
    
    def _test_winning_detection(self) -> bool:
        """Test winning detection"""
        print("\n🏆 Testing winning detection...")
        
        # Create a near-winning situation - four in a row horizontally
        test_board = [[0 for _ in range(15)] for _ in range(15)]
        for i in range(4):
            test_board[7][7 + i] = 1  # Black four in a row at positions (7,7) to (7,10)
        
        test_game_state = {
            'board': test_board,
            'current_player': 'black',
            'my_color': 'black',
            'move_history': [],
            'game_id': 'test_game',
            'round_number': 5
        }
        
        try:
            move = self.ai_instance.make_move(test_game_state)
            x, y = move
            
            # Check if a winning position was selected (should be (7,6) or (7,11))
            winning_positions = [(7, 6), (7, 11)]
            if (x, y) in winning_positions:
                self.log_test("Winning Detection", True, f"Correctly identified winning opportunity: ({x}, {y})")
            else:
                self.log_test("Winning Detection", False, f"Did not identify winning opportunity, chose ({x}, {y})")
                # This is not a fatal error, just a hint
            
            return True
            
        except Exception as e:
            self.log_test("Winning Detection", False, f"Winning detection error: {str(e)}")
            return False
    
    def test_config_file(self) -> bool:
        """Test configuration file"""
        print("\n⚙️ Testing configuration file...")
        
        config_file = "ai_config.yaml"
        if not os.path.exists(config_file):
            self.log_test("Configuration File", False, f"Configuration file not found: {config_file}")
            return False
        
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            # Check required fields
            required_fields = [
                'ai_id', 'ai_name', 'version', 'description', 
                'category', 'capabilities', 'author', 'created_at', 
                'timeout', 'difficulty'
            ]
            
            for field in required_fields:
                if field not in config:
                    self.log_test("Configuration File", False, f"Config is missing required field: {field}")
                    return False
            
            # Check specific values
            if config['ai_id'] != "qwen_gomoku_3":
                self.log_test("Configuration File", False, f"Expected ai_id 'qwen_gomoku_3', got '{config['ai_id']}'")
                return False
            
            if config['timeout'] != 15:
                self.log_test("Configuration File", False, f"Expected timeout 15, got {config['timeout']}")
                return False
            
            valid_difficulties = ['easy', 'medium', 'hard', 'expert']
            if config['difficulty'] not in valid_difficulties:
                self.log_test("Configuration File", False, f"difficulty must be one of: {valid_difficulties}")
                return False
            
            self.log_test("Configuration File", True, f"Configuration file format is correct: {config['ai_name']}")
            return True
            
        except yaml.YAMLError as e:
            self.log_test("Configuration File", False, f"YAML format error: {str(e)}")
            return False
        except Exception as e:
            self.log_test("Configuration File", False, f"Configuration file read error: {str(e)}")
            return False
    
    def run_all_tests(self) -> bool:
        """Run all tests"""
        print("🚀 Starting Qwen Gomoku Master 3 AI tests...")
        print("=" * 50)
        
        tests = [
            self.test_ai_initialization,
            self.test_get_info_method,
            self.test_make_move_method,
            self.test_config_file
        ]
        
        all_passed = True
        for test in tests:
            try:
                if not test():
                    all_passed = False
            except Exception as e:
                print(f"❌ Test execution exception: {str(e)}")
                traceback.print_exc()
                all_passed = False
        
        return all_passed
    
    def print_summary(self):
        """Print test summary"""
        print("\n" + "=" * 50)
        print("📊 Test Summary")
        print("=" * 50)
        
        passed_count = sum(1 for result in self.test_results if result['passed'])
        total_count = len(self.test_results)
        
        print(f"Total tests: {total_count}")
        print(f"Passed: {passed_count}")
        print(f"Failed: {total_count - passed_count}")
        print(f"Pass rate: {passed_count / total_count * 100:.1f}%")
        
        if passed_count == total_count:
            print("\n🎉 Congrats! All tests passed!")
            print("Your Qwen Gomoku Master 3 AI is ready for tournament play!")
        else:
            print("\n⚠️ Some tests failed. Please check the following issues:")
            for result in self.test_results:
                if not result['passed']:
                    print(f"  - {result['test']}: {result['message']}")
        
        print("\n📚 Next steps:")
        print("1. Place your AI in the ai_players/gomoku/ directory")
        print("2. Run battle tests against other AIs")
        print("3. Fine-tune parameters based on performance")


def main():
    """Main function"""
    print("Qwen Gomoku Master 3 AI Test Tool")
    print("Author: Qwen Code")
    print("Version: 3.0")
    print()
    
    tester = AITester()
    
    try:
        success = tester.run_all_tests()
        tester.print_summary()
        
        # Return appropriate exit code
        sys.exit(0 if success else 1)
        
    except KeyboardInterrupt:
        print("\n\n⏹️ Test interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n💥 An unexpected error occurred during testing: {str(e)}")
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()