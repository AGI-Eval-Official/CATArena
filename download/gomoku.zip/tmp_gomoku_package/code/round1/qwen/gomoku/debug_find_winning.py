#!/usr/bin/env python3
"""
Debug script to test _find_winning_move directly
"""

from ai_player import QwenGomokuMaster3AI

def test_find_winning_move_direct():
    ai = QwenGomokuMaster3AI()
    
    # Create test board with four in a row
    test_board = [[0 for _ in range(15)] for _ in range(15)]
    for i in range(4):
        test_board[7][7 + i] = 1  # Black stones at (7,7), (7,8), (7,9), (7,10)
    
    print("Testing _find_winning_move directly...")
    winning_move = ai._find_winning_move(test_board, 1)
    print(f"_find_winning_move returned: {winning_move}")
    
    # Let's also test the check_win method on the winning positions
    print("\nTesting _check_win on winning positions:")
    test_board_copy = [row[:] for row in test_board]
    test_board_copy[7][6] = 1
    result1 = ai._check_win(test_board_copy, 7, 6, 1)
    print(f"_check_win((7,6)): {result1}")
    
    test_board_copy = [row[:] for row in test_board]
    test_board_copy[7][11] = 1
    result2 = ai._check_win(test_board_copy, 7, 11, 1)
    print(f"_check_win((7,11)): {result2}")

if __name__ == "__main__":
    test_find_winning_move_direct()