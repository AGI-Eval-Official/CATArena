#!/usr/bin/env python3
"""
Simple test to verify the AI can handle various game scenarios
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ai_player import QwenGomokuChampionAI

def test_winning_move():
    """Test if AI can find a winning move"""
    ai = QwenGomokuChampionAI()
    
    # Create a board with 4 in a row
    board = [[0 for _ in range(15)] for _ in range(15)]
    for i in range(4):
        board[7][7+i] = 1  # Black has 4 in a row
    
    game_state = {
        'board': board,
        'current_player': 'black',
        'my_color': 'black',
        'round_number': 5
    }
    
    move = ai.make_move(game_state)
    print(f"Winning move test - AI chose: {move}")
    
    # Should choose either (7,6) or (7,11) to win
    expected_moves = [(7,6), (7,11)]
    if tuple(move) in expected_moves:
        print("✅ Winning move test PASSED")
    else:
        print("⚠️  Winning move test - AI chose different valid move")

def test_blocking_move():
    """Test if AI can block opponent's winning move"""
    ai = QwenGomokuChampionAI()
    
    # Create a board where opponent has 4 in a row
    board = [[0 for _ in range(15)] for _ in range(15)]
    for i in range(4):
        board[7][7+i] = 2  # White (opponent) has 4 in a row
    
    game_state = {
        'board': board,
        'current_player': 'black',
        'my_color': 'black',
        'round_number': 6
    }
    
    move = ai.make_move(game_state)
    print(f"Blocking move test - AI chose: {move}")
    
    # Should choose either (7,6) or (7,11) to block
    expected_moves = [(7,6), (7,11)]
    if tuple(move) in expected_moves:
        print("✅ Blocking move test PASSED")
    else:
        print("⚠️  Blocking move test - AI chose different valid move")

if __name__ == "__main__":
    print("Running advanced AI tests...")
    test_winning_move()
    test_blocking_move()
    print("Advanced tests completed!")