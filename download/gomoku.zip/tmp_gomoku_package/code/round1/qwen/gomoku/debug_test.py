#!/usr/bin/env python3
"""
Debug script to test winning move detection
"""

from ai_player import QwenGomokuMaster3AI

def test_winning_detection():
    ai = QwenGomokuMaster3AI()
    
    # Create test board with four in a row
    test_board = [[0 for _ in range(15)] for _ in range(15)]
    for i in range(4):
        test_board[7][7 + i] = 1  # Black stones at (7,7), (7,8), (7,9), (7,10)
    
    print("Test board setup:")
    for i in range(5, 12):
        row_str = ""
        for j in range(5, 12):
            if test_board[i][j] == 1:
                row_str += "B "
            elif test_board[i][j] == 2:
                row_str += "W "
            else:
                row_str += ". "
        print(row_str)
    
    # Test winning move detection directly
    winning_move = ai._find_winning_move(test_board, 1)
    print(f"Winning move found: {winning_move}")
    
    # Test check_win method directly
    test_board[7][6] = 1
    is_win = ai._check_win(test_board, 7, 6, 1)
    print(f"Placing at (7,6) results in win: {is_win}")
    test_board[7][6] = 0
    
    test_board[7][11] = 1
    is_win = ai._check_win(test_board, 7, 11, 1)
    print(f"Placing at (7,11) results in win: {is_win}")
    test_board[7][11] = 0

if __name__ == "__main__":
    test_winning_detection()