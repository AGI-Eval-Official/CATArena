"""
Test script for Claude Sonnet 4.5 Gomoku Elite AI
"""

import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ai_player import ClaudeSonnet45GomokuEliteAI


def test_initialization():
    """Test AI initialization."""
    print("Testing AI initialization...")
    ai = ClaudeSonnet45GomokuEliteAI()

    assert ai.ai_id == "claude_sonnet_4_5_AI", "AI ID mismatch"
    assert ai.name == "Claude Sonnet 4.5 Elite", "AI name mismatch"
    assert ai.board_size == 15, "Board size mismatch"

    print("✓ Initialization test passed")
    return ai


def test_get_info(ai):
    """Test get_info method."""
    print("\nTesting get_info method...")
    info = ai.get_info()

    assert isinstance(info, dict), "Info must be a dict"
    assert "ai_id" in info, "Info must contain ai_id"
    assert "name" in info, "Info must contain name"
    assert "capabilities" in info, "Info must contain capabilities"

    print(f"AI Name: {info['name']}")
    print(f"Version: {info['version']}")
    print(f"Capabilities: {', '.join(info['capabilities'][:3])}...")
    print("✓ get_info test passed")


def test_first_move(ai):
    """Test first move (empty board)."""
    print("\nTesting first move...")

    game_state = {
        'board': [[0 for _ in range(15)] for _ in range(15)],
        'my_color': 'black',
        'current_player': 'black',
        'round_number': 1,
        'move_history': []
    }

    move = ai.make_move(game_state)

    assert isinstance(move, list), "Move must be a list"
    assert len(move) == 2, "Move must have 2 coordinates"
    assert 0 <= move[0] < 15, "X coordinate out of bounds"
    assert 0 <= move[1] < 15, "Y coordinate out of bounds"

    print(f"First move: {move}")
    print("✓ First move test passed")


def test_blocking_move(ai):
    """Test blocking opponent's winning move."""
    print("\nTesting blocking move...")

    # Create a board where white has 4 in a row
    board = [[0 for _ in range(15)] for _ in range(15)]
    board[7][5] = 2  # white
    board[7][6] = 2  # white
    board[7][7] = 2  # white
    board[7][8] = 2  # white
    # Black must block at [7, 9] or [7, 4]

    game_state = {
        'board': board,
        'my_color': 'black',
        'current_player': 'black',
        'round_number': 5,
        'move_history': []
    }

    move = ai.make_move(game_state)

    # Should block at one of the ends
    assert move in [[7, 4], [7, 9]], f"Should block at [7,4] or [7,9], got {move}"

    print(f"Blocking move: {move}")
    print("✓ Blocking move test passed")


def test_winning_move(ai):
    """Test detecting winning move."""
    print("\nTesting winning move detection...")

    # Create a board where black can win
    board = [[0 for _ in range(15)] for _ in range(15)]
    board[7][5] = 1  # black
    board[7][6] = 1  # black
    board[7][7] = 1  # black
    board[7][8] = 1  # black
    # Black can win at [7, 9] or [7, 4]

    game_state = {
        'board': board,
        'my_color': 'black',
        'current_player': 'black',
        'round_number': 5,
        'move_history': []
    }

    move = ai.make_move(game_state)

    # Should win at one of the ends
    assert move in [[7, 4], [7, 9]], f"Should win at [7,4] or [7,9], got {move}"

    print(f"Winning move: {move}")
    print("✓ Winning move test passed")


def test_valid_moves(ai):
    """Test that AI always returns valid moves."""
    print("\nTesting valid move generation...")

    # Test on a partially filled board
    board = [[0 for _ in range(15)] for _ in range(15)]

    # Place some random pieces
    board[7][7] = 1
    board[7][8] = 2
    board[8][7] = 1
    board[6][7] = 2

    game_state = {
        'board': board,
        'my_color': 'black',
        'current_player': 'black',
        'round_number': 5,
        'move_history': []
    }

    # Test multiple moves
    for _ in range(3):
        move = ai.make_move(game_state)

        assert isinstance(move, list), "Move must be a list"
        assert len(move) == 2, "Move must have 2 coordinates"
        assert 0 <= move[0] < 15, "X coordinate out of bounds"
        assert 0 <= move[1] < 15, "Y coordinate out of bounds"
        assert board[move[0]][move[1]] == 0, "Move position must be empty"

        # Place the move and continue
        board[move[0]][move[1]] = 1

    print("✓ Valid move generation test passed")


def run_all_tests():
    """Run all test cases."""
    print("=" * 60)
    print("Claude Sonnet 4.5 Gomoku Elite AI - Test Suite")
    print("=" * 60)

    try:
        ai = test_initialization()
        test_get_info(ai)
        test_first_move(ai)
        test_blocking_move(ai)
        test_winning_move(ai)
        test_valid_moves(ai)

        print("\n" + "=" * 60)
        print("All tests passed successfully!")
        print("=" * 60)

        return True

    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        return False
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
