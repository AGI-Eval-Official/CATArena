"""
Standalone integration test for Claude Sonnet 4.5 Gomoku Elite AI
Simulates actual game scenarios
"""

import sys
import os
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ai_player import ClaudeSonnet45GomokuEliteAI


def print_board(board):
    """Print the board in a readable format."""
    print("\n   ", end="")
    for i in range(15):
        print(f"{i:2d}", end=" ")
    print()

    for i in range(15):
        print(f"{i:2d} ", end="")
        for j in range(15):
            if board[i][j] == 0:
                print(" . ", end="")
            elif board[i][j] == 1:
                print(" X ", end="")
            else:
                print(" O ", end="")
        print()


def check_win(board, x, y, player):
    """Check if the last move at (x,y) wins."""
    directions = [(0, 1), (1, 0), (1, 1), (1, -1)]

    for dx, dy in directions:
        count = 1

        # Forward
        nx, ny = x + dx, y + dy
        while 0 <= nx < 15 and 0 <= ny < 15 and board[nx][ny] == player:
            count += 1
            nx, ny = nx + dx, ny + dy

        # Backward
        nx, ny = x - dx, y - dy
        while 0 <= nx < 15 and 0 <= ny < 15 and board[nx][ny] == player:
            count += 1
            nx, ny = nx - dx, ny - dy

        if count >= 5:
            return True

    return False


def simulate_game():
    """Simulate a full game between two AI instances."""
    print("=" * 70)
    print("Simulating a game: Claude AI (Black) vs Claude AI (White)")
    print("=" * 70)

    ai_black = ClaudeSonnet45GomokuEliteAI()
    ai_white = ClaudeSonnet45GomokuEliteAI()

    board = [[0 for _ in range(15)] for _ in range(15)]
    move_history = []
    current_player = 'black'

    max_moves = 100
    move_count = 0

    while move_count < max_moves:
        move_count += 1

        # Prepare game state
        game_state = {
            'board': [row[:] for row in board],
            'my_color': current_player,
            'current_player': current_player,
            'round_number': move_count,
            'move_history': move_history
        }

        # Get AI move
        ai = ai_black if current_player == 'black' else ai_white
        player_value = 1 if current_player == 'black' else 2

        start_time = time.time()
        move = ai.make_move(game_state)
        elapsed = time.time() - start_time

        x, y = move

        # Validate move
        if not (0 <= x < 15 and 0 <= y < 15):
            print(f"Error: Invalid move {move} by {current_player}")
            return False

        if board[x][y] != 0:
            print(f"Error: Position {move} already occupied")
            return False

        # Make move
        board[x][y] = player_value
        move_history.append(move)

        symbol = "X" if current_player == 'black' else "O"
        print(f"Move {move_count}: {current_player.capitalize()} ({symbol}) -> [{x}, {y}] (took {elapsed:.3f}s)")

        # Check win
        if check_win(board, x, y, player_value):
            print("\n" + "=" * 70)
            print(f"{current_player.capitalize()} wins!")
            print("=" * 70)
            print_board(board)
            return True

        # Switch player
        current_player = 'white' if current_player == 'black' else 'black'

    print("\nGame ended in a draw (max moves reached)")
    print_board(board)
    return True


def test_performance():
    """Test AI decision speed."""
    print("\n" + "=" * 70)
    print("Testing AI Performance")
    print("=" * 70)

    ai = ClaudeSonnet45GomokuEliteAI()

    test_cases = [
        {
            'name': 'Empty board',
            'board': [[0 for _ in range(15)] for _ in range(15)],
        },
        {
            'name': 'Mid-game',
            'board': [[0 for _ in range(15)] for _ in range(15)],
        },
        {
            'name': 'Complex position',
            'board': [[0 for _ in range(15)] for _ in range(15)],
        }
    ]

    # Add some pieces to mid-game
    test_cases[1]['board'][7][7] = 1
    test_cases[1]['board'][7][8] = 2
    test_cases[1]['board'][8][7] = 1
    test_cases[1]['board'][8][8] = 2

    # Add complex position
    for i in range(6, 10):
        for j in range(6, 10):
            if (i + j) % 2 == 0:
                test_cases[2]['board'][i][j] = 1
            elif (i + j) % 3 == 0:
                test_cases[2]['board'][i][j] = 2

    for test in test_cases:
        game_state = {
            'board': test['board'],
            'my_color': 'black',
            'current_player': 'black',
            'round_number': 1,
            'move_history': []
        }

        start_time = time.time()
        move = ai.make_move(game_state)
        elapsed = time.time() - start_time

        print(f"\n{test['name']}: {move} (took {elapsed:.3f}s)")

        if elapsed > 15:
            print("  ⚠ Warning: Exceeded timeout threshold")
        else:
            print("  ✓ Within timeout")


def test_tactical_scenarios():
    """Test AI in specific tactical scenarios."""
    print("\n" + "=" * 70)
    print("Testing Tactical Scenarios")
    print("=" * 70)

    ai = ClaudeSonnet45GomokuEliteAI()

    # Scenario 1: Double threat creation
    print("\n1. Testing double threat creation...")
    board = [[0 for _ in range(15)] for _ in range(15)]
    board[7][6] = 1
    board[7][7] = 1
    board[7][8] = 1
    board[8][7] = 2

    game_state = {
        'board': board,
        'my_color': 'black',
        'current_player': 'black',
        'round_number': 5,
        'move_history': []
    }

    move = ai.make_move(game_state)
    print(f"   Move: {move}")

    # Scenario 2: Complex defense
    print("\n2. Testing complex defense...")
    board = [[0 for _ in range(15)] for _ in range(15)]
    board[7][5] = 2
    board[7][6] = 2
    board[7][7] = 2
    board[8][6] = 1

    game_state = {
        'board': board,
        'my_color': 'black',
        'current_player': 'black',
        'round_number': 6,
        'move_history': []
    }

    move = ai.make_move(game_state)
    print(f"   Move: {move}")
    print("   ✓ Tactical tests completed")


def main():
    """Run all integration tests."""
    print("Claude Sonnet 4.5 Gomoku Elite AI - Integration Test Suite\n")

    try:
        # Run performance test
        test_performance()

        # Run tactical tests
        test_tactical_scenarios()

        # Simulate a short game
        print("\n" + "=" * 70)
        print("Simulating a short game scenario...")
        print("=" * 70)

        ai_black = ClaudeSonnet45GomokuEliteAI()
        board = [[0 for _ in range(15)] for _ in range(15)]

        # Play a few moves
        for i in range(10):
            game_state = {
                'board': [row[:] for row in board],
                'my_color': 'black',
                'current_player': 'black',
                'round_number': i + 1,
                'move_history': []
            }

            move = ai_black.make_move(game_state)
            board[move[0]][move[1]] = 1

            print(f"Move {i+1}: {move}")

        print("\n✓ Integration tests completed successfully!")

        print("\n" + "=" * 70)
        print("Summary")
        print("=" * 70)
        print("✓ Performance: OK")
        print("✓ Tactical play: OK")
        print("✓ Game simulation: OK")
        print("\nThe AI is ready for competitive play!")

        return True

    except Exception as e:
        print(f"\n❌ Integration test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
