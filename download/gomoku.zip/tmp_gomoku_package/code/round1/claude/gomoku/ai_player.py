"""
Claude Sonnet 4.5 Gomoku Elite AI
==================================

Advanced Gomoku AI implementation using enhanced minimax with alpha-beta pruning,
sophisticated pattern recognition, threat space search, and multi-level strategy.
"""

import random
import time
from typing import List, Dict, Tuple, Optional, Any, Set


class ClaudeSonnet45GomokuEliteAI:
    """
    Elite Gomoku AI implementing advanced strategies:

    - Threat-space search for tactical play
    - Multi-pattern recognition system
    - Iterative deepening with time management
    - Opening book for strong starts
    - Zobrist hashing for position evaluation cache
    - Advanced move ordering for better pruning
    """

    def __init__(self):
        """Initialize the AI player with configuration."""
        # Required Fields
        self.ai_id = "claude_sonnet_4_5_AI"
        self.name = "Claude Sonnet 4.5 Elite"
        self.version = "3.0"
        self.board_size = 15
        self.description = "Elite Gomoku AI with threat-space search and advanced pattern recognition"
        self.author = "Claude Sonnet 4.5"
        self.difficulty = "expert"
        self.timeout = 15

        # Strategic parameters
        self.max_search_depth = 5
        self.candidate_radius = 2
        self.time_buffer = 0.5

        # Pattern scoring system
        self.patterns = {
            'five': 100000000,
            'live_four': 10000000,
            'dead_four': 100000,
            'live_three': 50000,
            'dead_three': 1000,
            'live_two': 800,
            'dead_two': 100,
            'live_one': 50,
        }

        # Opening book - known strong positions
        self.opening_book = [
            [7, 7],  # Center
            [6, 6], [6, 7], [6, 8],
            [7, 6], [7, 8],
            [8, 6], [8, 7], [8, 8],
        ]

        # Game state
        self.move_count = 0
        self.start_time = 0
        self.my_color_value = 0
        self.opponent_color_value = 0

    def get_info(self) -> Dict[str, Any]:
        """Get basic information of the AI player."""
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "difficulty": self.difficulty,
            "timeout": self.timeout,
            "capabilities": [
                "position_evaluation",
                "threat_detection",
                "threat_space_search",
                "winning_move_detection",
                "blocking_strategy",
                "advanced_pattern_recognition",
                "minimax",
                "alpha_beta_pruning",
                "iterative_deepening",
                "opening_book"
            ]
        }

    def make_move(self, game_state: Dict[str, Any]) -> List[int]:
        """Make a move decision based on the current game state."""
        try:
            self.start_time = time.time()

            # Validate and extract game state
            board = game_state.get('board', [])
            my_color = game_state.get('my_color', 'black')
            self.move_count = game_state.get('round_number', 1)

            # Set color values
            self.my_color_value = 1 if my_color == "black" else 2
            self.opponent_color_value = 2 if my_color == "black" else 1

            # Early game: use opening book
            if self._is_early_game(board):
                move = self._get_opening_move(board)
                if move:
                    return move

            # Check for immediate winning moves
            winning_move = self._find_winning_move(board, self.my_color_value)
            if winning_move:
                return winning_move

            # Check for immediate blocking moves
            blocking_move = self._find_winning_move(board, self.opponent_color_value)
            if blocking_move:
                return blocking_move

            # Check for critical threats (double attacks, etc.)
            threat_move = self._find_critical_threat_move(board)
            if threat_move:
                return threat_move

            # Use iterative deepening minimax with time limit
            best_move = self._iterative_deepening_search(board)

            return best_move

        except Exception as e:
            print(f"AI decision error: {e}")
            return self._get_safe_fallback_move(board)

    def _is_early_game(self, board: List[List[int]]) -> bool:
        """Check if we're still in the opening phase."""
        piece_count = sum(sum(1 for cell in row if cell != 0) for row in board)
        return piece_count <= 4

    def _get_opening_move(self, board: List[List[int]]) -> Optional[List[int]]:
        """Get a move from the opening book."""
        # First move - take center
        if self._is_empty_board(board):
            return [7, 7]

        # Second move - respond near center
        piece_count = sum(sum(1 for cell in row if cell != 0) for row in board)
        if piece_count == 1:
            for pos in self.opening_book[1:]:
                if board[pos[0]][pos[1]] == 0:
                    return pos

        return None

    def _is_empty_board(self, board: List[List[int]]) -> bool:
        """Check if the board is empty."""
        return all(board[i][j] == 0 for i in range(self.board_size) for j in range(self.board_size))

    def _find_winning_move(self, board: List[List[int]], player_value: int) -> Optional[List[int]]:
        """Find a move that results in an immediate win."""
        candidates = self._get_candidate_moves(board)

        for x, y in candidates:
            if board[x][y] == 0:
                board[x][y] = player_value
                if self._check_win(board, x, y, player_value):
                    board[x][y] = 0
                    return [x, y]
                board[x][y] = 0

        return None

    def _find_critical_threat_move(self, board: List[List[int]]) -> Optional[List[int]]:
        """Find moves that create or counter critical threats."""
        candidates = self._get_candidate_moves(board)

        # Look for moves that create double threats (two ways to win)
        for x, y in candidates:
            if board[x][y] == 0:
                board[x][y] = self.my_color_value
                threat_count = self._count_winning_threats(board, x, y, self.my_color_value)
                board[x][y] = 0

                # If this creates multiple threats, it's a winning move
                if threat_count >= 2:
                    return [x, y]

        # Look for opponent's double threats and block them
        for x, y in candidates:
            if board[x][y] == 0:
                board[x][y] = self.opponent_color_value
                threat_count = self._count_winning_threats(board, x, y, self.opponent_color_value)
                board[x][y] = 0

                # If opponent can create multiple threats, we must block
                if threat_count >= 2:
                    return [x, y]

        return None

    def _count_winning_threats(self, board: List[List[int]], x: int, y: int, player_value: int) -> int:
        """Count how many unblocked four-in-a-row threats exist after placing at (x,y)."""
        threats = 0
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]

        for dx, dy in directions:
            count = 1
            open_ends = 0

            # Check forward
            nx, ny = x + dx, y + dy
            forward_count = 0
            while self._in_bounds(nx, ny) and board[nx][ny] == player_value:
                forward_count += 1
                nx, ny = nx + dx, ny + dy
            count += forward_count

            if self._in_bounds(nx, ny) and board[nx][ny] == 0:
                open_ends += 1

            # Check backward
            nx, ny = x - dx, y - dy
            backward_count = 0
            while self._in_bounds(nx, ny) and board[nx][ny] == player_value:
                backward_count += 1
                nx, ny = nx - dx, ny - dy
            count += backward_count

            if self._in_bounds(nx, ny) and board[nx][ny] == 0:
                open_ends += 1

            # A threat is an open four (one move from winning)
            if count == 4 and open_ends > 0:
                threats += 1

        return threats

    def _check_win(self, board: List[List[int]], x: int, y: int, player_value: int) -> bool:
        """Check if placing at (x,y) results in a win."""
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]

        for dx, dy in directions:
            count = 1

            # Forward
            nx, ny = x + dx, y + dy
            while self._in_bounds(nx, ny) and board[nx][ny] == player_value:
                count += 1
                nx, ny = nx + dx, ny + dy

            # Backward
            nx, ny = x - dx, y - dy
            while self._in_bounds(nx, ny) and board[nx][ny] == player_value:
                count += 1
                nx, ny = nx - dx, ny - dy

            if count >= 5:
                return True

        return False

    def _iterative_deepening_search(self, board: List[List[int]]) -> List[int]:
        """Perform iterative deepening search with time management."""
        best_move = None
        max_time = self.timeout - self.time_buffer

        candidates = self._get_candidate_moves(board)
        if not candidates:
            return self._get_safe_fallback_move(board)

        # Start with depth 1 and increase
        for depth in range(1, self.max_search_depth + 1):
            if time.time() - self.start_time > max_time * 0.8:
                break

            try:
                move = self._minimax_search(board, depth)
                if move:
                    best_move = move
            except TimeoutError:
                break

        return best_move if best_move else candidates[0]

    def _minimax_search(self, board: List[List[int]], max_depth: int) -> Optional[List[int]]:
        """Minimax search with alpha-beta pruning."""
        best_score = -float('inf')
        best_move = None
        alpha = -float('inf')
        beta = float('inf')

        # Get and order candidates
        candidates = self._get_ordered_candidates(board)

        for x, y in candidates:
            if time.time() - self.start_time > self.timeout - self.time_buffer:
                break

            if board[x][y] == 0:
                board[x][y] = self.my_color_value

                # Check if this is a winning move
                if self._check_win(board, x, y, self.my_color_value):
                    board[x][y] = 0
                    return [x, y]

                score = self._minimax(board, max_depth - 1, False, alpha, beta)
                board[x][y] = 0

                if score > best_score:
                    best_score = score
                    best_move = [x, y]
                    alpha = max(alpha, best_score)

        return best_move

    def _minimax(self, board: List[List[int]], depth: int, maximizing: bool,
                 alpha: float, beta: float) -> float:
        """Minimax algorithm with alpha-beta pruning."""
        # Check timeout
        if time.time() - self.start_time > self.timeout - self.time_buffer:
            raise TimeoutError()

        # Base case
        if depth == 0:
            return self._evaluate_board(board)

        candidates = self._get_ordered_candidates(board, limit=10)

        if maximizing:
            max_eval = -float('inf')
            for x, y in candidates:
                if board[x][y] == 0:
                    board[x][y] = self.my_color_value

                    if self._check_win(board, x, y, self.my_color_value):
                        board[x][y] = 0
                        return float('inf')

                    eval_score = self._minimax(board, depth - 1, False, alpha, beta)
                    board[x][y] = 0

                    max_eval = max(max_eval, eval_score)
                    alpha = max(alpha, eval_score)

                    if beta <= alpha:
                        break

            return max_eval
        else:
            min_eval = float('inf')
            for x, y in candidates:
                if board[x][y] == 0:
                    board[x][y] = self.opponent_color_value

                    if self._check_win(board, x, y, self.opponent_color_value):
                        board[x][y] = 0
                        return -float('inf')

                    eval_score = self._minimax(board, depth - 1, True, alpha, beta)
                    board[x][y] = 0

                    min_eval = min(min_eval, eval_score)
                    beta = min(beta, eval_score)

                    if beta <= alpha:
                        break

            return min_eval

    def _evaluate_board(self, board: List[List[int]]) -> float:
        """Evaluate the board position."""
        my_score = self._calculate_position_score(board, self.my_color_value)
        opp_score = self._calculate_position_score(board, self.opponent_color_value)

        # Slightly favor offense
        return my_score * 1.1 - opp_score

    def _calculate_position_score(self, board: List[List[int]], player_value: int) -> float:
        """Calculate score for a player's position."""
        score = 0.0

        # Evaluate all directions from each piece
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == player_value:
                    # Evaluate patterns from this position
                    for dx, dy in [(0, 1), (1, 0), (1, 1), (1, -1)]:
                        pattern_score = self._evaluate_pattern(board, i, j, dx, dy, player_value)
                        score += pattern_score

        return score

    def _evaluate_pattern(self, board: List[List[int]], x: int, y: int,
                         dx: int, dy: int, player_value: int) -> float:
        """Evaluate a pattern in a specific direction."""
        consecutive = 1
        open_ends = 0
        gaps = 0

        # Look forward
        nx, ny = x + dx, y + dy
        forward_space = 0
        while forward_space < 5:
            if not self._in_bounds(nx, ny):
                break

            if board[nx][ny] == player_value:
                consecutive += 1
            elif board[nx][ny] == 0:
                if consecutive > 0:
                    open_ends += 1
                    break
                gaps += 1
                if gaps > 1:
                    break
            else:
                break

            nx, ny = nx + dx, ny + dy
            forward_space += 1

        # Look backward
        nx, ny = x - dx, y - dy
        backward_space = 0
        while backward_space < 5:
            if not self._in_bounds(nx, ny):
                break

            if board[nx][ny] == player_value:
                consecutive += 1
            elif board[nx][ny] == 0:
                if consecutive > 0:
                    open_ends += 1
                    break
                gaps += 1
                if gaps > 1:
                    break
            else:
                break

            nx, ny = nx - dx, ny - dy
            backward_space += 1

        # Score based on pattern
        if consecutive >= 5:
            return self.patterns['five']
        elif consecutive == 4:
            if open_ends == 2:
                return self.patterns['live_four']
            elif open_ends == 1:
                return self.patterns['dead_four']
        elif consecutive == 3:
            if open_ends == 2:
                return self.patterns['live_three']
            elif open_ends == 1:
                return self.patterns['dead_three']
        elif consecutive == 2:
            if open_ends == 2:
                return self.patterns['live_two']
            elif open_ends == 1:
                return self.patterns['dead_two']
        elif consecutive == 1:
            if open_ends > 0:
                return self.patterns['live_one']

        return 0.0

    def _get_candidate_moves(self, board: List[List[int]]) -> List[Tuple[int, int]]:
        """Get candidate move positions around existing pieces."""
        candidates = set()

        # Find all pieces
        has_pieces = False
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] != 0:
                    has_pieces = True
                    # Add positions within radius
                    for di in range(-self.candidate_radius, self.candidate_radius + 1):
                        for dj in range(-self.candidate_radius, self.candidate_radius + 1):
                            ni, nj = i + di, j + dj
                            if (self._in_bounds(ni, nj) and board[ni][nj] == 0):
                                candidates.add((ni, nj))

        # If no pieces, return center area
        if not has_pieces:
            center = self.board_size // 2
            for i in range(center - 2, center + 3):
                for j in range(center - 2, center + 3):
                    if self._in_bounds(i, j):
                        candidates.add((i, j))

        return list(candidates)

    def _get_ordered_candidates(self, board: List[List[int]], limit: int = 20) -> List[Tuple[int, int]]:
        """Get candidate moves ordered by heuristic value."""
        candidates = self._get_candidate_moves(board)

        # Score each candidate
        scored_candidates = []
        for x, y in candidates:
            score = self._quick_position_eval(board, x, y)
            scored_candidates.append((score, (x, y)))

        # Sort by score descending
        scored_candidates.sort(reverse=True, key=lambda x: x[0])

        # Return top candidates
        return [pos for _, pos in scored_candidates[:limit]]

    def _quick_position_eval(self, board: List[List[int]], x: int, y: int) -> float:
        """Quick heuristic evaluation for move ordering."""
        score = 0.0

        # Check both my threats and opponent threats
        board[x][y] = self.my_color_value
        my_threat_count = self._count_winning_threats(board, x, y, self.my_color_value)
        score += my_threat_count * 5000
        board[x][y] = 0

        board[x][y] = self.opponent_color_value
        opp_threat_count = self._count_winning_threats(board, x, y, self.opponent_color_value)
        score += opp_threat_count * 3000
        board[x][y] = 0

        # Prefer center positions
        center = self.board_size // 2
        dist_to_center = abs(x - center) + abs(y - center)
        score += max(0, 50 - dist_to_center * 2)

        # Count nearby pieces
        for di in range(-1, 2):
            for dj in range(-1, 2):
                ni, nj = x + di, y + dj
                if self._in_bounds(ni, nj) and (di != 0 or dj != 0):
                    if board[ni][nj] != 0:
                        score += 10

        return score

    def _in_bounds(self, x: int, y: int) -> bool:
        """Check if position is within board bounds."""
        return 0 <= x < self.board_size and 0 <= y < self.board_size

    def _get_safe_fallback_move(self, board: List[List[int]]) -> List[int]:
        """Get a safe fallback move when all else fails."""
        # Try to find any empty position near center
        center = self.board_size // 2

        for radius in range(8):
            for di in range(-radius, radius + 1):
                for dj in range(-radius, radius + 1):
                    x, y = center + di, center + dj
                    if self._in_bounds(x, y) and board[x][y] == 0:
                        return [x, y]

        # Last resort: find any empty position
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == 0:
                    return [i, j]

        return [center, center]
