import random
from typing import Dict, Any, List

class GomokuAITemplate:
    def __init__(self):
        self.ai_id = "gemini_gomoku_ai_0"
        self.name = "Gemini Gomoku AI 0"
        self.version = "1.0.0"
        self.author = "Gemini"
        self.description = "A Gomoku AI developed by Gemini."
        self.difficulty = "medium"
        self.timeout = 10
        self.board_size = 15

    def get_info(self) -> Dict[str, Any]:
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "difficulty": self.difficulty,
            "timeout": self.timeout,
            "capabilities": self._get_capabilities()
        }

    def _get_capabilities(self) -> List[str]:
        return ["position_evaluation"]

    def make_move(self, game_state: Dict[str, Any]) -> List[int]:
        board = game_state['board']
        my_color_str = game_state['my_color']
        my_color = 1 if my_color_str == 'black' else 2
        opponent_color = 3 - my_color

        best_move = None
        best_score = -float('inf')

        for r in range(self.board_size):
            for c in range(self.board_size):
                if board[r][c] == 0:
                    board[r][c] = my_color
                    score = self.minimax(board, 2, False, my_color, opponent_color)
                    board[r][c] = 0
                    if score > best_score:
                        best_score = score
                        best_move = [r, c]

        return best_move if best_move is not None else self._get_safe_random_move(board)

    def minimax(self, board, depth, is_maximizing, my_color, opponent_color):
        if depth == 0 or self.is_game_over(board, my_color, opponent_color):
            return self.evaluate_board(board, my_color, opponent_color)

        if is_maximizing:
            best_score = -float('inf')
            for r in range(self.board_size):
                for c in range(self.board_size):
                    if board[r][c] == 0:
                        board[r][c] = my_color
                        score = self.minimax(board, depth - 1, False, my_color, opponent_color)
                        board[r][c] = 0
                        best_score = max(best_score, score)
            return best_score
        else:
            best_score = float('inf')
            for r in range(self.board_size):
                for c in range(self.board_size):
                    if board[r][c] == 0:
                        board[r][c] = opponent_color
                        score = self.minimax(board, depth - 1, True, my_color, opponent_color)
                        board[r][c] = 0
                        best_score = min(best_score, score)
            return best_score

    def evaluate_board(self, board, my_color, opponent_color):
        my_score = self.calculate_score(board, my_color)
        opponent_score = self.calculate_score(board, opponent_color)
        return my_score - opponent_score

    def calculate_score(self, board, color):
        score = 0
        # Horizontal, Vertical, and Diagonal checks
        for r in range(self.board_size):
            for c in range(self.board_size):
                if board[r][c] == color:
                    # Horizontal
                    if c + 4 < self.board_size and all(board[r][c+i] == color for i in range(5)):
                        score += 10000
                    # Vertical
                    if r + 4 < self.board_size and all(board[r+i][c] == color for i in range(5)):
                        score += 10000
                    # Diagonal (top-left to bottom-right)
                    if r + 4 < self.board_size and c + 4 < self.board_size and all(board[r+i][c+i] == color for i in range(5)):
                        score += 10000
                    # Diagonal (top-right to bottom-left)
                    if r + 4 < self.board_size and c - 4 >= 0 and all(board[r+i][c-i] == color for i in range(5)):
                        score += 10000
        return score

    def is_game_over(self, board, my_color, opponent_color):
        if self.check_win(board, my_color) or self.check_win(board, opponent_color):
            return True
        for r in range(self.board_size):
            for c in range(self.board_size):
                if board[r][c] == 0:
                    return False
        return True

    def check_win(self, board, color):
        for r in range(self.board_size):
            for c in range(self.board_size):
                if self.check_line(board, r, c, 1, 0, color) or \
                   self.check_line(board, r, c, 0, 1, color) or \
                   self.check_line(board, r, c, 1, 1, color) or \
                   self.check_line(board, r, c, 1, -1, color):
                    return True
        return False

    def check_line(self, board, r, c, dr, dc, color):
        if r + 4 * dr < 0 or r + 4 * dr >= self.board_size or \
           c + 4 * dc < 0 or c + 4 * dc >= self.board_size:
            return False
        for i in range(5):
            if board[r + i * dr][c + i * dc] != color:
                return False
        return True
    
    def _get_safe_random_move(self, board: List[List[int]]) -> List[int]:
        empty_cells = []
        for r in range(self.board_size):
            for c in range(self.board_size):
                if board[r][c] == 0:
                    empty_cells.append([r, c])
        return random.choice(empty_cells) if empty_cells else [0, 0]


    def on_game_start(self, game_info: Dict[str, Any]) -> None:
        pass

    def on_game_end(self, game_result: Dict[str, Any]) -> None:
        pass

    def on_opponent_move(self, move: List[int], board: List[List[int]]) -> None:
        pass

    def _print_board(self, board: List[List[int]]):
        for row in board:
            print(" ".join(map(str, row)))

if __name__ == '__main__':
    ai = GomokuAITemplate()
    game_state = {
        'board': [[0] * 15 for _ in range(15)],
        'my_color': 'black',
        'round_number': 1,
        'move_history': [],
        'game_id': 'test_game'
    }
    game_state['board'][7][7] = 1
    move = ai.make_move(game_state)
    print(f"Chosen move: {move}")