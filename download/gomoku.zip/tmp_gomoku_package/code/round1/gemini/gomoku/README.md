# Gomoku AI Player Development Template

This is a standard development template for a Gomoku AI player. It provides a complete development framework and detailed documentation for building AI players.

## 📁 File Structure

```
AI_example/
├── README.md           # This documentation
├── ai_player.py        # AI player implementation template
├── ai_config.yaml      # AI configuration file template
└── test_ai.py          # AI test script
```

## 🚀 Quick Start

### 1. Copy the template

Copy the entire `AI_example` folder to a new location and rename it to your AI name:

```bash
cp -r AI_example my_awesome_ai
cd my_awesome_ai
```

### 2. Edit the configuration file

Edit the `ai_config.yaml` file and update the required fields:

```yaml
aI_id: "my_awesome_ai"          # Required: your AI unique identifier
ai_name: "My Awesome AI"         # Required: your AI display name
author: "Your Name"              # Required: your name
description: "Your AI description"  # Required: your AI description
```

### 3. Implement AI logic

Edit `ai_player.py` and focus on implementing these methods:

- `__init__()`: set AI basic information
- `_find_best_move()`: implement your decision-making algorithm

### 4. Test your AI

Run the test script to verify the AI implementation:

```bash
python test_ai.py
```

## 📋 Required Interfaces

### Core Methods

#### 1. `__init__(self)`
Required: initialize the AI player

```python
def __init__(self):
    # Required fields: set these basic properties
    self.ai_id = "your_ai_id"           # Unique AI identifier
    self.name = "Your AI Name"           # Display name
    self.version = "1.0"                 # Version
    self.board_size = 15                  # Board size
    self.description = "AI description"  # Description
    self.author = "Your Name"            # Author info
    self.difficulty = "medium"           # Difficulty
    self.timeout = 10                     # Timeout in seconds
```

#### 2. `get_info(self) -> Dict[str, Any]`
Required: return basic AI information

```python
def get_info(self) -> Dict[str, Any]:
    return {
        "ai_id": self.ai_id,
        "name": self.name,
        "version": self.version,
        "description": self.description,
        "author": self.author,
        "difficulty": self.difficulty,
        "timeout": self.timeout,
        "capabilities": self._get_capabilities()
    }
```

#### 3. `make_move(self, game_state: Dict[str, Any]) -> List[int]`
Required: decide the next move based on the game state

```python
def make_move(self, game_state: Dict[str, Any]) -> List[int]:
    # Input: game_state dict including:
    # - board: List[List[int]] - board state (15x15)
    #   - 0: empty, 1: black, 2: white
    # - current_player: str - current player ("black" or "white")
    # - my_color: str - your color ("black" or "white")
    # - move_history: List[List[int]] - move history
    # - game_id: str - game ID
    # - round_number: int - current round number
    
    # Output: [x, y] - move position, x and y are integers in 0-14
    # Note: must return a valid empty position
    
    return [x, y]  # Your AI decision result
```

### Optional Methods

#### 1. `on_game_start(self, game_info: Dict[str, Any]) -> None`
Optional: callback when the game starts

#### 2. `on_game_end(self, game_result: Dict[str, Any]) -> None`
Optional: callback when the game ends

#### 3. `on_opponent_move(self, move: List[int], board: List[List[int]]) -> None`
Optional: callback when the opponent makes a move

## 🎯 AI Algorithm Guide

### Basic Strategy

1. Winning Detection: prioritize moves that win immediately
2. Blocking Strategy: prevent the opponent from winning
3. Threat Creation: create multiple simultaneous threats
4. Position Evaluation: assess the value of each position

### Advanced Strategy

1. Search Algorithms: Minimax, Alpha-Beta pruning
2. Pattern Recognition: detect common offensive/defensive patterns
3. Opening Book: use predefined opening moves
4. Endgame Solver: precise calculation in endgame positions


## 📊 Configuration File Explained

### Required Fields

| Field | Type | Description | Example |
|------|------|-------------|---------|
| `ai_id` | string | unique AI identifier | "my_ai" |
| `ai_name` | string | display name | "My AI" |
| `version` | string | version | "1.0" |
| `description` | string | AI description | "Intelligent Gomoku AI" |
| `category` | string | AI category | "standard" |
| `capabilities` | array | capability list | ["position_evaluation"] |
| `author` | string | author | "John Doe" |
| `created_at` | string | creation date | "2024-01-01" |
| `timeout` | integer | timeout (seconds) | 10 |
| `difficulty` | string | difficulty level | "medium" |

### Optional Fields

| Field | Type | Description | Example |
|------|------|-------------|---------|
| `contact` | string | contact info | "email@example.com" |
| `license` | string | license | "MIT" |
| `dependencies` | array | Python dependencies | ["numpy"] |
| `parameters` | object | configurable parameters | {"depth": 3} |
| `performance` | object | performance metrics | {"win_rate": 0.8} |
| `tags` | array | tags | ["fast", "strong"] |

## 🧪 Testing Guide

### Basic Test

Run `test_ai.py` for basic functionality tests:

```bash
python test_ai.py
```

Test coverage includes:
- AI initialization correctness
- `get_info()` return format
- Basic functionality of `make_move()`
- Configuration file validation

### Performance Test

```python
# Measure decision time
import time

start_time = time.time()
move = ai.make_move(game_state)
end_time = time.time()

print(f"Decision time: {end_time - start_time:.3f}s")
```


## 🔧 Development Tips

### 1. Debugging Tips

```python
def make_move(self, game_state):
    # Add debug output
    print(f"Current round: {game_state.get('round_number', 0)}")
    print(f"My color: {game_state.get('my_color', 'unknown')}")
    
    # Visualize board
    self._print_board(game_state['board'])
    
    # Your decision logic
    move = self._find_best_move(board, my_color)
    
    print(f"Chosen position: ({move[0]}, {move[1]})")
    return move
```

### 2. Performance Optimization

```python
# Use caching to avoid repeated calculations
from functools import lru_cache

@lru_cache(maxsize=1000)
def _evaluate_position(self, board_tuple, x, y, player):
    # Convert board to tuple to support caching
    board = [list(row) for row in board_tuple]
    # Your evaluation logic
    return score
```

### 3. Error Handling

```python
def make_move(self, game_state):
    try:
        # Your decision logic
        return self._find_best_move(board, my_color)
    except Exception as e:
        print(f"Decision error: {e}")
        return self._get_safe_random_move(game_state.get('board', []))
```


