#!/usr/bin/env python3
"""
Gomoku AI Player Test Script
==================

This script is used to test the basic functionality of the AI player, ensuring the AI correctly implements all required interfaces.

Usage:
    python test_ai.py

Test Contents:
1. AI initialization test
2. get_info() method test
3. make_move() method test
4. Configuration file validation
5. Basic functionality verification

Author: AI Template Generator
Version: 1.0
"""

import sys
import os
import yaml
import time
import traceback
from typing import Dict, List, Any

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from ai_player import GomokuAITemplate, MyCustomAI
except ImportError as e:
    print(f"❌ Failed to import AI module: {e}")
    print("Please ensure ai_player.py exists and the syntax is correct")
    sys.exit(1)


class AITester:
    """AI Player Tester"""
    
    def __init__(self):
        self.test_results = []
        self.ai_instance = None
    
    def log_test(self, test_name: str, passed: bool, message: str = ""):
        """Record test result"""
        status = "✅ Passed" if passed else "❌ Failed"
        result = {
            "test": test_name,
            "passed": passed,
            "message": message
        }
        self.test_results.append(result)
        print(f"{status} {test_name}: {message}")
    
    def test_ai_initialization(self) -> bool:
        """Test AI initialization"""
        print("\n🔧 Testing AI initialization...")
        
        try:
            # Test template AI
            template_ai = GomokuAITemplate()
            
            # Check required fields
            required_fields = [
                'ai_id', 'name', 'version', 'board_size', 
                'description', 'author', 'difficulty', 'timeout'
            ]
            
            for field in required_fields:
                if not hasattr(template_ai, field):
                    self.log_test("Initialization Check", False, f"Missing required field: {field}")
                    return False
                
                value = getattr(template_ai, field)
                if value is None or value == "":
                    self.log_test("Initialization Check", False, f"Field {field} cannot be empty")
                    return False
            
            # Check field types
            if not isinstance(template_ai.ai_id, str):
                self.log_test("Initialization Check", False, "ai_id must be a string")
                return False
            
            if not isinstance(template_ai.board_size, int) or template_ai.board_size != 15:
                self.log_test("Initialization Check", False, "board_size must be 15")
                return False
            
            if not isinstance(template_ai.timeout, int) or template_ai.timeout <= 0:
                self.log_test("Initialization Check", False, "timeout must be a positive integer")
                return False
            
            self.ai_instance = template_ai
            self.log_test("Initialization Check", True, "All required fields are correctly set")
            return True
            
        except Exception as e:
            self.log_test("Initialization Check", False, f"Initialization error: {str(e)}")
            return False
    
    def test_get_info_method(self) -> bool:
        """Test get_info method"""
        print("\n📋 Testing get_info method...")
        
        if not self.ai_instance:
            self.log_test("get_info Method", False, "AI instance not initialized")
            return False
        
        try:
            info = self.ai_instance.get_info()
            
            # Check return type
            if not isinstance(info, dict):
                self.log_test("get_info Method", False, "Return value must be a dictionary")
                return False
            
            # Check required fields
            required_fields = [
                'ai_id', 'name', 'version', 'description', 
                'author', 'difficulty', 'timeout'
            ]
            
            for field in required_fields:
                if field not in info:
                    self.log_test("get_info Method", False, f"Returned dict missing field: {field}")
                    return False
            
            # Check field values
            if not isinstance(info['ai_id'], str) or not info['ai_id']:
                self.log_test("get_info Method", False, "ai_id must be a non-empty string")
                return False
            
            if not isinstance(info['timeout'], int) or info['timeout'] <= 0:
                self.log_test("get_info Method", False, "timeout must be a positive integer")
                return False
            
            self.log_test("get_info Method", True, f"Returned correct AI info: {info['name']}")
            return True
            
        except Exception as e:
            self.log_test("get_info Method", False, f"Method call exception: {str(e)}")
            return False
    
    def test_make_move_method(self) -> bool:
        """Test make_move method"""
        print("\n🎯 Testing make_move method...")
        
        if not self.ai_instance:
            self.log_test("make_move Method", False, "AI instance not initialized")
            return False
        
        try:
            # Create test game state
            test_board = [[0 for _ in range(15)] for _ in range(15)]
            test_game_state = {
                'board': test_board,
                'current_player': 'black',
                'my_color': 'black',
                'move_history': [],
                'game_id': 'test_game',
                'round_number': 1
            }
            
            # First move (empty board)
            start_time = time.time()
            move = self.ai_instance.make_move(test_game_state)
            end_time = time.time()
            
            decision_time = end_time - start_time
            
            # Check return format
            if not isinstance(move, list) or len(move) != 2:
                self.log_test("make_move Method", False, "Return value must be a list of length 2")
                return False
            
            x, y = move
            if not isinstance(x, int) or not isinstance(y, int):
                self.log_test("make_move Method", False, "Coordinates must be integers")
                return False
            
            if not (0 <= x < 15 and 0 <= y < 15):
                self.log_test("make_move Method", False, f"Coordinates out of range: ({x}, {y})")
                return False
            
            if test_board[x][y] != 0:
                self.log_test("make_move Method", False, f"Selected a non-empty position: ({x}, {y})")
                return False
            
            # Check decision time
            if decision_time > self.ai_instance.timeout:
                self.log_test("make_move Method", False, f"Decision time exceeded: {decision_time:.3f}s")
                return False
            
            self.log_test("make_move Method", True, 
                         f"Returned valid position ({x}, {y}) in {decision_time:.3f}s")
            
            # Test complex scenarios
            return self._test_complex_scenarios()
            
        except Exception as e:
            self.log_test("make_move Method", False, f"Method call exception: {str(e)}")
            traceback.print_exc()
            return False
    
    def _test_complex_scenarios(self) -> bool:
        """Test complex scenarios"""
        print("\n🧩 Testing complex scenarios...")
        
        # Scenario 1: Board with stones
        test_board = [[0 for _ in range(15)] for _ in range(15)]
        test_board[7][7] = 1  # Black
        test_board[7][8] = 2  # White
        
        test_game_state = {
            'board': test_board,
            'current_player': 'black',
            'my_color': 'black',
            'move_history': [[7, 7], [7, 8]],
            'game_id': 'test_game',
            'round_number': 3
        }
        
        try:
            move = self.ai_instance.make_move(test_game_state)
            x, y = move
            
            if test_board[x][y] != 0:
                self.log_test("Complex Scenario Test", False, f"Selected an occupied position: ({x}, {y})")
                return False
            
            self.log_test("Complex Scenario Test", True, f"Correctly handled complex situation, chose ({x}, {y})")
            
        except Exception as e:
            self.log_test("Complex Scenario Test", False, f"Complex scenario handling exception: {str(e)}")
            return False
        
        # Scenario 2: Winning opportunity detection
        return self._test_winning_detection()
    
    def _test_winning_detection(self) -> bool:
        """Test winning detection"""
        print("\n🏆 Testing winning detection...")
        
        # Create a near-winning situation
        test_board = [[0 for _ in range(15)] for _ in range(15)]
        # Create four in a row; placing at either end wins
        for i in range(4):
            test_board[7][7 + i] = 1  # Black four in a row
        
        test_game_state = {
            'board': test_board,
            'current_player': 'black',
            'my_color': 'black',
            'move_history': [],
            'game_id': 'test_game',
            'round_number': 5
        }
        
        try:
            move = self.ai_instance.make_move(test_game_state)
            x, y = move
            
            # Check if a winning position was selected
            winning_positions = [(7, 6), (7, 11)]  # Ends of the four-in-a-row
            if (x, y) in winning_positions:
                self.log_test("Winning Detection", True, f"Correctly identified winning opportunity: ({x}, {y})")
            else:
                self.log_test("Winning Detection", False, f"Did not identify winning opportunity, chose ({x}, {y})")
                # This is not a fatal error, just a hint
            
            return True
            
        except Exception as e:
            self.log_test("Winning Detection", False, f"Winning detection error: {str(e)}")
            return False
    
    def test_config_file(self) -> bool:
        """Test configuration file"""
        print("\n⚙️ Testing configuration file...")
        
        config_file = "ai_config.yaml"
        if not os.path.exists(config_file):
            self.log_test("Configuration File", False, f"Configuration file not found: {config_file}")
            return False
        
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            # Check required fields
            required_fields = [
                'ai_id', 'ai_name', 'version', 'description', 
                'category', 'capabilities', 'author', 'created_at', 
                'timeout', 'difficulty'
            ]
            
            for field in required_fields:
                if field not in config:
                    self.log_test("Configuration File", False, f"Config is missing required field: {field}")
                    return False
            
            # Check field formats
            if not isinstance(config['ai_id'], str) or not config['ai_id']:
                self.log_test("Configuration File", False, "ai_id must be a non-empty string")
                return False
            
            if not isinstance(config['capabilities'], list):
                self.log_test("Configuration File", False, "capabilities must be an array")
                return False
            
            if not isinstance(config['timeout'], int) or config['timeout'] <= 0:
                self.log_test("Configuration File", False, "timeout must be a positive integer")
                return False
            
            valid_difficulties = ['easy', 'medium', 'hard', 'expert']
            if config['difficulty'] not in valid_difficulties:
                self.log_test("Configuration File", False, f"difficulty must be one of: {valid_difficulties}")
                return False
            
            self.log_test("Configuration File", True, f"Configuration file format is correct: {config['ai_name']}")
            return True
            
        except yaml.YAMLError as e:
            self.log_test("Configuration File", False, f"YAML format error: {str(e)}")
            return False
        except Exception as e:
            self.log_test("Configuration File", False, f"Configuration file read error: {str(e)}")
            return False
    
    def test_custom_ai(self) -> bool:
        """Test custom AI example"""
        print("\n🎨 Testing custom AI example...")
        
        try:
            custom_ai = MyCustomAI()
            
            # Check correct inheritance
            if not isinstance(custom_ai, GomokuAITemplate):
                self.log_test("Custom AI", False, "MyCustomAI must inherit GomokuAITemplate")
                return False
            
            # Check whether basic info was modified
            if custom_ai.ai_id == "template_ai":
                self.log_test("Custom AI", False, "MyCustomAI should change ai_id")
                return False
            
            # Test basic functionality
            info = custom_ai.get_info()
            if not isinstance(info, dict):
                self.log_test("Custom AI", False, "get_info method returned incorrect format")
                return False
            
            self.log_test("Custom AI", True, f"Custom AI works properly: {custom_ai.name}")
            return True
            
        except Exception as e:
            self.log_test("Custom AI", False, f"Custom AI test error: {str(e)}")
            return False
    
    def run_all_tests(self) -> bool:
        """Run all tests"""
        print("🚀 Starting AI player tests...")
        print("=" * 50)
        
        tests = [
            self.test_ai_initialization,
            self.test_get_info_method,
            self.test_make_move_method,
            self.test_config_file,
            self.test_custom_ai
        ]
        
        all_passed = True
        for test in tests:
            try:
                if not test():
                    all_passed = False
            except Exception as e:
                print(f"❌ Test execution exception: {str(e)}")
                traceback.print_exc()
                all_passed = False
        
        return all_passed
    
    def print_summary(self):
        """Print test summary"""
        print("\n" + "=" * 50)
        print("📊 Test Summary")
        print("=" * 50)
        
        passed_count = sum(1 for result in self.test_results if result['passed'])
        total_count = len(self.test_results)
        
        print(f"Total tests: {total_count}")
        print(f"Passed: {passed_count}")
        print(f"Failed: {total_count - passed_count}")
        print(f"Pass rate: {passed_count / total_count * 100:.1f}%")
        
        if passed_count == total_count:
            print("\n🎉 Congrats! All tests passed!")
            print("Your AI player template is ready; you can start developing your AI.")
        else:
            print("\n⚠️ Some tests failed. Please check the following issues:")
            for result in self.test_results:
                if not result['passed']:
                    print(f"  - {result['test']}: {result['message']}")
        
        print("\n📚 Next steps:")
        print("1. Modify AI configuration according to README.md")
        print("2. Implement your own AI algorithm")
        print("3. Run more tests to verify AI performance")
        print("4. Conduct battle tests with other AIs")


def main():
    """Main function"""
    print("Gomoku AI Player Test Tool")
    print("Author: AI Template Generator")
    print("Version: 1.0")
    print()
    
    tester = AITester()
    
    try:
        success = tester.run_all_tests()
        tester.print_summary()
        
        # Return appropriate exit code
        sys.exit(0 if success else 1)
        
    except KeyboardInterrupt:
        print("\n\n⏹️ Test interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n💥 An unexpected error occurred during testing: {str(e)}")
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()