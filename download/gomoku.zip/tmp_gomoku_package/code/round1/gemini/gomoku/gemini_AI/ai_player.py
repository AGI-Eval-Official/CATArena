"""
Gemini Gomoku AI
===============

A Gomoku AI implementation using minimax with alpha-beta pruning.
"""

import random
import math
from typing import List, Dict, Tuple, Optional, Any


class GeminiGomokuAI:
    """
    A Gomoku AI using minimax with alpha-beta pruning.
    """
    
    def __init__(self):
        """Initialize the AI player with configuration."""
        self.ai_id = "gemini_gomoku_0"
        self.name = "Gemini Gomoku"
        self.version = "1.0"
        self.board_size = 15
        self.description = "A Gomoku AI using minimax with alpha-beta pruning."
        self.author = "Gemini"
        self.difficulty = "medium"
        self.timeout = 15
        
        # Internal state
        self.max_search_depth = 3
        self.candidate_radius = 2

    def get_info(self) -> Dict[str, Any]:
        """
        Get basic information of the AI player.
        """
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "difficulty": self.difficulty,
            "timeout": self.timeout,
            "capabilities": [
                "position_evaluation",
                "winning_move_detection",
                "blocking_strategy",
                "minimax",
                "alpha_beta_pruning"
            ]
        }
    
    def make_move(self, game_state: Dict[str, Any]) -> List[int]:
        """
        Make a move decision based on the current game state.
        """
        try:
            self._validate_game_state(game_state)
            
            board = game_state.get('board', [])
            my_color = game_state.get('my_color', 'black')
            
            my_value = 1 if my_color == "black" else 2
            opponent_value = 2 if my_color == "black" else 1
            
            if self._is_first_move(board):
                center = self.board_size // 2
                return [center, center]
            
            winning_move = self._find_winning_move(board, my_value)
            if winning_move:
                return winning_move
            
            blocking_move = self._find_winning_move(board, opponent_value)
            if blocking_move:
                return blocking_move
            
            best_move = self._minimax_search(board, my_value, opponent_value)
            
            self._validate_move(board, best_move)
            
            return best_move
            
        except Exception as e:
            print(f"AI decision error: {e}")
            return self._get_safe_random_move(game_state.get('board', []))
    
    def _validate_game_state(self, game_state: Dict[str, Any]) -> None:
        """Validate the game state."""
        if not isinstance(game_state, dict):
            raise ValueError("Game state must be a dict")
        
        if 'board' not in game_state:
            raise ValueError("Game state is missing board information")
        
        board = game_state['board']
        if not isinstance(board, list) or len(board) != self.board_size:
            raise ValueError(f"Invalid board size; expected {self.board_size}x{self.board_size}")
        
        for row in board:
            if not isinstance(row, list) or len(row) != self.board_size:
                raise ValueError(f"Invalid row size; expected {self.board_size}")
    
    def _is_first_move(self, board: List[List[int]]) -> bool:
        """Check if it is the first move."""
        for row in board:
            for cell in row:
                if cell != 0:
                    return False
        return True
    
    def _find_winning_move(self, board: List[List[int]], player_value: int) -> Optional[List[int]]:
        """
        Find a move that results in an immediate win.
        """
        candidates = self._get_candidate_positions(board)
        
        for x, y in candidates:
            if board[x][y] == 0:
                board[x][y] = player_value
                if self._check_win(board, x, y, player_value):
                    board[x][y] = 0
                    return [x, y]
                board[x][y] = 0
        
        return None
    
    def _check_win(self, board: List[List[int]], x: int, y: int, player_value: int) -> bool:
        """
        Check if placing at the specified position results in a win.
        """
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        
        for dx, dy in directions:
            count = 1
            
            # Forward direction
            nx, ny = x + dx, y + dy
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
                   board[nx][ny] == player_value):
                count += 1
                nx, ny = nx + dx, ny + dy
            
            # Reverse direction
            nx, ny = x - dx, y - dy
            while (0 <= nx < self.board_size and 0 <= ny < self.board_size and 
                   board[nx][ny] == player_value):
                count += 1
                nx, ny = nx - dx, ny - dy
            
            if count >= 5:
                return True
        
        return False
    
    def _minimax_search(self, board: List[List[int]], my_value: int, opponent_value: int) -> List[int]:
        """
        Perform minimax search with alpha-beta pruning to find the best move.
        """
        best_score = -float('inf')
        best_move = None
        candidates = self._get_candidate_positions(board)
        
        alpha = -float('inf')
        beta = float('inf')
        
        for x, y in candidates:
            if board[x][y] == 0:
                board[x][y] = my_value
                score = self._minimax(
                    board, self.max_search_depth - 1, False, alpha, beta, 
                    my_value, opponent_value
                )
                board[x][y] = 0
                
                if score > best_score:
                    best_score = score
                    best_move = [x, y]
                    alpha = max(alpha, best_score)
                    
                if beta <= alpha:
                    break
        
        return best_move if best_move else self._get_safe_random_move(board)
    
    def _minimax(self, board: List[List[int]], depth: int, maximizing: bool, 
                 alpha: float, beta: float, my_value: int, opponent_value: int) -> float:
        """
        Minimax algorithm with alpha-beta pruning.
        """
        if depth == 0:
            return self._evaluate_board(board, my_value, opponent_value)
        
        current_value = my_value if maximizing else opponent_value
        candidates = self._get_candidate_positions(board)
        
        if maximizing:
            max_eval = -float('inf')
            for x, y in candidates:
                if board[x][y] == 0:
                    board[x][y] = current_value
                    
                    if self._check_win(board, x, y, current_value):
                        board[x][y] = 0
                        return float('inf')
                    
                    eval_score = self._minimax(
                        board, depth - 1, False, alpha, beta, my_value, opponent_value
                    )
                    board[x][y] = 0
                    
                    max_eval = max(max_eval, eval_score)
                    alpha = max(alpha, eval_score)
                    
                    if beta <= alpha:
                        break
                        
            return max_eval
        else: # Minimizing
            min_eval = float('inf')
            for x, y in candidates:
                if board[x][y] == 0:
                    board[x][y] = current_value
                    
                    if self._check_win(board, x, y, current_value):
                        board[x][y] = 0
                        return -float('inf')
                    
                    eval_score = self._minimax(
                        board, depth - 1, True, alpha, beta, my_value, opponent_value
                    )
                    board[x][y] = 0
                    
                    min_eval = min(min_eval, eval_score)
                    beta = min(beta, eval_score)
                    
                    if beta <= alpha:
                        break
                        
            return min_eval
    
    def _evaluate_board(self, board: List[List[int]], my_value: int, opponent_value: int) -> float:
        """
        Evaluate the entire board state.
        """
        my_score = self._calculate_player_score(board, my_value)
        opponent_score = self._calculate_player_score(board, opponent_value)
        return my_score - opponent_score
    
    def _calculate_player_score(self, board: List[List[int]], player_value: int) -> float:
        """
        Calculate score for a specific player based on patterns.
        """
        score = 0.0
        
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == player_value:
                    # Check patterns in all directions
                    directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
                    for dx, dy in directions:
                        score += self._evaluate_line(board, i, j, dx, dy, player_value)
        
        return score

    def _evaluate_line(self, board, x, y, dx, dy, player_value):
        """
        Evaluates a line for a player.
        """
        score = 0
        
        # Count consecutive pieces
        count = 0
        for i in range(5):
            nx, ny = x + i * dx, y + i * dy
            if 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                if board[nx][ny] == player_value:
                    count += 1
                elif board[nx][ny] != 0: # Opponent piece
                    return 0 # Blocked
            else: # Off board
                return 0 # Blocked
        
        if count == 5:
            score += 100000
        elif count == 4:
            score += 10000
        elif count == 3:
            score += 1000
        elif count == 2:
            score += 100
        elif count == 1:
            score += 10
            
        return score

    def _get_candidate_positions(self, board: List[List[int]]) -> List[Tuple[int, int]]:
        """
        Get candidate move positions around existing pieces.
        """
        candidates = set()
        
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] != 0:
                    for di in range(-self.candidate_radius, self.candidate_radius + 1):
                        for dj in range(-self.candidate_radius, self.candidate_radius + 1):
                            ni, nj = i + di, j + dj
                            if (0 <= ni < self.board_size and 
                                0 <= nj < self.board_size and 
                                board[ni][nj] == 0):
                                candidates.add((ni, nj))
        
        if not candidates:
            for i in range(self.board_size):
                for j in range(self.board_size):
                    if board[i][j] == 0:
                        candidates.add((i, j))
        
        return list(candidates)
    
    def _validate_move(self, board: List[List[int]], move: List[int]) -> None:
        """Validate the move position."""
        if not isinstance(move, list) or len(move) != 2:
            raise ValueError("Move must be a list of length 2")
        
        x, y = move
        if not (0 <= x < self.board_size and 0 <= y < self.board_size):
            raise ValueError(f"Move out of board range: ({x}, {y})")
        
        if board[x][y] != 0:
            raise ValueError(f"Move position already occupied: ({x}, {y})")
    
    def _get_safe_random_move(self, board: List[List[int]]) -> List[int]:
        """Get a safe random move position."""
        empty_positions = []
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == 0:
                    empty_positions.append([i, j])
        
        if empty_positions:
            return random.choice(empty_positions)
        else:
            center = self.board_size // 2
            return [center, center]
