"""
Texas Hold'em AI - Claude Sonnet 4.5
============================================================================
Advanced Texas Hold'em AI with sophisticated strategies including:
- Accurate preflop hand strength evaluation using Chen formula
- Postflop hand evaluation with proper poker hand ranking
- Position-aware decision making
- Pot odds and implied odds calculation
- Adaptive opponent modeling
- Strategic bluffing and semi-bluffing
- GTO-inspired mixed strategies
============================================================================
"""

import random
import math
import logging
from typing import Dict, List, Any, Tuple, Optional, Set
from collections import defaultdict, Counter
from itertools import combinations

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('claude_sonnet_4_5_holdem_ai')


class ClaudeSonnet45HoldemAI:
    """
    Advanced Texas Hold'em AI powered by Claude Sonnet 4.5

    Features:
    1. Chen formula for preflop hand evaluation
    2. Complete postflop hand ranking system
    3. Position-aware strategy adjustment
    4. Pot odds and expected value calculation
    5. Opponent modeling and exploitation
    6. Strategic bluffing and value betting
    7. Adaptive strategy based on game state
    """

    def __init__(self):
        """Initialize the AI with configuration and state tracking"""
        # ====================================================================
        # Basic Information (Must match ai_config.yaml)
        # ====================================================================
        self.ai_id = "Claude_4"
        self.name = "Claude Sonnet 4.5 Holdem AI"
        self.version = "1.0"
        self.description = "Advanced Texas Hold'em AI powered by Claude Sonnet 4.5"

        # ====================================================================
        # Strategy Parameters
        # ====================================================================
        self.base_aggression = 0.65
        self.bluff_frequency = 0.18
        self.position_awareness = True
        self.tight_aggressive = True

        # ====================================================================
        # Opponent Modeling
        # ====================================================================
        self.opponent_stats = defaultdict(lambda: {
            'hands_played': 0,
            'preflop_raises': 0,
            'preflop_calls': 0,
            'preflop_folds': 0,
            'postflop_aggression': 0,
            'showdowns': 0,
            'showdown_strength': [],
            'fold_to_raise': 0,
            'total_raises': 0,
        })

        # ====================================================================
        # Game State Tracking
        # ====================================================================
        self.hand_history = []
        self.current_hand_actions = []
        self.table_image = 'neutral'  # tight, loose, neutral, aggressive

        # ====================================================================
        # Card Rank Values
        # ====================================================================
        self.rank_values = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
            '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }

        logger.info(f"AI {self.name} initialized successfully")

    def get_info(self) -> Dict[str, Any]:
        """
        Get AI information (Required method)

        Returns:
            Dict: AI information including id, name, version, capabilities
        """
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "capabilities": [
                "hand_evaluation",
                "decision_making",
                "position_awareness",
                "opponent_modeling",
                "pot_odds_calculation",
                "bluffing",
                "hand_range_analysis",
                "adaptive_strategy"
            ]
        }

    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Core decision-making method (Required method)

        Args:
            game_state: Current game state information

        Returns:
            Dict: Decision with action and optional amount
        """
        try:
            # ================================================================
            # 1. Validate and Extract Game State
            # ================================================================
            valid_actions = game_state.get('valid_actions', [])
            if not valid_actions:
                logger.warning("No valid actions available")
                return {"action": "fold"}

            current_player = game_state.get('current_player')
            players = game_state.get('players', {})

            if current_player not in players:
                logger.error(f"Current player {current_player} not found")
                return self._safe_action(valid_actions)

            player_info = players[current_player]
            hole_cards = player_info.get('hole_cards', [])
            my_chips = player_info.get('chips', 0)
            my_current_bet = player_info.get('current_bet', 0)

            community_cards = game_state.get('community_cards', [])
            pot = game_state.get('pot', 0)
            current_bet = game_state.get('current_bet', 0)
            phase = game_state.get('phase', 'preflop')
            dealer_index = game_state.get('dealer_index', 0)

            # ================================================================
            # 2. Parse Available Actions
            # ================================================================
            available_actions = self._parse_valid_actions(valid_actions)

            # ================================================================
            # 3. Evaluate Hand Strength
            # ================================================================
            if phase == 'preflop':
                hand_strength = self._evaluate_preflop_strength(hole_cards)
                potential = self._evaluate_hand_potential(hole_cards)
            else:
                hand_strength = self._evaluate_postflop_strength(hole_cards, community_cards)
                potential = self._evaluate_draw_potential(hole_cards, community_cards)

            # ================================================================
            # 4. Position Analysis
            # ================================================================
            position = self._analyze_position(current_player, players, dealer_index)
            position_factor = self._get_position_factor(position)

            # ================================================================
            # 5. Calculate Pot Odds and Expected Value
            # ================================================================
            bet_to_call = current_bet - my_current_bet
            pot_odds = self._calculate_pot_odds(pot, bet_to_call)

            # ================================================================
            # 6. Opponent Analysis
            # ================================================================
            opponent_tendencies = self._analyze_opponents(players, current_player)

            # ================================================================
            # 7. Make Strategic Decision
            # ================================================================
            decision = self._make_strategic_decision(
                hand_strength=hand_strength,
                potential=potential,
                position=position,
                position_factor=position_factor,
                pot_odds=pot_odds,
                pot=pot,
                bet_to_call=bet_to_call,
                my_chips=my_chips,
                available_actions=available_actions,
                phase=phase,
                opponent_tendencies=opponent_tendencies,
                game_state=game_state
            )

            logger.info(f"Phase: {phase}, Hand: {hole_cards}, Strength: {hand_strength:.3f}, "
                       f"Position: {position}, Decision: {decision}")

            return decision

        except Exception as e:
            logger.error(f"Error in make_move: {e}", exc_info=True)
            return self._safe_action(valid_actions)

    def _parse_valid_actions(self, valid_actions: List[Dict]) -> Dict[str, Optional[Dict]]:
        """Parse available actions into a dictionary"""
        actions = {
            'fold': None,
            'check': None,
            'call': None,
            'raise': None,
            'all_in': None
        }

        for action in valid_actions:
            action_type = action.get('action')
            if action_type in actions:
                actions[action_type] = action

        return actions

    def _evaluate_preflop_strength(self, hole_cards: List[str]) -> float:
        """
        Evaluate preflop hand strength using Chen formula

        The Chen formula is a point-based system for evaluating starting hands:
        - Highest card value (max 10 points)
        - Pairs get double value
        - Suited cards get +2 points
        - Connected cards get points based on gap

        Args:
            hole_cards: Two hole cards

        Returns:
            float: Normalized hand strength (0.0-1.0)
        """
        if len(hole_cards) != 2:
            return 0.0

        card1, card2 = hole_cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)

        val1 = self.rank_values.get(rank1, 0)
        val2 = self.rank_values.get(rank2, 0)

        high_card = max(val1, val2)
        low_card = min(val1, val2)
        is_suited = (suit1 == suit2)
        is_pair = (val1 == val2)

        # Chen Formula Implementation
        points = 0.0

        # 1. Base points from highest card
        if high_card == 14:  # Ace
            points = 10
        elif high_card == 13:  # King
            points = 8
        elif high_card == 12:  # Queen
            points = 7
        elif high_card == 11:  # Jack
            points = 6
        else:
            points = (high_card - 2) / 2.0

        # 2. Pair bonus - multiply by 2 and max out at 10
        if is_pair:
            points = min(points * 2, 10)
            if high_card >= 5:
                points = max(points, 5)

        # 3. Suited bonus
        if is_suited:
            points += 2

        # 4. Gap penalty and straight potential
        if not is_pair:
            gap = abs(val1 - val2) - 1

            # Connected or one-gap cards
            if gap == 0:  # Connected
                points += 1
            elif gap == 1:  # One gap
                points += 0
            elif gap == 2:  # Two gap
                points -= 1
            elif gap == 3:  # Three gap
                points -= 2
            elif gap >= 4:  # Four+ gap
                points -= 4

            # Straight penalty for low cards
            if gap <= 1 and high_card < 12:
                points += 1

        # 5. Normalize to 0-1 range (max Chen score is around 20)
        normalized = min(points / 20.0, 1.0)

        # 6. Premium hand adjustments
        premium_hands = [
            (['A', 'A'], 1.0),
            (['K', 'K'], 0.98),
            (['Q', 'Q'], 0.95),
            (['A', 'K'], 0.92 if is_suited else 0.88),
            (['J', 'J'], 0.90),
            (['A', 'Q'], 0.85 if is_suited else 0.78),
            (['K', 'Q'], 0.82 if is_suited else 0.75),
            (['10', '10'], 0.85),
        ]

        for premium_ranks, premium_value in premium_hands:
            if sorted([rank1, rank2]) == sorted(premium_ranks):
                normalized = max(normalized, premium_value)
                break

        return max(0.0, min(1.0, normalized))

    def _evaluate_postflop_strength(self, hole_cards: List[str],
                                   community_cards: List[str]) -> float:
        """
        Evaluate postflop hand strength using proper poker hand ranking

        Args:
            hole_cards: Player's hole cards
            community_cards: Community cards on the board

        Returns:
            float: Hand strength (0.0-1.0)
        """
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return self._evaluate_preflop_strength(hole_cards) * 0.8

        # Evaluate best 5-card hand
        best_rank, rank_values = self._get_best_hand(all_cards)

        # Map hand rank to strength
        rank_to_base_strength = {
            'royal_flush': 1.0,
            'straight_flush': 0.98,
            'four_of_a_kind': 0.94,
            'full_house': 0.88,
            'flush': 0.80,
            'straight': 0.70,
            'three_of_a_kind': 0.60,
            'two_pair': 0.48,
            'one_pair': 0.35,
            'high_card': 0.20
        }

        base_strength = rank_to_base_strength.get(best_rank, 0.20)

        # Adjust based on kicker strength
        if rank_values:
            kicker_bonus = (rank_values[0] - 2) / 120.0  # Small adjustment for high kickers
            base_strength += kicker_bonus

        return min(1.0, base_strength)

    def _get_best_hand(self, cards: List[str]) -> Tuple[str, List[int]]:
        """
        Determine the best 5-card poker hand from available cards

        Args:
            cards: List of cards to evaluate

        Returns:
            Tuple of (hand_rank, rank_values for comparison)
        """
        if len(cards) < 5:
            return 'high_card', []

        # Check all 5-card combinations
        best_rank = 'high_card'
        best_values = []
        best_rank_score = 0

        rank_scores = {
            'high_card': 1, 'one_pair': 2, 'two_pair': 3, 'three_of_a_kind': 4,
            'straight': 5, 'flush': 6, 'full_house': 7, 'four_of_a_kind': 8,
            'straight_flush': 9, 'royal_flush': 10
        }

        for combo in combinations(cards, 5):
            rank, values = self._evaluate_five_cards(list(combo))
            score = rank_scores.get(rank, 0)

            if score > best_rank_score or (score == best_rank_score and values > best_values):
                best_rank = rank
                best_values = values
                best_rank_score = score

        return best_rank, best_values

    def _evaluate_five_cards(self, cards: List[str]) -> Tuple[str, List[int]]:
        """
        Evaluate exactly 5 cards and return the poker hand rank

        Args:
            cards: Exactly 5 cards

        Returns:
            Tuple of (hand_rank, rank_values)
        """
        if len(cards) != 5:
            return 'high_card', []

        # Parse cards
        parsed = [self._parse_card(c) for c in cards]
        ranks = [self.rank_values[r] for r, s in parsed]
        suits = [s for r, s in parsed]

        # Count ranks and suits
        rank_counts = Counter(ranks)
        suit_counts = Counter(suits)

        # Sort ranks by count then value
        sorted_ranks = sorted(rank_counts.items(), key=lambda x: (x[1], x[0]), reverse=True)
        rank_values = [r for r, c in sorted_ranks]

        # Check for flush
        is_flush = max(suit_counts.values()) == 5

        # Check for straight
        sorted_unique_ranks = sorted(set(ranks), reverse=True)
        is_straight = False
        straight_high = 0

        if len(sorted_unique_ranks) == 5:
            # Normal straight
            if sorted_unique_ranks[0] - sorted_unique_ranks[4] == 4:
                is_straight = True
                straight_high = sorted_unique_ranks[0]
            # A-2-3-4-5 (wheel)
            elif sorted_unique_ranks == [14, 5, 4, 3, 2]:
                is_straight = True
                straight_high = 5  # In wheel, 5 is high

        # Determine hand rank
        counts = [c for r, c in sorted_ranks]

        # Royal Flush: A-K-Q-J-10 suited
        if is_straight and is_flush and straight_high == 14 and 13 in ranks:
            return 'royal_flush', [14]

        # Straight Flush
        if is_straight and is_flush:
            return 'straight_flush', [straight_high]

        # Four of a Kind
        if counts[0] == 4:
            return 'four_of_a_kind', rank_values

        # Full House
        if counts[0] == 3 and counts[1] == 2:
            return 'full_house', rank_values

        # Flush
        if is_flush:
            return 'flush', sorted(ranks, reverse=True)

        # Straight
        if is_straight:
            return 'straight', [straight_high]

        # Three of a Kind
        if counts[0] == 3:
            return 'three_of_a_kind', rank_values

        # Two Pair
        if counts[0] == 2 and counts[1] == 2:
            return 'two_pair', rank_values

        # One Pair
        if counts[0] == 2:
            return 'one_pair', rank_values

        # High Card
        return 'high_card', sorted(ranks, reverse=True)

    def _evaluate_hand_potential(self, hole_cards: List[str]) -> float:
        """
        Evaluate potential of preflop hand for improvement

        Args:
            hole_cards: Two hole cards

        Returns:
            float: Potential score (0.0-1.0)
        """
        if len(hole_cards) != 2:
            return 0.0

        card1, card2 = hole_cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)

        val1 = self.rank_values.get(rank1, 0)
        val2 = self.rank_values.get(rank2, 0)

        is_suited = (suit1 == suit2)
        is_pair = (val1 == val2)
        gap = abs(val1 - val2)

        potential = 0.5  # Base potential

        # Suited cards have flush potential
        if is_suited:
            potential += 0.2

        # Connected cards have straight potential
        if gap <= 1:
            potential += 0.2
        elif gap <= 3:
            potential += 0.1

        # Pairs have set potential
        if is_pair:
            potential += 0.15

        # High cards have high pair potential
        if max(val1, val2) >= 12:
            potential += 0.1

        return min(1.0, potential)

    def _evaluate_draw_potential(self, hole_cards: List[str],
                                 community_cards: List[str]) -> float:
        """
        Evaluate drawing potential on flop/turn

        Args:
            hole_cards: Player's hole cards
            community_cards: Community cards

        Returns:
            float: Draw potential (0.0-1.0)
        """
        all_cards = hole_cards + community_cards

        if len(all_cards) < 5:
            return 0.3

        # Count suits and ranks for draw detection
        parsed = [self._parse_card(c) for c in all_cards]
        suits = [s for r, s in parsed]
        ranks = [self.rank_values[r] for r, s in parsed]

        suit_counts = Counter(suits)
        potential = 0.0

        # Flush draw (4 cards of same suit)
        if max(suit_counts.values()) == 4:
            potential += 0.35  # ~35% to hit flush

        # Straight draw detection (simplified)
        sorted_ranks = sorted(set(ranks))
        for i in range(len(sorted_ranks) - 3):
            window = sorted_ranks[i:i+4]
            if window[-1] - window[0] <= 4:
                potential += 0.25  # Open-ended or gutshot
                break

        return min(1.0, potential)

    def _analyze_position(self, current_player: str, players: Dict,
                         dealer_index: int) -> str:
        """
        Analyze player position at the table

        Args:
            current_player: Current player ID
            players: All players
            dealer_index: Dealer position

        Returns:
            str: Position ('early', 'middle', 'late', 'blinds')
        """
        active_players = [pid for pid, pinfo in players.items()
                         if pinfo.get('state') == 'active']

        if current_player not in active_players:
            return 'unknown'

        player_count = len(active_players)
        player_index = active_players.index(current_player)

        # Determine position based on player count
        if player_count <= 2:
            return 'heads_up'
        elif player_count <= 4:
            # Short-handed
            if player_index <= 1:
                return 'blinds'
            else:
                return 'late'
        elif player_count <= 6:
            # 6-max
            if player_index <= 1:
                return 'blinds'
            elif player_index <= 2:
                return 'early'
            elif player_index <= 4:
                return 'middle'
            else:
                return 'late'
        else:
            # Full ring
            if player_index <= 2:
                return 'blinds'
            elif player_index <= 4:
                return 'early'
            elif player_index <= player_count - 3:
                return 'middle'
            else:
                return 'late'

    def _get_position_factor(self, position: str) -> float:
        """
        Get position adjustment factor for decision making

        Args:
            position: Position string

        Returns:
            float: Position factor multiplier
        """
        factors = {
            'blinds': 0.85,      # Worst position
            'early': 0.90,       # Conservative
            'middle': 1.00,      # Normal
            'late': 1.15,        # Aggressive
            'heads_up': 1.10,    # More aggressive
            'unknown': 0.95
        }
        return factors.get(position, 1.0)

    def _calculate_pot_odds(self, pot_size: int, bet_to_call: int) -> float:
        """
        Calculate pot odds for calling decisions

        Args:
            pot_size: Current pot size
            bet_to_call: Amount to call

        Returns:
            float: Pot odds ratio
        """
        if bet_to_call <= 0:
            return float('inf')
        return pot_size / bet_to_call

    def _analyze_opponents(self, players: Dict, current_player: str) -> Dict[str, Any]:
        """
        Analyze opponent tendencies

        Args:
            players: All players
            current_player: Current player ID

        Returns:
            Dict: Opponent analysis
        """
        opponents = {pid: pinfo for pid, pinfo in players.items()
                    if pid != current_player and pinfo.get('state') == 'active'}

        return {
            'count': len(opponents),
            'average_stack': sum(p.get('chips', 0) for p in opponents.values()) / max(len(opponents), 1),
            'aggressive_count': 0,  # Would be populated with tracking
        }

    def _make_strategic_decision(self, hand_strength: float, potential: float,
                                position: str, position_factor: float,
                                pot_odds: float, pot: int, bet_to_call: int,
                                my_chips: int, available_actions: Dict,
                                phase: str, opponent_tendencies: Dict,
                                game_state: Dict) -> Dict[str, Any]:
        """
        Make strategic decision based on all factors

        This is the core decision engine that weighs all factors
        """
        # Adjust hand strength by position
        adjusted_strength = hand_strength * position_factor

        # Add potential to strength (especially preflop)
        if phase == 'preflop':
            effective_strength = adjusted_strength * 0.7 + potential * 0.3
        else:
            effective_strength = adjusted_strength * 0.85 + potential * 0.15

        # Decision thresholds
        PREMIUM_THRESHOLD = 0.85
        STRONG_THRESHOLD = 0.70
        GOOD_THRESHOLD = 0.55
        PLAYABLE_THRESHOLD = 0.40
        MARGINAL_THRESHOLD = 0.25

        # ================================================================
        # Premium Hands - Always aggressive
        # ================================================================
        if effective_strength >= PREMIUM_THRESHOLD:
            if available_actions['raise']:
                amount = self._calculate_raise_amount(
                    pot, bet_to_call, 'value_bet', my_chips, effective_strength
                )
                return {"action": "raise", "amount": amount}
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']

        # ================================================================
        # Strong Hands - Value betting
        # ================================================================
        elif effective_strength >= STRONG_THRESHOLD:
            # Check pot odds if we need to call
            if bet_to_call > 0 and pot_odds < 2:
                # Bad pot odds, but strong hand - raise if possible
                if available_actions['raise'] and position in ['late', 'middle']:
                    amount = self._calculate_raise_amount(
                        pot, bet_to_call, 'value_bet', my_chips, effective_strength
                    )
                    return {"action": "raise", "amount": amount}
                elif available_actions['call']:
                    return available_actions['call']

            # Good pot odds or no bet to call
            if available_actions['raise'] and position == 'late':
                amount = self._calculate_raise_amount(
                    pot, bet_to_call, 'value_bet', my_chips, effective_strength
                )
                return {"action": "raise", "amount": amount}
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']

        # ================================================================
        # Good Hands - Selective aggression
        # ================================================================
        elif effective_strength >= GOOD_THRESHOLD:
            if available_actions['check']:
                return available_actions['check']
            elif bet_to_call > 0:
                # Check pot odds
                if pot_odds >= 3:
                    if available_actions['call']:
                        return available_actions['call']
                elif position == 'late' and self._should_bluff():
                    if available_actions['raise']:
                        amount = self._calculate_raise_amount(
                            pot, bet_to_call, 'semi_bluff', my_chips, effective_strength
                        )
                        return {"action": "raise", "amount": amount}

        # ================================================================
        # Playable Hands - Position dependent
        # ================================================================
        elif effective_strength >= PLAYABLE_THRESHOLD:
            if available_actions['check']:
                return available_actions['check']
            elif bet_to_call > 0:
                # Only call with good pot odds
                if pot_odds >= 4 and bet_to_call < my_chips * 0.1:
                    if available_actions['call']:
                        return available_actions['call']
            # Late position bluff opportunity
            elif position == 'late' and phase == 'preflop' and self._should_bluff():
                if available_actions['raise']:
                    amount = self._calculate_raise_amount(
                        pot, bet_to_call, 'bluff', my_chips, effective_strength
                    )
                    return {"action": "raise", "amount": amount}

        # ================================================================
        # Marginal/Weak Hands - Mostly fold
        # ================================================================
        else:
            if available_actions['check']:
                return available_actions['check']
            elif bet_to_call > 0:
                # Only call with excellent pot odds
                if pot_odds >= 6 and bet_to_call < my_chips * 0.05:
                    if available_actions['call']:
                        return available_actions['call']

        # ================================================================
        # Default: Fold or check
        # ================================================================
        if available_actions['fold']:
            return available_actions['fold']
        elif available_actions['check']:
            return available_actions['check']

        # Last resort - take first available action
        for action in available_actions.values():
            if action is not None:
                return action

        return {"action": "fold"}

    def _calculate_raise_amount(self, pot: int, bet_to_call: int,
                               raise_type: str, my_chips: int,
                               hand_strength: float) -> int:
        """
        Calculate optimal raise amount

        Args:
            pot: Current pot size
            bet_to_call: Amount to call
            raise_type: Type of raise ('value_bet', 'semi_bluff', 'bluff')
            my_chips: Player's chip stack
            hand_strength: Current hand strength

        Returns:
            int: Raise amount
        """
        # Base multipliers by raise type
        if raise_type == 'value_bet':
            # Larger raises with strong hands
            if hand_strength >= 0.9:
                multiplier = 0.8
            elif hand_strength >= 0.75:
                multiplier = 0.7
            else:
                multiplier = 0.6
        elif raise_type == 'semi_bluff':
            multiplier = 0.5
        else:  # bluff
            multiplier = 0.4

        # Calculate raise amount
        total_pot = pot + bet_to_call
        raise_amount = int(total_pot * multiplier)

        # Ensure minimum raise (2x current bet)
        min_raise = bet_to_call * 2 if bet_to_call > 0 else pot // 2
        raise_amount = max(raise_amount, min_raise)

        # Cap at reasonable percentage of stack
        max_raise = int(my_chips * 0.6)
        raise_amount = min(raise_amount, max_raise)

        # Ensure we have chips to cover
        raise_amount = min(raise_amount, my_chips)

        return max(raise_amount, min_raise)

    def _should_bluff(self) -> bool:
        """
        Determine if we should bluff based on frequency and randomness

        Returns:
            bool: True if should bluff
        """
        return random.random() < self.bluff_frequency

    def _parse_card(self, card: str) -> Tuple[str, str]:
        """
        Parse card string into rank and suit

        Args:
            card: Card string (e.g., 'As', 'Kh', '10d')

        Returns:
            Tuple of (rank, suit)
        """
        if len(card) == 2:
            return card[0], card[1]
        elif len(card) == 3 and card[:2] == '10':
            return '10', card[2]
        else:
            # Handle edge cases
            return card[:-1], card[-1]

    def _safe_action(self, valid_actions: List[Dict]) -> Dict[str, Any]:
        """
        Return a safe fallback action

        Args:
            valid_actions: List of valid actions

        Returns:
            Dict: Safe action
        """
        # Prefer check > call > fold
        for preferred in ['check', 'call', 'fold']:
            action = next((a for a in valid_actions if a.get('action') == preferred), None)
            if action:
                return action

        # Return first available
        if valid_actions:
            return valid_actions[0]

        return {"action": "fold"}

    def reset(self):
        """
        Reset AI state for a new game (Optional method)
        """
        self.opponent_stats.clear()
        self.hand_history.clear()
        self.current_hand_actions.clear()
        self.table_image = 'neutral'
        logger.info(f"AI {self.name} reset successfully")


# ============================================================================
# Test Code
# ============================================================================
if __name__ == "__main__":
    # Create AI instance
    ai = ClaudeSonnet45HoldemAI()

    # Test AI info
    print("=" * 70)
    print("AI Information:")
    print("=" * 70)
    info = ai.get_info()
    for key, value in info.items():
        print(f"{key}: {value}")

    # Test preflop strength evaluation
    print("\n" + "=" * 70)
    print("Preflop Hand Strength Tests:")
    print("=" * 70)
    test_hands = [
        (['As', 'Ah'], "Pocket Aces"),
        (['Ks', 'Kh'], "Pocket Kings"),
        (['As', 'Ks'], "Ace-King Suited"),
        (['Ah', 'Kd'], "Ace-King Offsuit"),
        (['Qs', 'Js'], "Queen-Jack Suited"),
        (['10h', '9h'], "Ten-Nine Suited"),
        (['7s', '2c'], "Seven-Two Offsuit"),
        (['As', '2s'], "Ace-Two Suited"),
    ]

    for hand, description in test_hands:
        strength = ai._evaluate_preflop_strength(hand)
        print(f"{description:25s} {hand}: {strength:.3f}")

    # Test decision making
    print("\n" + "=" * 70)
    print("Decision Making Test:")
    print("=" * 70)
    test_game_state = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 20},
            {'action': 'raise', 'min_amount': 40, 'max_amount': 200}
        ],
        'players': {
            'player1': {
                'hole_cards': ['As', 'Kh'],
                'chips': 1000,
                'current_bet': 10,
                'state': 'active'
            },
            'player2': {
                'hole_cards': ['?', '?'],
                'chips': 950,
                'current_bet': 20,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': [],
        'pot': 30,
        'current_bet': 20,
        'phase': 'preflop',
        'dealer_index': 0
    }

    print("Game State:")
    print(f"  Hand: {test_game_state['players']['player1']['hole_cards']}")
    print(f"  Phase: {test_game_state['phase']}")
    print(f"  Pot: {test_game_state['pot']}")
    print(f"  Current Bet: {test_game_state['current_bet']}")
    print(f"  My Chips: {test_game_state['players']['player1']['chips']}")

    decision = ai.make_move(test_game_state)
    print(f"\nDecision: {decision}")

    print("\n" + "=" * 70)
    print("AI Test Complete!")
    print("=" * 70)
