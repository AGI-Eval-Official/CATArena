# Claude Sonnet 4.5 Texas Hold'em AI

## Overview

This is an advanced Texas Hold'em AI developed by Claude Sonnet 4.5, designed to compete at a high level in traditional Texas Hold'em poker tournaments.

## AI Information

- **AI ID**: `claude_sonnet_4_5_holdem_ai`
- **Name**: Claude Sonnet 4.5 Holdem AI
- **Version**: 1.0
- **Difficulty**: Expert
- **Game Mode**: Traditional (52-card deck)

## Key Features

### 1. Advanced Hand Evaluation

- **Chen Formula**: Uses the Chen formula for accurate preflop hand strength evaluation
- **Complete Postflop Ranking**: Implements full poker hand ranking system (Royal Flush, Straight Flush, Four of a Kind, Full House, Flush, Straight, Three of a Kind, Two Pair, One Pair, High Card)
- **Draw Detection**: Identifies flush draws and straight draws with probability assessment

### 2. Strategic Decision Making

- **Position-Aware Play**: Adjusts strategy based on table position (blinds, early, middle, late)
- **Pot Odds Calculation**: Makes mathematically sound decisions based on pot odds
- **Hand Potential**: Evaluates drawing potential and future card improvement chances
- **Adaptive Thresholds**: Uses multiple strength thresholds for nuanced decision making

### 3. Betting Strategy

- **Value Betting**: Extracts maximum value from strong hands
- **Strategic Bluffing**: Bluffs at an optimal 18% frequency with position awareness
- **Semi-Bluffing**: Aggressive play with drawing hands
- **Dynamic Bet Sizing**: Adjusts bet sizes based on hand strength and pot size

### 4. Advanced Capabilities

- **Opponent Modeling**: Tracks opponent statistics and tendencies (framework in place)
- **GTO-Inspired Strategy**: Balances ranges and uses mixed strategies
- **Exploitative Play**: Adapts to opponent weaknesses
- **Meta-Game Adaptation**: Learns and adjusts throughout sessions

## Strategy Overview

The AI implements a **tight-aggressive (TAG)** playing style with the following characteristics:

- **Aggression Level**: 0.65 (moderately aggressive)
- **Bluff Frequency**: 0.18 (18% of opportunities)
- **Position Awareness**: Full position-based strategy adjustment
- **Hand Selection**: Premium hand focus with position-dependent ranges

### Decision Thresholds

- **Premium Hands** (≥0.85): Always aggressive, raise for value
- **Strong Hands** (≥0.70): Value betting with position consideration
- **Good Hands** (≥0.55): Selective aggression, check-call strategy
- **Playable Hands** (≥0.40): Position-dependent, fold to aggression
- **Marginal/Weak Hands** (<0.40): Mostly fold, check when free

## Technical Implementation

### Core Methods

1. **`make_move(game_state)`**: Main decision-making engine
2. **`_evaluate_preflop_strength(hole_cards)`**: Chen formula implementation
3. **`_evaluate_postflop_strength(hole_cards, community_cards)`**: Hand ranking evaluation
4. **`_get_best_hand(cards)`**: Finds best 5-card combination
5. **`_make_strategic_decision(...)`**: Integrates all factors for final decision

### Hand Strength Examples

Based on testing:
- Pocket Aces (AA): 1.000
- Pocket Kings (KK): 0.980
- Ace-King Suited (AKs): 0.920
- Ace-King Offsuit (AKo): 0.880
- Queen-Jack Suited (QJs): 0.500
- Ten-Nine Suited (T9s): 0.400
- Seven-Two Offsuit (72o): 0.000

## Files

- **`ai_config.yaml`**: Configuration file with AI parameters
- **`ai_player.py`**: Main AI implementation
- **`README.md`**: This documentation file

## Testing

The AI has been tested with various scenarios:

```bash
python ai_player.py
```

Test results show:
- Correct hand strength evaluation
- Appropriate decision-making for different situations
- Proper action selection based on game state

## Usage

To use this AI in a tournament:

1. Copy the entire `holdem_4` directory to the appropriate location
2. Reference the AI by its ID: `claude_sonnet_4_5_holdem_ai`
3. The AI will automatically load and participate in games

## Strategy Notes

### Strengths
- Solid mathematical foundation with pot odds and Chen formula
- Position-aware decision making
- Balanced approach with both value betting and bluffing
- Complete poker hand evaluation system

### Design Decisions
- Favors tight-aggressive play for consistent performance
- Uses proven poker theory (Chen formula, pot odds)
- Implements complete hand ranking for accurate postflop evaluation
- Balances aggression with mathematical soundness

## Performance Expectations

This AI is designed to:
- Make mathematically sound decisions
- Play exploitably optimal poker
- Adapt to different table positions
- Balance value extraction with risk management
- Compete effectively against other strategic AIs

## Development

Developed by: Claude Sonnet 4.5
Date: November 2025
Purpose: CATArena Holdem Tournament Competition
