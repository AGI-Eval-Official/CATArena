"""
Additional test scenarios for the AI
"""
from ai_player import ClaudeSonnet45HoldemAI


def test_postflop_scenarios():
    """Test AI with postflop situations"""
    ai = ClaudeSonnet45HoldemAI()

    print("=" * 70)
    print("POSTFLOP SCENARIOS TEST")
    print("=" * 70)

    # Scenario 1: Flop with made hand
    print("\n--- Scenario 1: Top Pair on Flop ---")
    game_state = {
        'valid_actions': [
            {'action': 'check'},
            {'action': 'raise', 'min_amount': 30, 'max_amount': 150}
        ],
        'players': {
            'player1': {
                'hole_cards': ['Ah', 'Kd'],
                'chips': 900,
                'current_bet': 0,
                'state': 'active'
            },
            'player2': {
                'chips': 850,
                'current_bet': 0,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': ['As', '7c', '3h'],
        'pot': 60,
        'current_bet': 0,
        'phase': 'flop',
        'dealer_index': 0
    }

    decision = ai.make_move(game_state)
    print(f"Hand: {game_state['players']['player1']['hole_cards']}")
    print(f"Board: {game_state['community_cards']}")
    print(f"Decision: {decision}")

    # Scenario 2: Flush draw
    print("\n--- Scenario 2: Flush Draw on Turn ---")
    game_state = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 50},
            {'action': 'raise', 'min_amount': 100, 'max_amount': 200}
        ],
        'players': {
            'player1': {
                'hole_cards': ['Kh', 'Qh'],
                'chips': 800,
                'current_bet': 20,
                'state': 'active'
            },
            'player2': {
                'chips': 750,
                'current_bet': 50,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': ['Ah', '7h', '3c', '9d'],
        'pot': 120,
        'current_bet': 50,
        'phase': 'turn',
        'dealer_index': 1
    }

    decision = ai.make_move(game_state)
    print(f"Hand: {game_state['players']['player1']['hole_cards']}")
    print(f"Board: {game_state['community_cards']}")
    print(f"Decision: {decision}")

    # Scenario 3: Weak hand facing bet
    print("\n--- Scenario 3: Weak Hand Facing Large Bet ---")
    game_state = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 150}
        ],
        'players': {
            'player1': {
                'hole_cards': ['9c', '8d'],
                'chips': 700,
                'current_bet': 50,
                'state': 'active'
            },
            'player2': {
                'chips': 650,
                'current_bet': 150,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': ['Ah', 'Kh', 'Qs', '2c'],
        'pot': 250,
        'current_bet': 150,
        'phase': 'turn',
        'dealer_index': 0
    }

    decision = ai.make_move(game_state)
    print(f"Hand: {game_state['players']['player1']['hole_cards']}")
    print(f"Board: {game_state['community_cards']}")
    print(f"Decision: {decision}")

    # Scenario 4: Set on flop
    print("\n--- Scenario 4: Set (Three of a Kind) on Flop ---")
    game_state = {
        'valid_actions': [
            {'action': 'check'},
            {'action': 'raise', 'min_amount': 40, 'max_amount': 200}
        ],
        'players': {
            'player1': {
                'hole_cards': ['8h', '8d'],
                'chips': 950,
                'current_bet': 0,
                'state': 'active'
            },
            'player2': {
                'chips': 900,
                'current_bet': 0,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': ['8s', 'Kc', '3h'],
        'pot': 60,
        'current_bet': 0,
        'phase': 'flop',
        'dealer_index': 0
    }

    decision = ai.make_move(game_state)
    print(f"Hand: {game_state['players']['player1']['hole_cards']}")
    print(f"Board: {game_state['community_cards']}")
    print(f"Decision: {decision}")


def test_position_awareness():
    """Test position-aware decision making"""
    ai = ClaudeSonnet45HoldemAI()

    print("\n" + "=" * 70)
    print("POSITION AWARENESS TEST")
    print("=" * 70)

    # Same marginal hand from different positions
    positions = ['blinds', 'early', 'middle', 'late']

    for pos_idx, position_name in enumerate(positions):
        print(f"\n--- {position_name.upper()} Position ---")

        # Create game state with 6 players
        players = {}
        for i in range(6):
            players[f'player{i}'] = {
                'chips': 1000,
                'current_bet': 0,
                'state': 'active'
            }

        players['player0']['hole_cards'] = ['Jh', '10s']

        game_state = {
            'valid_actions': [
                {'action': 'fold'},
                {'action': 'check'},
                {'action': 'raise', 'min_amount': 20, 'max_amount': 100}
            ],
            'players': players,
            'current_player': 'player0',
            'community_cards': [],
            'pot': 15,
            'current_bet': 0,
            'phase': 'preflop',
            'dealer_index': (6 - pos_idx) % 6
        }

        decision = ai.make_move(game_state)
        pos = ai._analyze_position('player0', players, game_state['dealer_index'])
        print(f"Hand: J-10 offsuit")
        print(f"Detected Position: {pos}")
        print(f"Decision: {decision}")


def test_hand_evaluation():
    """Test hand evaluation accuracy"""
    ai = ClaudeSonnet45HoldemAI()

    print("\n" + "=" * 70)
    print("HAND EVALUATION ACCURACY TEST")
    print("=" * 70)

    print("\n--- Postflop Hand Rankings ---")

    test_cases = [
        (['As', 'Ks'], ['Qs', 'Js', '10s'], "Royal Flush"),
        (['9h', '8h'], ['7h', '6h', '5h'], "Straight Flush"),
        (['Kd', 'Kc'], ['Ks', 'Kh', '7d'], "Four of a Kind"),
        (['Ah', 'Ad'], ['As', '5c', '5d'], "Full House"),
        (['2h', '3h'], ['7h', '9h', 'Jh'], "Flush"),
        (['9c', '8d'], ['7s', '6h', '5c'], "Straight"),
        (['Qh', 'Qd'], ['Qs', '7c', '4h'], "Three of a Kind"),
        (['Jh', 'Jd'], ['9s', '9c', '4h'], "Two Pair"),
        (['Ah', '7d'], ['As', '5c', '2h'], "One Pair"),
        (['Ah', 'Kd'], ['Qs', '8c', '3h'], "High Card"),
    ]

    for hole, board, expected in test_cases:
        strength = ai._evaluate_postflop_strength(hole, board)
        rank, values = ai._get_best_hand(hole + board)
        print(f"{expected:20s} - Strength: {strength:.3f} - Detected: {rank}")


if __name__ == "__main__":
    test_postflop_scenarios()
    test_position_awareness()
    test_hand_evaluation()

    print("\n" + "=" * 70)
    print("ALL TESTS COMPLETED")
    print("=" * 70)
