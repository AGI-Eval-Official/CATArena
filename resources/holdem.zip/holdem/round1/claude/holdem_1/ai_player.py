"""
Claude Sonnet 4.5 Texas Hold'em AI - Traditional Mode
============================================================================
A competitive Texas Hold'em AI featuring:
- Advanced hand evaluation using proper poker logic
- Position-based strategy adjustment
- Pot odds and expected value calculations
- Opponent modeling and exploitation
- Adaptive aggression levels
- Strategic bluffing and semi-bluffing
============================================================================
"""

import sys
import os
import random
import math
import logging
from typing import Dict, List, Any, Tuple, Optional
from collections import defaultdict, Counter
from itertools import combinations

# Add the poker engine to the path to use proper hand evaluation
poker_engine_path = '/data/CATArena/GamesEnv/games/holdem/engines'
if poker_engine_path not in sys.path:
    sys.path.insert(0, poker_engine_path)

try:
    from poker_logic import (
        Card, HandEvaluator, HandRank,
        create_card_from_string, string_list_to_cards
    )
    POKER_ENGINE_AVAILABLE = True
except ImportError:
    POKER_ENGINE_AVAILABLE = False
    logging.warning("Poker engine not available, using fallback evaluation")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('sonnet_4_5_AI')


class ClaudeSonnet45AI:
    """
    Claude Sonnet 4.5 Texas Hold'em AI

    A competitive AI designed to win tournaments through:
    1. Accurate hand strength evaluation
    2. Position-aware decision making
    3. Pot odds and equity calculations
    4. Opponent pattern recognition
    5. Adaptive strategy based on game state
    """

    def __init__(self):
        """Initialize the AI with competitive parameters"""
        # ====================================================================
        # Basic Information
        # ====================================================================
        self.ai_id = "Claude_1"
        self.name = "Claude Sonnet 4.5 AI"
        self.version = "1.0.0"
        self.description = "Advanced competitive Texas Hold'em AI"

        # ====================================================================
        # Strategy Parameters
        # ====================================================================
        self.base_aggression = 0.7          # Base aggression level
        self.bluff_frequency = 0.18         # Strategic bluff rate
        self.semi_bluff_frequency = 0.25    # Semi-bluff with draws
        self.c_bet_frequency = 0.65         # Continuation bet rate
        self.position_awareness = True
        self.tight_aggressive = True

        # ====================================================================
        # Hand Strength Thresholds
        # ====================================================================
        self.PREMIUM_THRESHOLD = 0.85       # Premium hands (AA, KK, AK)
        self.VERY_STRONG_THRESHOLD = 0.75   # Very strong hands
        self.STRONG_THRESHOLD = 0.60        # Strong hands
        self.PLAYABLE_THRESHOLD = 0.40      # Playable hands
        self.MARGINAL_THRESHOLD = 0.25      # Marginal hands

        # ====================================================================
        # Opponent Modeling
        # ====================================================================
        self.opponent_stats = defaultdict(lambda: {
            'hands_played': 0,
            'vpip': 0.0,              # Voluntarily Put In Pot
            'pfr': 0.0,               # Pre-Flop Raise
            'aggression_factor': 1.0,  # Bet/Raise vs Call ratio
            'fold_to_cbet': 0.5,      # Fold to continuation bet
            'showdown_hands': [],
            'actions': []
        })

        # ====================================================================
        # Game State Tracking
        # ====================================================================
        self.hand_history = []
        self.current_hand_actions = []
        self.last_action = None
        self.is_preflop_raiser = False

        # ====================================================================
        # Position Factors
        # ====================================================================
        self.position_multipliers = {
            'early': 0.85,    # More conservative early
            'middle': 1.0,    # Standard middle
            'late': 1.15      # More aggressive late
        }

        logger.info(f"AI {self.name} v{self.version} initialized successfully")

    def get_info(self) -> Dict[str, Any]:
        """Return AI information"""
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "capabilities": [
                "hand_evaluation",
                "decision_making",
                "position_awareness",
                "opponent_modeling",
                "pot_odds_calculation",
                "bluffing",
                "hand_range_analysis"
            ]
        }

    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make a decision based on game state

        Core decision-making process:
        1. Parse game state and validate inputs
        2. Evaluate hand strength (preflop or postflop)
        3. Analyze position
        4. Calculate pot odds and equity
        5. Consider opponent tendencies
        6. Make strategic decision
        """
        try:
            # ============================================================
            # 1. Extract and validate game state
            # ============================================================
            valid_actions = game_state.get('valid_actions', [])
            if not valid_actions:
                return {"action": "fold"}

            current_player = game_state.get('current_player')
            players = game_state.get('players', {})

            if current_player not in players:
                logger.error(f"Player {current_player} not found")
                return self._safe_fold(valid_actions)

            player_info = players[current_player]
            hole_cards = player_info.get('hole_cards', [])
            my_chips = player_info.get('chips', 0)
            my_current_bet = player_info.get('current_bet', 0)

            community_cards = game_state.get('community_cards', [])
            pot = game_state.get('pot', 0)
            current_bet = game_state.get('current_bet', 0)
            phase = game_state.get('phase', 'preflop')
            dealer_index = game_state.get('dealer_index', 0)

            # ============================================================
            # 2. Parse available actions
            # ============================================================
            available_actions = self._parse_valid_actions(valid_actions)

            # ============================================================
            # 3. Evaluate hand strength
            # ============================================================
            hand_strength = self.evaluate_hand_strength(
                hole_cards, community_cards, phase
            )

            # ============================================================
            # 4. Analyze position
            # ============================================================
            position = self.analyze_position(current_player, players, dealer_index)
            position_factor = self.position_multipliers.get(position, 1.0)

            # ============================================================
            # 5. Calculate pot odds
            # ============================================================
            bet_to_call = current_bet - my_current_bet
            pot_odds = self.calculate_pot_odds(pot, bet_to_call)

            # ============================================================
            # 6. Calculate effective hand strength (with position)
            # ============================================================
            effective_strength = hand_strength * position_factor

            # ============================================================
            # 7. Determine number of active opponents
            # ============================================================
            active_opponents = sum(
                1 for pid, pinfo in players.items()
                if pid != current_player and pinfo.get('state') == 'active'
            )

            # ============================================================
            # 8. Calculate stack-to-pot ratio
            # ============================================================
            spr = my_chips / max(pot, 1)

            # ============================================================
            # 9. Make strategic decision
            # ============================================================
            decision = self._make_strategic_decision(
                hand_strength=hand_strength,
                effective_strength=effective_strength,
                position=position,
                pot_odds=pot_odds,
                available_actions=available_actions,
                game_state=game_state,
                phase=phase,
                active_opponents=active_opponents,
                spr=spr,
                my_chips=my_chips,
                bet_to_call=bet_to_call
            )

            logger.info(
                f"Phase: {phase}, Hand: {hole_cards}, "
                f"Strength: {hand_strength:.2f}, Position: {position}, "
                f"Decision: {decision.get('action')}"
            )

            return decision

        except Exception as e:
            logger.error(f"Error in make_move: {e}", exc_info=True)
            return self._safe_fold(valid_actions)

    def evaluate_hand_strength(self, hole_cards: List[str],
                              community_cards: List[str],
                              phase: str) -> float:
        """
        Evaluate hand strength with proper poker logic

        Returns:
            float: Hand strength from 0.0 to 1.0
        """
        if phase == 'preflop' or len(community_cards) == 0:
            return self._evaluate_preflop_strength(hole_cards)
        else:
            return self._evaluate_postflop_strength(hole_cards, community_cards)

    def _evaluate_preflop_strength(self, hole_cards: List[str]) -> float:
        """
        Evaluate preflop hand strength using Chen formula and adjustments

        Returns:
            float: Hand strength 0.0 to 1.0
        """
        if len(hole_cards) != 2:
            return 0.0

        card1, card2 = hole_cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)

        # Rank values
        rank_values = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
            '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }

        val1 = rank_values.get(rank1, 0)
        val2 = rank_values.get(rank2, 0)
        high_card = max(val1, val2)
        low_card = min(val1, val2)

        is_suited = (suit1 == suit2)
        is_pair = (val1 == val2)
        gap = high_card - low_card

        # Start with Chen formula base
        if is_pair:
            # Pocket pairs
            if high_card == 14:  # AA
                return 0.95
            elif high_card == 13:  # KK
                return 0.92
            elif high_card == 12:  # QQ
                return 0.88
            elif high_card == 11:  # JJ
                return 0.84
            elif high_card == 10:  # TT
                return 0.80
            elif high_card >= 7:   # 77-99
                return 0.65 + (high_card - 7) * 0.05
            else:  # 22-66
                return 0.45 + (high_card - 2) * 0.04
        else:
            # Non-pairs
            base_strength = (high_card + low_card) / 28.0

            # Premium non-pairs
            if high_card == 14 and low_card == 13:  # AK
                return 0.87 if is_suited else 0.82
            elif high_card == 14 and low_card == 12:  # AQ
                return 0.80 if is_suited else 0.73
            elif high_card == 14 and low_card == 11:  # AJ
                return 0.75 if is_suited else 0.66
            elif high_card == 13 and low_card == 12:  # KQ
                return 0.76 if is_suited else 0.68

            # Suited bonus
            if is_suited:
                base_strength += 0.12

            # Connectedness bonus
            if gap == 0:  # Connected
                base_strength += 0.08
            elif gap == 1:  # One gap
                base_strength += 0.05
            elif gap == 2:  # Two gaps
                base_strength += 0.02

            # High card bonus
            if high_card == 14:  # Ace
                base_strength += 0.12
            elif high_card == 13:  # King
                base_strength += 0.08
            elif high_card == 12:  # Queen
                base_strength += 0.05

            # Penalty for very weak hands
            if high_card <= 9 and low_card <= 6 and gap > 3:
                base_strength *= 0.5

            return min(base_strength, 0.95)

    def _evaluate_postflop_strength(self, hole_cards: List[str],
                                   community_cards: List[str]) -> float:
        """
        Evaluate postflop hand strength using poker engine

        Returns:
            float: Hand strength 0.0 to 1.0
        """
        if not POKER_ENGINE_AVAILABLE:
            return self._fallback_postflop_evaluation(hole_cards, community_cards)

        try:
            # Convert string cards to Card objects
            all_cards = string_list_to_cards(hole_cards + community_cards)

            if len(all_cards) < 5:
                return self._evaluate_preflop_strength(hole_cards)

            # Evaluate best hand
            best_hand = HandEvaluator.evaluate_hand(all_cards)

            # Map hand rank to strength
            rank_to_base_strength = {
                HandRank.HIGH_CARD: 0.20,
                HandRank.PAIR: 0.35,
                HandRank.TWO_PAIR: 0.50,
                HandRank.THREE_OF_A_KIND: 0.62,
                HandRank.STRAIGHT: 0.72,
                HandRank.FLUSH: 0.80,
                HandRank.FULL_HOUSE: 0.88,
                HandRank.FOUR_OF_A_KIND: 0.94,
                HandRank.STRAIGHT_FLUSH: 0.98,
                HandRank.ROYAL_FLUSH: 1.0
            }

            base_strength = rank_to_base_strength.get(best_hand.rank, 0.2)

            # Adjust based on kickers for same rank hands
            if best_hand.rank_values:
                top_kicker = best_hand.rank_values[0]
                kicker_bonus = (top_kicker - 2) / 100.0  # Small bonus for high kickers
                base_strength = min(base_strength + kicker_bonus, 0.99)

            return base_strength

        except Exception as e:
            logger.warning(f"Error in postflop evaluation: {e}")
            return self._fallback_postflop_evaluation(hole_cards, community_cards)

    def _fallback_postflop_evaluation(self, hole_cards: List[str],
                                     community_cards: List[str]) -> float:
        """Fallback evaluation when poker engine unavailable"""
        all_cards = hole_cards + community_cards

        # Simple pattern matching
        ranks = [self._parse_card(card)[0] for card in all_cards]
        suits = [self._parse_card(card)[1] for card in all_cards]

        rank_counts = Counter(ranks)
        suit_counts = Counter(suits)

        max_rank_count = max(rank_counts.values()) if rank_counts else 0
        max_suit_count = max(suit_counts.values()) if suit_counts else 0

        # Estimate strength
        if max_rank_count >= 4:
            return 0.94  # Four of a kind
        elif max_rank_count == 3 and len(rank_counts) <= 3:
            return 0.88  # Full house or three of a kind
        elif max_suit_count >= 5:
            return 0.80  # Flush
        elif max_rank_count == 3:
            return 0.62  # Three of a kind
        elif max_rank_count == 2 and len(rank_counts) <= 4:
            return 0.50  # Two pair
        elif max_rank_count == 2:
            return 0.35  # One pair
        else:
            return 0.20  # High card

    def analyze_position(self, current_player: str, players: Dict,
                        dealer_index: int) -> str:
        """
        Analyze player position

        Returns:
            str: 'early', 'middle', or 'late'
        """
        active_players = [
            pid for pid, pinfo in players.items()
            if pinfo.get('state') == 'active'
        ]

        if current_player not in active_players:
            return 'middle'

        player_count = len(active_players)
        current_index = active_players.index(current_player)

        # Determine position based on player count
        if player_count <= 3:
            return 'late' if current_index >= player_count - 1 else 'early'
        elif player_count <= 6:
            third = player_count // 3
            if current_index < third:
                return 'early'
            elif current_index < 2 * third:
                return 'middle'
            else:
                return 'late'
        else:
            if current_index < 2:
                return 'early'
            elif current_index < player_count - 2:
                return 'middle'
            else:
                return 'late'

    def calculate_pot_odds(self, pot_size: int, bet_to_call: int) -> float:
        """Calculate pot odds"""
        if bet_to_call <= 0:
            return float('inf')
        return pot_size / bet_to_call

    def _make_strategic_decision(self, hand_strength: float,
                                effective_strength: float,
                                position: str, pot_odds: float,
                                available_actions: Dict,
                                game_state: Dict, phase: str,
                                active_opponents: int, spr: float,
                                my_chips: int, bet_to_call: int) -> Dict[str, Any]:
        """
        Make strategic decision based on all factors

        Decision tree:
        1. Premium hands: Always aggressive
        2. Strong hands: Value bet/raise based on position
        3. Playable hands: Consider pot odds and position
        4. Marginal hands: Mostly fold unless great odds
        5. Weak hands: Fold or bluff in late position
        """
        pot = game_state.get('pot', 0)

        # ================================================================
        # Premium Hands - Maximum Aggression
        # ================================================================
        if effective_strength >= self.PREMIUM_THRESHOLD:
            if available_actions['raise']:
                amount = self._calculate_raise_amount(
                    game_state, 'value_bet', effective_strength
                )
                return {"action": "raise", "amount": amount}
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']

        # ================================================================
        # Very Strong Hands - Strong Value Play
        # ================================================================
        elif effective_strength >= self.VERY_STRONG_THRESHOLD:
            if available_actions['raise'] and (position != 'early' or phase != 'preflop'):
                amount = self._calculate_raise_amount(
                    game_state, 'value_bet', effective_strength
                )
                return {"action": "raise", "amount": amount}
            elif available_actions['call'] and pot_odds > 1.5:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
            elif available_actions['call']:
                return available_actions['call']

        # ================================================================
        # Strong Hands - Selective Aggression
        # ================================================================
        elif effective_strength >= self.STRONG_THRESHOLD:
            # Be aggressive in late position or with good pot odds
            if available_actions['raise'] and position == 'late' and pot_odds < 3:
                amount = self._calculate_raise_amount(
                    game_state, 'value_bet', effective_strength
                )
                return {"action": "raise", "amount": amount}
            elif available_actions['call'] and pot_odds > 2:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 1.5:
                return available_actions['call']

        # ================================================================
        # Playable Hands - Position and Odds Dependent
        # ================================================================
        elif effective_strength >= self.PLAYABLE_THRESHOLD:
            if available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 4:
                return available_actions['call']
            # Semi-bluff with decent hands in late position
            elif (position == 'late' and phase != 'river' and
                  self._should_semi_bluff() and available_actions['raise']):
                amount = self._calculate_raise_amount(
                    game_state, 'bluff', effective_strength
                )
                return {"action": "raise", "amount": amount}

        # ================================================================
        # Marginal Hands - Very Selective
        # ================================================================
        elif effective_strength >= self.MARGINAL_THRESHOLD:
            if available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 6:
                return available_actions['call']

        # ================================================================
        # Weak Hands - Fold or Strategic Bluff
        # ================================================================
        else:
            if available_actions['check']:
                return available_actions['check']
            # Pure bluff in late position when appropriate
            elif (position == 'late' and active_opponents <= 2 and
                  self._should_bluff() and available_actions['raise'] and
                  phase != 'preflop'):
                amount = self._calculate_raise_amount(
                    game_state, 'bluff', 0.3
                )
                return {"action": "raise", "amount": amount}

        # ================================================================
        # Default: Fold
        # ================================================================
        if available_actions['fold']:
            return available_actions['fold']

        # Last resort
        return list(available_actions.values())[0] if available_actions else {"action": "fold"}

    def _calculate_raise_amount(self, game_state: Dict,
                               raise_type: str,
                               hand_strength: float) -> int:
        """
        Calculate optimal raise amount

        Args:
            game_state: Current game state
            raise_type: 'value_bet', 'bluff', 'semi_bluff'
            hand_strength: Current hand strength

        Returns:
            int: Raise amount
        """
        pot = game_state.get('pot', 0)
        current_bet = game_state.get('current_bet', 0)
        current_player = game_state.get('current_player')
        players = game_state.get('players', {})

        if current_player in players:
            my_chips = players[current_player].get('chips', 0)
            my_current_bet = players[current_player].get('current_bet', 0)
        else:
            my_chips = 1000
            my_current_bet = 0

        # Base multipliers
        multipliers = {
            'value_bet': 0.75,    # 75% pot for value
            'semi_bluff': 0.6,    # 60% pot for semi-bluff
            'bluff': 0.5          # 50% pot for bluff
        }

        base_multiplier = multipliers.get(raise_type, 0.6)

        # Adjust based on hand strength for value bets
        if raise_type == 'value_bet' and hand_strength > 0.8:
            base_multiplier = 0.85  # Larger bets with very strong hands

        raise_amount = int(pot * base_multiplier) + current_bet

        # Ensure minimum raise
        min_raise = current_bet * 2
        max_raise = my_chips + my_current_bet

        # Clamp to valid range
        raise_amount = max(min_raise, min(raise_amount, max_raise))

        return raise_amount

    def _should_bluff(self) -> bool:
        """Determine if should bluff this hand"""
        return random.random() < self.bluff_frequency

    def _should_semi_bluff(self) -> bool:
        """Determine if should semi-bluff with drawing hand"""
        return random.random() < self.semi_bluff_frequency

    def _parse_valid_actions(self, valid_actions: List[Dict]) -> Dict[str, Optional[Dict]]:
        """Parse available actions into dictionary"""
        actions = {
            'fold': None,
            'check': None,
            'call': None,
            'raise': None,
            'all_in': None
        }

        for action in valid_actions:
            action_type = action.get('action')
            if action_type in actions:
                actions[action_type] = action

        return actions

    def _parse_card(self, card: str) -> Tuple[str, str]:
        """
        Parse card string into rank and suit

        Args:
            card: Card string like 'As', 'Kh', '10d'

        Returns:
            Tuple[str, str]: (rank, suit)
        """
        if len(card) == 2:
            return card[0], card[1]
        elif len(card) == 3 and card[:2] == '10':
            return '10', card[2]
        else:
            return card[:-1], card[-1]

    def _safe_fold(self, valid_actions: List[Dict]) -> Dict[str, Any]:
        """Safe fold when errors occur"""
        fold_action = next(
            (a for a in valid_actions if a.get('action') == 'fold'),
            None
        )
        if fold_action:
            return fold_action
        return {"action": "fold", "amount": 0}

    def reset(self):
        """Reset AI state for new game"""
        self.opponent_stats.clear()
        self.hand_history.clear()
        self.current_hand_actions.clear()
        self.last_action = None
        self.is_preflop_raiser = False
        logger.info(f"AI {self.name} reset")

    def get_thinking_time(self) -> float:
        """Return random thinking time to appear human-like"""
        return random.uniform(0.3, 2.5)


# ============================================================================
# Test Code
# ============================================================================
if __name__ == "__main__":
    print("=" * 70)
    print("Claude Sonnet 4.5 Texas Hold'em AI - Test Suite")
    print("=" * 70)

    # Create AI instance
    ai = ClaudeSonnet45AI()

    # Test 1: AI Info
    print("\n[TEST 1] AI Information")
    print("-" * 70)
    info = ai.get_info()
    for key, value in info.items():
        print(f"{key}: {value}")

    # Test 2: Preflop Hand Evaluation
    print("\n[TEST 2] Preflop Hand Strength Evaluation")
    print("-" * 70)
    test_hands = [
        (['As', 'Ah'], "Pocket Aces"),
        (['Ks', 'Kh'], "Pocket Kings"),
        (['As', 'Ks'], "Ace King Suited"),
        (['Ah', 'Kd'], "Ace King Offsuit"),
        (['Qs', 'Js'], "Queen Jack Suited"),
        (['9h', '9d'], "Pocket Nines"),
        (['7h', '2d'], "Seven Two Offsuit"),
    ]

    for hole_cards, description in test_hands:
        strength = ai._evaluate_preflop_strength(hole_cards)
        print(f"{description:20s} {hole_cards}: {strength:.3f}")

    # Test 3: Position Analysis
    print("\n[TEST 3] Position Analysis")
    print("-" * 70)
    test_players = {
        'player1': {'state': 'active'},
        'player2': {'state': 'active'},
        'player3': {'state': 'active'},
        'player4': {'state': 'active'},
        'player5': {'state': 'active'},
        'player6': {'state': 'active'},
    }

    for i, player in enumerate(test_players.keys()):
        position = ai.analyze_position(player, test_players, 0)
        print(f"{player}: {position}")

    # Test 4: Decision Making
    print("\n[TEST 4] Decision Making Simulation")
    print("-" * 70)

    test_scenarios = [
        {
            'name': 'Premium Hand Preflop',
            'valid_actions': [
                {'action': 'fold'},
                {'action': 'call', 'amount': 20},
                {'action': 'raise', 'min_amount': 40, 'max_amount': 200}
            ],
            'players': {
                'player1': {
                    'hole_cards': ['As', 'Ah'],
                    'chips': 1000,
                    'current_bet': 10,
                    'state': 'active'
                },
                'player2': {'chips': 980, 'current_bet': 20, 'state': 'active'}
            },
            'current_player': 'player1',
            'community_cards': [],
            'pot': 30,
            'current_bet': 20,
            'phase': 'preflop',
            'dealer_index': 0
        },
        {
            'name': 'Marginal Hand in Late Position',
            'valid_actions': [
                {'action': 'fold'},
                {'action': 'call', 'amount': 20},
            ],
            'players': {
                'player1': {
                    'hole_cards': ['9h', '8h'],
                    'chips': 980,
                    'current_bet': 0,
                    'state': 'active'
                },
                'player2': {'chips': 980, 'current_bet': 20, 'state': 'active'}
            },
            'current_player': 'player1',
            'community_cards': [],
            'pot': 30,
            'current_bet': 20,
            'phase': 'preflop',
            'dealer_index': 0
        }
    ]

    for scenario in test_scenarios:
        print(f"\nScenario: {scenario['name']}")
        decision = ai.make_move(scenario)
        print(f"Decision: {decision}")

    # Test 5: Pot Odds Calculation
    print("\n[TEST 5] Pot Odds Calculation")
    print("-" * 70)
    test_cases = [
        (100, 20, "Call 20 into pot of 100"),
        (200, 50, "Call 50 into pot of 200"),
        (150, 30, "Call 30 into pot of 150"),
    ]

    for pot, call, description in test_cases:
        odds = ai.calculate_pot_odds(pot, call)
        print(f"{description}: {odds:.2f}:1")

    print("\n" + "=" * 70)
    print("All tests completed successfully!")
    print("=" * 70)
