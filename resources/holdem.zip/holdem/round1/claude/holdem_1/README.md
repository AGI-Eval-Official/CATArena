# Claude Sonnet 4.5 Texas Hold'em AI

A competitive Texas Hold'em AI developed by Claude Sonnet 4.5, designed for tournament play with advanced strategic capabilities.

## Overview

This AI implements a **tight-aggressive (TAG)** strategy with adaptive decision-making based on:
- Hand strength evaluation using proven poker algorithms
- Position-aware betting patterns
- Mathematical pot odds calculations
- Opponent modeling capabilities
- Strategic bluffing and semi-bluffing

## Key Features

### 1. Advanced Hand Evaluation
- **Preflop**: Uses modified Chen formula with adjustments for:
  - Pocket pairs (AA through 22)
  - Suited and unsuited high cards
  - Connector bonuses
  - Gap penalties
- **Postflop**: Integrates with poker_logic.py engine for accurate hand ranking
  - Evaluates all 5-card combinations
  - Proper hand comparison with kickers
  - Fallback evaluation if engine unavailable

### 2. Position-Based Strategy
- **Early Position**: Conservative play (85% strength multiplier)
- **Middle Position**: Standard play (100% multiplier)
- **Late Position**: Aggressive play (115% multiplier)
- Dynamically adjusts based on table size (2-10 players)

### 3. Mathematical Decision Making
- Pot odds calculation and comparison
- Expected value considerations
- Stack-to-pot ratio (SPR) analysis
- Bet sizing based on hand strength and board texture

### 4. Strategic Play Patterns
- **Aggression Level**: 0.7 (moderately aggressive)
- **Bluff Frequency**: 18% in favorable situations
- **Semi-Bluff Frequency**: 25% with drawing hands
- **Continuation Bet**: 65% on favorable flops
- Position-dependent betting strategy

### 5. Hand Strength Thresholds
```
Premium:      ≥ 0.85  (AA, KK, AKs, etc.)
Very Strong:  ≥ 0.75  (QQ, JJ, AQs, etc.)
Strong:       ≥ 0.60  (TT, AJs, KQs, etc.)
Playable:     ≥ 0.40  (Small pairs, suited connectors)
Marginal:     ≥ 0.25  (Weak pairs, suited aces)
Weak:         < 0.25  (Trash hands)
```

## Files

- **ai_config.yaml**: Configuration file with AI metadata and parameters
- **ai_player.py**: Main AI implementation with decision logic
- **README.md**: This documentation file

## Installation

1. Copy this directory to your AI players folder:
```bash
cp -r /data/CATArena/AI_Candidate/holdem/round1/claude/holdem_1 \
      /path/to/ai_players/holdem/traditional/
```

2. Ensure the poker engine is accessible at:
```
/data/CATArena/GamesEnv/games/holdem/engines/poker_logic.py
```

## Usage

### Running Tests
Test the AI locally:
```bash
cd /data/CATArena/AI_Candidate/holdem/round1/claude/holdem_1
python ai_player.py
```

### Playing Against Other AIs
Configure a battle in `configs/sample_battle_traditional.json`:
```json
{
  "battle": {
    "rounds": 100,
    "timeout": 30,
    "verbose": false
  },
  "players": ["sonnet_4_5_AI", "other_ai_1", "other_ai_2"],
  "mode": "traditional"
}
```

Run the battle:
```bash
cd /data/CATArena/GamesEnv/games/holdem
python cli_battle.py --config configs/sample_battle_traditional.json
```

## Strategy Details

### Preflop Strategy
1. **Premium Hands (AA-QQ, AKs)**: Raise aggressively, build pot
2. **Strong Hands (JJ-99, AQ, KQ)**: Raise in late position, call in early
3. **Playable Hands (Small pairs, suited connectors)**: Call with good odds
4. **Marginal Hands**: Fold in early position, consider stealing in late
5. **Weak Hands**: Fold unless in late position with bluff opportunity

### Postflop Strategy
1. **Made Hands**: Value bet based on hand strength
2. **Drawing Hands**: Semi-bluff with good equity
3. **Weak Hands**: Check/fold or bluff in late position
4. **Strong Hands**: Build pot gradually, trap when appropriate

### Position Adjustments
- **Early Position**: Play premium hands only, fold marginal holdings
- **Middle Position**: Open up range slightly, steal occasionally
- **Late Position**: Wide range, steal blinds, bluff more frequently

### Bet Sizing
- **Value Bets**: 75-85% of pot (stronger hands → larger bets)
- **Semi-Bluffs**: 60% of pot
- **Bluffs**: 50% of pot
- All sizes adjusted for pot size and stack depth

## Technical Implementation

### Core Methods

#### `make_move(game_state)`
Main decision-making method that:
1. Parses game state
2. Evaluates hand strength
3. Analyzes position
4. Calculates pot odds
5. Makes strategic decision

#### `evaluate_hand_strength(hole_cards, community_cards, phase)`
Returns hand strength (0.0 to 1.0) using:
- Preflop: Modified Chen formula
- Postflop: Poker engine hand evaluation

#### `analyze_position(current_player, players, dealer_index)`
Determines position ('early', 'middle', 'late') based on:
- Number of active players
- Current player index
- Dealer position

#### `_make_strategic_decision(...)`
Implements decision tree:
1. Premium hands → Maximum aggression
2. Strong hands → Value betting
3. Playable hands → Pot odds dependent
4. Marginal hands → Very selective
5. Weak hands → Fold or strategic bluff

## Performance Characteristics

- **Decision Time**: 0.3 - 2.5 seconds (appears human-like)
- **Memory Usage**: Tracks opponent statistics for adaptation
- **Error Handling**: Graceful fallback to safe fold on errors
- **Logging**: Detailed decision logging for analysis

## Dependencies

- Python 3.7+
- Standard library: sys, os, random, math, logging, typing, collections, itertools
- Optional: poker_logic.py (falls back to simplified evaluation if unavailable)

## Configuration

Edit `ai_config.yaml` to adjust:
- **aggression_level**: 0.0 (passive) to 1.0 (aggressive)
- **bluff_frequency**: How often to bluff (0.0 to 0.3 recommended)
- **position_awareness**: Enable/disable position-based adjustments
- **thinking_time_min/max**: Simulate human thinking time

## Testing Results

```
Test 1: AI Information ✓
Test 2: Preflop Hand Strength Evaluation ✓
  - Pocket Aces: 0.950
  - Pocket Kings: 0.920
  - Seven Two Offsuit: 0.161
Test 3: Position Analysis ✓
Test 4: Decision Making ✓
Test 5: Pot Odds Calculation ✓
```

## Strategy Philosophy

This AI follows a **tight-aggressive (TAG)** approach:
- **Tight**: Play strong starting hands, fold weak hands
- **Aggressive**: Bet and raise rather than call and check
- **Adaptive**: Adjust based on position, stack depth, and opponents
- **Mathematical**: Base decisions on pot odds and expected value

## Future Enhancements

Potential improvements:
1. Advanced opponent modeling with VPIP/PFR tracking
2. Board texture analysis for continuation bets
3. Range-based thinking instead of hand-based
4. ICM considerations for tournament play
5. Multi-street planning
6. GTO mixed strategies for balance

## Author

Developed by **Claude Sonnet 4.5**
- Version: 1.0.0
- Model: claude-sonnet-4-5-20250929
- Date: 2025-11-09

## License

This AI is provided as-is for tournament use. Feel free to study and learn from the implementation.
