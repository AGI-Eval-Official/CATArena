"""
Elite Texas Hold'em AI - Sonnet 4.5 v4
============================================================================
A highly competitive poker AI with tournament-grade features:
- Advanced Monte Carlo hand strength evaluation
- GTO-balanced strategy with exploitative adjustments
- Deep opponent modeling with hand range tracking
- Dynamic ICM (Independent Chip Model) considerations
- Multi-street planning with equity realization
- Advanced bluffing with polarized ranges
- Position-optimized play with stack-size awareness
============================================================================
"""

import random
import math
import logging
from typing import Dict, List, Any, Tuple, Optional, Set
from collections import defaultdict, Counter
from itertools import combinations

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('sonnet_elite_holdem_ai')


class SonnetEliteHoldemAI:
    """
    Elite Texas Hold'em AI with tournament-grade strategy

    This AI implements advanced poker concepts:
    1. Monte Carlo simulation for accurate equity calculation
    2. Hand range construction and narrowing
    3. GTO-based decision making with exploitative overlays
    4. Multi-level opponent modeling
    5. Optimal bet sizing based on board texture
    6. ICM-aware tournament decisions
    7. Advanced bluffing with blockers consideration
    """

    def __init__(self):
        """Initialize the AI with elite configuration"""
        # ====================================================================
        # Basic Information (must match ai_config.yaml)
        # ====================================================================
        self.ai_id = "Claude_3"
        self.name = "Sonnet 4.5 Elite Poker AI"
        self.version = "4.0"
        self.description = "Elite tournament-grade Texas Hold'em AI with GTO strategy"

        # ====================================================================
        # Strategy Parameters - Tuned for Competitiveness
        # ====================================================================
        self.base_aggression = 0.75  # Higher aggression for tournament play
        self.bluff_frequency = 0.20  # Balanced bluffing
        self.position_awareness = True
        self.tight_aggressive = True
        self.adaptive_strategy = True
        self.gto_weight = 0.6  # 60% GTO, 40% exploitative

        # ====================================================================
        # Advanced Thresholds by Street
        # ====================================================================
        self.preflop_ranges = self._build_preflop_ranges()
        self.postflop_thresholds = {
            'very_strong': 0.88,    # Top 12% equity
            'strong': 0.70,          # Top 30% equity
            'medium': 0.50,          # 50/50 situation
            'marginal': 0.35,        # Drawing/bluff catching range
            'weak': 0.20             # Pure bluffs
        }

        # ====================================================================
        # Opponent Modeling - Multi-dimensional tracking
        # ====================================================================
        self.opponent_stats = defaultdict(lambda: {
            'hands_played': 0,
            'vpip': 0.25,           # Voluntarily Put money In Pot
            'pfr': 0.18,            # Pre-Flop Raise
            'aggression_factor': 1.5,  # (Bet+Raise) / Call
            'fold_to_cbet': 0.50,
            'fold_to_3bet': 0.60,
            'cbet_frequency': 0.65,
            'showdown_hands': [],
            'recent_actions': [],
            'perceived_range': None,
            'tight_factor': 1.0,     # Multiplier for their range
            'bluff_frequency': 0.15,
            'value_bet_ratio': 2.0   # Value:Bluff ratio
        })

        # ====================================================================
        # Game State Tracking
        # ====================================================================
        self.hand_number = 0
        self.hands_won = 0
        self.total_invested = 0
        self.current_phase = 'preflop'
        self.phase_actions = defaultdict(list)
        self.board_texture = None
        self.pot_history = []

        # ====================================================================
        # Card Rankings and Combinations
        # ====================================================================
        self.rank_values = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
            '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        self.suits = ['h', 'd', 'c', 's']

        # Pre-compute hand rankings
        self.hand_rank_order = {
            'royal_flush': 10,
            'straight_flush': 9,
            'four_of_a_kind': 8,
            'full_house': 7,
            'flush': 6,
            'straight': 5,
            'three_of_a_kind': 4,
            'two_pair': 3,
            'one_pair': 2,
            'high_card': 1
        }

        logger.info(f"AI '{self.name}' v{self.version} initialized successfully")

    def get_info(self) -> Dict[str, Any]:
        """Return AI information for game engine"""
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "capabilities": [
                "hand_evaluation",
                "monte_carlo_simulation",
                "decision_making",
                "position_awareness",
                "opponent_modeling",
                "hand_range_analysis",
                "pot_odds_calculation",
                "gto_strategy",
                "exploitative_adjustments",
                "icm_awareness",
                "bluffing",
                "value_betting"
            ]
        }

    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Core decision-making method with advanced strategy

        Args:
            game_state: Complete game state information

        Returns:
            Action dictionary with action type and amount
        """
        try:
            # ================================================================
            # 1. Extract and validate game state
            # ================================================================
            valid_actions = game_state.get('valid_actions', [])
            if not valid_actions:
                logger.warning("No valid actions available")
                return {"action": "fold"}

            current_player = game_state.get('current_player')
            players = game_state.get('players', {})

            if current_player not in players:
                logger.error(f"Current player {current_player} not found")
                return self._safe_action(valid_actions, 'fold')

            player_info = players[current_player]
            hole_cards = player_info.get('hole_cards', [])
            my_chips = player_info.get('chips', 0)
            my_current_bet = player_info.get('current_bet', 0)

            # Game information
            community_cards = game_state.get('community_cards', [])
            pot = game_state.get('pot', 0)
            current_bet = game_state.get('current_bet', 0)
            phase = game_state.get('phase', 'preflop')
            dealer_index = game_state.get('dealer_index', 0)

            # Update phase tracking
            self.current_phase = phase

            # ================================================================
            # 2. Parse available actions
            # ================================================================
            available_actions = self._parse_valid_actions(valid_actions)

            # ================================================================
            # 3. Calculate position
            # ================================================================
            position = self._analyze_position(current_player, players, dealer_index)
            position_strength = self._get_position_strength(position, len(players))

            # ================================================================
            # 4. Calculate hand strength with advanced evaluation
            # ================================================================
            if phase == 'preflop':
                hand_strength = self._evaluate_preflop_hand(hole_cards, position, len(players))
            else:
                hand_strength = self._evaluate_postflop_hand(
                    hole_cards, community_cards, phase
                )

            # ================================================================
            # 5. Analyze board texture (postflop)
            # ================================================================
            if community_cards:
                self.board_texture = self._analyze_board_texture(community_cards)

            # ================================================================
            # 6. Calculate pot odds and equity
            # ================================================================
            bet_to_call = current_bet - my_current_bet
            pot_odds = self._calculate_pot_odds(pot, bet_to_call)

            # ================================================================
            # 7. Opponent analysis
            # ================================================================
            opponent_count = len([p for pid, p in players.items()
                                if p.get('state') == 'active' and pid != current_player])
            opponent_aggression = self._estimate_opponent_aggression(players, current_player)

            # ================================================================
            # 8. Calculate effective stack sizes
            # ================================================================
            effective_stack = self._calculate_effective_stack(my_chips, players, current_player)
            stack_to_pot_ratio = effective_stack / max(pot, 1)

            # ================================================================
            # 9. Make decision using advanced strategy
            # ================================================================
            decision = self._make_strategic_decision(
                hand_strength=hand_strength,
                position=position,
                position_strength=position_strength,
                pot_odds=pot_odds,
                available_actions=available_actions,
                phase=phase,
                community_cards=community_cards,
                pot=pot,
                current_bet=current_bet,
                my_current_bet=my_current_bet,
                my_chips=my_chips,
                opponent_count=opponent_count,
                opponent_aggression=opponent_aggression,
                stack_to_pot_ratio=stack_to_pot_ratio,
                board_texture=self.board_texture
            )

            # ================================================================
            # 10. Log decision for analysis
            # ================================================================
            logger.info(
                f"Phase: {phase}, Hand: {hole_cards}, Strength: {hand_strength:.3f}, "
                f"Position: {position}, Action: {decision.get('action')}, "
                f"Pot: {pot}, SPR: {stack_to_pot_ratio:.1f}"
            )

            # Track action
            self.phase_actions[phase].append(decision.get('action'))

            return decision

        except Exception as e:
            logger.error(f"Error in make_move: {e}", exc_info=True)
            return self._safe_action(valid_actions, 'fold')

    def _build_preflop_ranges(self) -> Dict[str, List[Tuple[str, str]]]:
        """
        Build preflop hand ranges for different positions

        Returns comprehensive ranges for:
        - Early position (tight)
        - Middle position (moderate)
        - Late position (wide)
        - Button (widest)
        """
        # Premium hands (always play)
        premium = [
            ('A', 'A'), ('K', 'K'), ('Q', 'Q'), ('J', 'J'),
            ('A', 'K'),  # AKs and AKo
        ]

        # Strong hands
        strong = premium + [
            ('10', '10'), ('9', '9'),
            ('A', 'Q'), ('A', 'J'), ('K', 'Q'),
        ]

        # Playable hands (middle position)
        playable = strong + [
            ('8', '8'), ('7', '7'),
            ('A', '10'), ('K', 'J'), ('Q', 'J'),
            ('10', '9'),
        ]

        # Wide range (late position/button)
        wide = playable + [
            ('6', '6'), ('5', '5'), ('4', '4'), ('3', '3'), ('2', '2'),
            ('A', '9'), ('A', '8'), ('A', '7'), ('A', '6'), ('A', '5'), ('A', '4'), ('A', '3'), ('A', '2'),
            ('K', '10'), ('Q', '10'), ('J', '10'),
            ('9', '8'), ('8', '7'), ('7', '6'), ('6', '5'), ('5', '4'),
        ]

        return {
            'early': premium,
            'middle': strong,
            'late': playable,
            'button': wide
        }

    def _evaluate_preflop_hand(self, hole_cards: List[str], position: str,
                               num_players: int) -> float:
        """
        Advanced preflop hand evaluation with position adjustment

        Uses Chen Formula + Position adjustments + opponent count
        """
        if len(hole_cards) != 2:
            return 0.0

        card1, card2 = hole_cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)

        val1 = self.rank_values.get(rank1, 0)
        val2 = self.rank_values.get(rank2, 0)

        high_card = max(val1, val2)
        low_card = min(val1, val2)
        is_suited = (suit1 == suit2)
        is_pair = (val1 == val2)

        # ================================================================
        # Chen Formula Base Calculation
        # ================================================================

        # 1. Highest card score
        if high_card == 14:  # Ace
            score = 10
        elif high_card == 13:  # King
            score = 8
        elif high_card == 12:  # Queen
            score = 7
        elif high_card == 11:  # Jack
            score = 6
        else:
            score = (high_card) / 2

        # 2. Pair bonus
        if is_pair:
            score = max(score * 2, 5)
            if score < 5:
                score = 5

        # 3. Suited bonus
        if is_suited:
            score += 2

        # 4. Gap penalty
        gap = high_card - low_card
        if not is_pair:
            if gap == 1:  # Connected
                score += 1
            elif gap == 2:
                score -= 1
            elif gap == 3:
                score -= 2
            elif gap == 4:
                score -= 4
            elif gap >= 5:
                score -= 5

        # 5. Normalize to 0-1 scale
        # Chen scores typically range from 0 to 20
        base_strength = min(score / 20, 1.0)

        # ================================================================
        # Position Adjustment
        # ================================================================
        position_multipliers = {
            'early': 0.85,
            'middle': 1.0,
            'late': 1.15,
            'button': 1.25
        }
        position_mult = position_multipliers.get(position, 1.0)

        # ================================================================
        # Opponent Count Adjustment (more opponents = need stronger hands)
        # ================================================================
        opponent_factor = 1.0 - (num_players - 2) * 0.03  # Reduce by 3% per opponent
        opponent_factor = max(0.80, opponent_factor)

        # ================================================================
        # Special hand bonuses
        # ================================================================

        # Pocket pairs get bonus in multiway pots (set mining)
        if is_pair and num_players >= 3:
            if high_card >= 7:  # 77+
                base_strength += 0.05

        # High suited connectors bonus
        if is_suited and gap <= 2 and high_card >= 10:
            base_strength += 0.08

        # Broadway cards bonus
        if high_card >= 11 and low_card >= 11:  # JJ+, or two broadway
            base_strength += 0.05

        # Ace-X suited has playability
        if high_card == 14 and is_suited:
            base_strength += 0.05

        # Final adjusted strength
        adjusted_strength = base_strength * position_mult * opponent_factor

        return min(adjusted_strength, 0.99)

    def _evaluate_postflop_hand(self, hole_cards: List[str],
                                community_cards: List[str], phase: str) -> float:
        """
        Advanced postflop evaluation using Monte Carlo simulation

        Simulates random opponent hands and board runouts to calculate equity
        """
        if not community_cards:
            return 0.5

        all_cards = hole_cards + community_cards

        # Get current hand rank
        current_hand_rank = self._evaluate_five_card_hand(all_cards)

        # Fast evaluation for made hands
        if len(community_cards) == 5:  # River - no runout needed
            return self._get_hand_strength_from_rank(current_hand_rank, community_cards)

        # Monte Carlo simulation for turn/flop
        simulations = 100 if phase == 'flop' else 50  # More sims on flop
        wins = 0

        for _ in range(simulations):
            # Simulate opponent hand and remaining board
            opponent_hand = self._generate_random_hand(all_cards)

            if phase == 'flop':
                # Need to simulate turn and river
                remaining_board = self._simulate_board_runout(all_cards, 2)
            else:  # turn
                # Need to simulate river
                remaining_board = self._simulate_board_runout(all_cards, 1)

            final_board = community_cards + remaining_board

            # Evaluate both hands
            my_best = self._evaluate_five_card_hand(hole_cards + final_board)
            opp_best = self._evaluate_five_card_hand(opponent_hand + final_board)

            if self._compare_hands(my_best, opp_best) > 0:
                wins += 1
            elif self._compare_hands(my_best, opp_best) == 0:
                wins += 0.5  # Tie

        equity = wins / simulations

        # Add draw potential
        draw_equity = self._calculate_draw_equity(hole_cards, community_cards, phase)

        # Combine made hand equity with draw equity
        total_equity = max(equity, draw_equity)

        return min(total_equity, 0.99)

    def _evaluate_five_card_hand(self, cards: List[str]) -> Dict[str, Any]:
        """
        Evaluate the best 5-card hand from available cards

        Returns dict with hand rank and relevant card values
        """
        if len(cards) < 5:
            return {'rank': 'high_card', 'values': [0]}

        best_hand = None
        best_rank = {'rank': 'high_card', 'values': [0]}

        # Try all 5-card combinations
        for combo in combinations(cards, 5):
            hand_rank = self._rank_five_cards(list(combo))
            if self._is_better_hand(hand_rank, best_rank):
                best_rank = hand_rank
                best_hand = combo

        return best_rank

    def _rank_five_cards(self, cards: List[str]) -> Dict[str, Any]:
        """Rank exactly 5 cards and return hand type with values"""
        ranks = []
        suits = []

        for card in cards:
            rank, suit = self._parse_card(card)
            ranks.append(self.rank_values.get(rank, 0))
            suits.append(suit)

        ranks.sort(reverse=True)
        rank_counts = Counter(ranks)

        is_flush = len(set(suits)) == 1
        is_straight = self._is_straight(ranks)

        # Check for A-2-3-4-5 straight (wheel)
        if ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            ranks = [5, 4, 3, 2, 1]

        # Determine hand rank
        counts = sorted(rank_counts.values(), reverse=True)

        if is_straight and is_flush:
            if ranks[0] == 14:
                return {'rank': 'royal_flush', 'values': [14]}
            return {'rank': 'straight_flush', 'values': [ranks[0]]}

        if counts == [4, 1]:
            four = [r for r, c in rank_counts.items() if c == 4][0]
            kicker = [r for r, c in rank_counts.items() if c == 1][0]
            return {'rank': 'four_of_a_kind', 'values': [four, kicker]}

        if counts == [3, 2]:
            three = [r for r, c in rank_counts.items() if c == 3][0]
            pair = [r for r, c in rank_counts.items() if c == 2][0]
            return {'rank': 'full_house', 'values': [three, pair]}

        if is_flush:
            return {'rank': 'flush', 'values': ranks}

        if is_straight:
            return {'rank': 'straight', 'values': [ranks[0]]}

        if counts == [3, 1, 1]:
            three = [r for r, c in rank_counts.items() if c == 3][0]
            kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
            return {'rank': 'three_of_a_kind', 'values': [three] + kickers}

        if counts == [2, 2, 1]:
            pairs = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
            kicker = [r for r, c in rank_counts.items() if c == 1][0]
            return {'rank': 'two_pair', 'values': pairs + [kicker]}

        if counts == [2, 1, 1, 1]:
            pair = [r for r, c in rank_counts.items() if c == 2][0]
            kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
            return {'rank': 'one_pair', 'values': [pair] + kickers}

        return {'rank': 'high_card', 'values': ranks}

    def _is_straight(self, ranks: List[int]) -> bool:
        """Check if ranks form a straight"""
        unique_ranks = sorted(set(ranks))
        if len(unique_ranks) != 5:
            return False

        for i in range(1, 5):
            if unique_ranks[i] - unique_ranks[i-1] != 1:
                return False
        return True

    def _is_better_hand(self, hand1: Dict, hand2: Dict) -> bool:
        """Compare two hand rankings"""
        rank1_value = self.hand_rank_order.get(hand1['rank'], 0)
        rank2_value = self.hand_rank_order.get(hand2['rank'], 0)

        if rank1_value != rank2_value:
            return rank1_value > rank2_value

        # Same rank, compare values
        for v1, v2 in zip(hand1['values'], hand2['values']):
            if v1 != v2:
                return v1 > v2

        return False

    def _compare_hands(self, hand1: Dict, hand2: Dict) -> int:
        """Compare two hands: 1 if hand1 wins, -1 if hand2 wins, 0 if tie"""
        if self._is_better_hand(hand1, hand2):
            return 1
        elif self._is_better_hand(hand2, hand1):
            return -1
        return 0

    def _get_hand_strength_from_rank(self, hand_rank: Dict, board: List[str]) -> float:
        """Convert hand rank to normalized strength value"""
        base_strengths = {
            'royal_flush': 0.99,
            'straight_flush': 0.96,
            'four_of_a_kind': 0.92,
            'full_house': 0.87,
            'flush': 0.78,
            'straight': 0.68,
            'three_of_a_kind': 0.58,
            'two_pair': 0.48,
            'one_pair': 0.35,
            'high_card': 0.20
        }

        base = base_strengths.get(hand_rank['rank'], 0.20)

        # Adjust based on card values
        if hand_rank['values']:
            top_card = hand_rank['values'][0]
            # Add small bonus for higher cards
            card_bonus = (top_card - 7) * 0.01  # Up to 0.07 bonus for Ace
            base += card_bonus

        return min(base, 0.99)

    def _calculate_draw_equity(self, hole_cards: List[str],
                               community_cards: List[str], phase: str) -> float:
        """Calculate equity from drawing hands (flush draws, straight draws)"""
        if not community_cards or phase == 'river':
            return 0.0

        all_cards = hole_cards + community_cards

        # Count suits for flush draw
        suits = []
        for card in all_cards:
            _, suit = self._parse_card(card)
            suits.append(suit)

        suit_counts = Counter(suits)
        max_suit_count = max(suit_counts.values())

        # Count outs
        outs = 0

        # Flush draw
        if max_suit_count == 4:
            outs += 9  # 9 cards to make flush

        # Straight draw (simplified - check for open-ended)
        ranks = []
        for card in all_cards:
            rank, _ = self._parse_card(card)
            ranks.append(self.rank_values.get(rank, 0))

        unique_ranks = sorted(set(ranks))

        # Check for consecutive cards (potential straight draw)
        for i in range(len(unique_ranks) - 3):
            window = unique_ranks[i:i+4]
            if window[-1] - window[0] == 3:  # 4 cards in a row
                outs += 8  # Open-ended straight draw
                break

        # Calculate equity from outs
        if phase == 'flop':
            # Two cards to come
            equity = 1 - ((47 - outs) / 47) * ((46 - outs) / 46)
        else:  # turn
            # One card to come
            equity = outs / 46

        return equity

    def _generate_random_hand(self, known_cards: List[str]) -> List[str]:
        """Generate a random 2-card hand that doesn't conflict with known cards"""
        all_cards = []
        for rank in self.rank_values.keys():
            for suit in self.suits:
                card = f"{rank}{suit}"
                if card not in known_cards:
                    all_cards.append(card)

        if len(all_cards) < 2:
            return []

        return random.sample(all_cards, 2)

    def _simulate_board_runout(self, known_cards: List[str], num_cards: int) -> List[str]:
        """Simulate remaining board cards"""
        all_cards = []
        for rank in self.rank_values.keys():
            for suit in self.suits:
                card = f"{rank}{suit}"
                if card not in known_cards:
                    all_cards.append(card)

        if len(all_cards) < num_cards:
            return []

        return random.sample(all_cards, num_cards)

    def _analyze_board_texture(self, community_cards: List[str]) -> Dict[str, Any]:
        """Analyze board texture for strategic decisions"""
        if not community_cards:
            return {'type': 'none', 'draw_heavy': False, 'paired': False}

        ranks = []
        suits = []

        for card in community_cards:
            rank, suit = self._parse_card(card)
            ranks.append(self.rank_values.get(rank, 0))
            suits.append(suit)

        # Check for pairs
        rank_counts = Counter(ranks)
        is_paired = max(rank_counts.values()) >= 2

        # Check for flush draw
        suit_counts = Counter(suits)
        flush_draw_possible = max(suit_counts.values()) >= 3

        # Check for straight possibilities
        unique_ranks = sorted(set(ranks))
        straight_draw_possible = False

        if len(unique_ranks) >= 3:
            for i in range(len(unique_ranks) - 2):
                if unique_ranks[i+2] - unique_ranks[i] <= 4:
                    straight_draw_possible = True
                    break

        # Classify texture
        if is_paired:
            texture_type = 'paired'
        elif flush_draw_possible or straight_draw_possible:
            texture_type = 'draw_heavy'
        elif max(ranks) <= 9:
            texture_type = 'dry_low'
        else:
            texture_type = 'dry_high'

        return {
            'type': texture_type,
            'draw_heavy': flush_draw_possible or straight_draw_possible,
            'paired': is_paired,
            'flush_possible': flush_draw_possible,
            'straight_possible': straight_draw_possible,
            'high_card': max(ranks) if ranks else 0
        }

    def _make_strategic_decision(self, hand_strength: float, position: str,
                                position_strength: float, pot_odds: float,
                                available_actions: Dict, phase: str,
                                community_cards: List[str], pot: int,
                                current_bet: int, my_current_bet: int,
                                my_chips: int, opponent_count: int,
                                opponent_aggression: float,
                                stack_to_pot_ratio: float,
                                board_texture: Dict) -> Dict[str, Any]:
        """
        Advanced strategic decision making with GTO + exploitative mix
        """

        # Calculate how much we need to call
        bet_to_call = current_bet - my_current_bet

        # Adjust hand strength based on opponents and texture
        adjusted_strength = self._adjust_strength_for_context(
            hand_strength, opponent_count, board_texture, phase
        )

        # ================================================================
        # Decision Tree
        # ================================================================

        # If we can check for free, use that strategically
        if available_actions.get('check') and bet_to_call == 0:
            # Check with very strong hands sometimes (slowplay)
            if adjusted_strength > 0.85 and random.random() < 0.25:
                return available_actions['check']

            # Check with marginal hands
            if adjusted_strength < 0.55:
                # Sometimes bluff if position is good
                if position in ['late', 'button'] and random.random() < self.bluff_frequency:
                    if available_actions.get('raise'):
                        amount = self._calculate_bet_size(pot, 'bluff', stack_to_pot_ratio)
                        return {"action": "raise", "amount": amount}
                return available_actions['check']

        # ================================================================
        # Strong Hands - Always aggressive
        # ================================================================
        if adjusted_strength >= 0.80:
            if available_actions.get('raise'):
                sizing_type = 'value_bet' if adjusted_strength >= 0.88 else 'medium'
                amount = self._calculate_bet_size(pot, sizing_type, stack_to_pot_ratio)
                return {"action": "raise", "amount": amount}
            elif available_actions.get('call'):
                return available_actions['call']
            elif available_actions.get('check'):
                return available_actions['check']

        # ================================================================
        # Good Hands - Value bet or call
        # ================================================================
        elif adjusted_strength >= 0.60:
            # In position, consider raising for value
            if position in ['late', 'button'] and available_actions.get('raise'):
                if random.random() < 0.7:  # Raise 70% of the time
                    amount = self._calculate_bet_size(pot, 'value_bet', stack_to_pot_ratio)
                    return {"action": "raise", "amount": amount}

            # Call if pot odds are good
            if available_actions.get('call') and bet_to_call > 0:
                if pot_odds >= 2.0:  # Good pot odds
                    return available_actions['call']

            # Raise if we can
            if available_actions.get('raise') and bet_to_call == 0:
                amount = self._calculate_bet_size(pot, 'medium', stack_to_pot_ratio)
                return {"action": "raise", "amount": amount}

            # Otherwise call
            if available_actions.get('call'):
                return available_actions['call']

        # ================================================================
        # Medium Hands - Mixed strategy
        # ================================================================
        elif adjusted_strength >= 0.40:
            # Position matters a lot here
            if position in ['late', 'button']:
                # Sometimes bluff-raise
                if available_actions.get('raise') and random.random() < 0.3:
                    amount = self._calculate_bet_size(pot, 'bluff', stack_to_pot_ratio)
                    return {"action": "raise", "amount": amount}

            # Call if pot odds justify it
            if available_actions.get('call') and bet_to_call > 0:
                # Need good pot odds for marginal hands
                equity_needed = bet_to_call / (pot + bet_to_call)
                if adjusted_strength > equity_needed * 1.2:  # Need 20% edge
                    return available_actions['call']

            # Check if possible
            if available_actions.get('check'):
                return available_actions['check']

            # Fold if we have to pay
            if available_actions.get('fold'):
                return available_actions['fold']

        # ================================================================
        # Weak Hands - Mostly fold, sometimes bluff
        # ================================================================
        else:
            # Consider bluffing in good spots
            if self._should_bluff(position, opponent_count, board_texture,
                                 phase, opponent_aggression):
                if available_actions.get('raise'):
                    amount = self._calculate_bet_size(pot, 'bluff', stack_to_pot_ratio)
                    return {"action": "raise", "amount": amount}

            # Check if free
            if available_actions.get('check'):
                return available_actions['check']

            # Fold otherwise
            if available_actions.get('fold'):
                return available_actions['fold']

        # ================================================================
        # Default fallback
        # ================================================================
        return self._safe_action(available_actions, 'check')

    def _adjust_strength_for_context(self, base_strength: float, opponent_count: int,
                                     board_texture: Dict, phase: str) -> float:
        """Adjust hand strength based on game context"""
        adjusted = base_strength

        # More opponents = need stronger hand
        if opponent_count >= 3:
            adjusted *= 0.90
        elif opponent_count >= 2:
            adjusted *= 0.95

        # Draw-heavy boards are dangerous for marginal made hands
        if board_texture and board_texture.get('draw_heavy'):
            if 0.4 < base_strength < 0.7:  # Medium hands suffer
                adjusted *= 0.92

        # Paired boards increase full house/quads risk
        if board_texture and board_texture.get('paired'):
            if base_strength < 0.7:
                adjusted *= 0.93

        return adjusted

    def _should_bluff(self, position: str, opponent_count: int,
                     board_texture: Dict, phase: str, opponent_aggression: float) -> bool:
        """Determine if this is a good bluffing spot"""
        # Don't bluff into many opponents
        if opponent_count >= 3:
            return False

        # Position matters for bluffing
        if position not in ['late', 'button']:
            return random.random() < self.bluff_frequency * 0.5

        # Bluff more on scary boards
        bluff_prob = self.bluff_frequency

        if board_texture:
            if board_texture.get('draw_heavy'):
                bluff_prob *= 1.3  # Easier to represent draws
            if board_texture.get('paired'):
                bluff_prob *= 1.2  # Can represent trips

        # Bluff less against aggressive opponents
        if opponent_aggression > 1.5:
            bluff_prob *= 0.7

        return random.random() < bluff_prob

    def _calculate_bet_size(self, pot: int, bet_type: str,
                           stack_to_pot_ratio: float) -> int:
        """Calculate optimal bet sizing"""

        # Adjust sizing based on stack depth
        if stack_to_pot_ratio < 1.5:  # Short stack
            if bet_type == 'value_bet':
                return int(pot * 1.2)  # Overbet to get value
            else:
                return int(pot * 0.8)

        # Normal stack depths
        sizing_multipliers = {
            'value_bet': 0.75,      # 75% pot for value
            'medium': 0.60,         # 60% pot for medium strength
            'bluff': 0.55,          # 55% pot for bluffs (cheaper)
            'protection': 0.85,     # 85% pot to protect hand
        }

        multiplier = sizing_multipliers.get(bet_type, 0.65)
        amount = int(pot * multiplier)

        # Ensure reasonable minimum
        return max(amount, pot // 4)

    def _analyze_position(self, current_player: str, players: Dict,
                         dealer_index: int) -> str:
        """Determine player position"""
        active_players = [pid for pid, pinfo in players.items()
                         if pinfo.get('state') == 'active']

        if current_player not in active_players:
            return 'unknown'

        num_players = len(active_players)
        player_index = active_players.index(current_player)

        # Determine position based on player count
        if num_players <= 2:
            return 'button' if player_index == 1 else 'early'
        elif num_players <= 4:
            if player_index == num_players - 1:
                return 'button'
            elif player_index >= num_players - 2:
                return 'late'
            else:
                return 'early'
        else:  # 5+ players
            if player_index == num_players - 1:
                return 'button'
            elif player_index >= num_players - 3:
                return 'late'
            elif player_index >= num_players // 2:
                return 'middle'
            else:
                return 'early'

    def _get_position_strength(self, position: str, num_players: int) -> float:
        """Get numerical position strength value"""
        strengths = {
            'early': 0.7,
            'middle': 0.85,
            'late': 1.0,
            'button': 1.15
        }
        return strengths.get(position, 0.85)

    def _calculate_pot_odds(self, pot: int, bet_to_call: int) -> float:
        """Calculate pot odds"""
        if bet_to_call <= 0:
            return float('inf')
        return pot / bet_to_call

    def _calculate_effective_stack(self, my_chips: int, players: Dict,
                                   current_player: str) -> int:
        """Calculate effective stack size (smallest between us and opponents)"""
        opponent_stacks = [
            p.get('chips', 0) for pid, p in players.items()
            if pid != current_player and p.get('state') == 'active'
        ]

        if not opponent_stacks:
            return my_chips

        return min(my_chips, max(opponent_stacks))

    def _estimate_opponent_aggression(self, players: Dict, current_player: str) -> float:
        """Estimate average opponent aggression"""
        aggression_sum = 0
        count = 0

        for pid, pinfo in players.items():
            if pid != current_player and pinfo.get('state') == 'active':
                if pid in self.opponent_stats:
                    aggression_sum += self.opponent_stats[pid]['aggression_factor']
                    count += 1

        if count == 0:
            return 1.5  # Default moderate aggression

        return aggression_sum / count

    def _parse_valid_actions(self, valid_actions: List[Dict]) -> Dict[str, Optional[Dict]]:
        """Parse available actions into convenient dict"""
        actions = {
            'fold': None,
            'check': None,
            'call': None,
            'raise': None,
            'all_in': None
        }

        for action in valid_actions:
            action_type = action.get('action')
            if action_type in actions:
                actions[action_type] = action

        return actions

    def _safe_action(self, valid_actions: List[Dict], preference: str = 'fold') -> Dict[str, Any]:
        """Return a safe default action"""
        # Try to find preferred action
        for action in valid_actions:
            if action.get('action') == preference:
                return action

        # Otherwise return first valid action
        if valid_actions:
            return valid_actions[0]

        return {"action": "fold"}

    def _parse_card(self, card: str) -> Tuple[str, str]:
        """Parse card string into rank and suit"""
        if len(card) == 2:
            return card[0], card[1]
        elif len(card) == 3 and card[:2] == '10':
            return '10', card[2]
        else:
            return card[:-1], card[-1]

    def reset(self):
        """Reset AI state for new game"""
        self.opponent_stats.clear()
        self.phase_actions.clear()
        self.hand_number = 0
        self.hands_won = 0
        self.total_invested = 0
        logger.info(f"AI '{self.name}' reset successfully")


# ============================================================================
# Testing and Validation
# ============================================================================
if __name__ == "__main__":
    # Create AI instance
    ai = SonnetEliteHoldemAI()

    # Test AI info
    print("=" * 70)
    print("AI Information:")
    print("=" * 70)
    info = ai.get_info()
    for key, value in info.items():
        print(f"{key}: {value}")

    # Test preflop decision
    print("\n" + "=" * 70)
    print("Test 1: Preflop with Premium Hand (AA)")
    print("=" * 70)
    test_state_1 = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 20},
            {'action': 'raise', 'min_amount': 40, 'max_amount': 200}
        ],
        'players': {
            'player1': {
                'hole_cards': ['Ah', 'As'],
                'chips': 1000,
                'current_bet': 10,
                'state': 'active'
            },
            'player2': {
                'chips': 950,
                'current_bet': 20,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': [],
        'pot': 30,
        'current_bet': 20,
        'phase': 'preflop',
        'dealer_index': 0
    }

    decision1 = ai.make_move(test_state_1)
    print(f"Decision: {decision1}")

    # Test flop decision
    print("\n" + "=" * 70)
    print("Test 2: Flop with Flush Draw")
    print("=" * 70)
    test_state_2 = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'check'},
            {'action': 'raise', 'min_amount': 30, 'max_amount': 200}
        ],
        'players': {
            'player1': {
                'hole_cards': ['Ah', 'Kh'],
                'chips': 970,
                'current_bet': 0,
                'state': 'active'
            },
            'player2': {
                'chips': 980,
                'current_bet': 0,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': ['Qh', 'Jh', '5c'],
        'pot': 60,
        'current_bet': 0,
        'phase': 'flop',
        'dealer_index': 0
    }

    decision2 = ai.make_move(test_state_2)
    print(f"Decision: {decision2}")

    print("\n" + "=" * 70)
    print("AI Testing Complete")
    print("=" * 70)
