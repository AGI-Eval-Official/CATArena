# Sonnet 4.5 Texas Hold'em AI

## Overview

This is an advanced Texas Hold'em poker AI powered by Claude Sonnet 4.5. The AI implements sophisticated strategies including hand evaluation, position awareness, opponent modeling, and adaptive betting.

## Features

### Core Capabilities
- **Advanced Hand Evaluation**: Uses modified Chen formula for pre-flop hands and comprehensive post-flop analysis
- **Position-Aware Strategy**: Adjusts play style based on position (early/middle/late)
- **Opponent Modeling**: Tracks opponent behavior and adapts strategy
- **Pot Odds Calculation**: Makes mathematically sound decisions based on pot odds
- **Draw Potential Analysis**: Recognizes flush draws, straight draws, and evaluates their value
- **Strategic Bluffing**: Context-aware bluffing based on position, phase, and opponents
- **Adaptive Aggression**: Dynamically adjusts aggression based on game state

### Strategy Highlights

1. **Pre-Flop Play**
   - Premium pairs (AA, KK, QQ) played aggressively
   - Strong hands (AK, AQ, JJ, TT) played for value
   - Position-dependent hand ranges
   - Suited connectors valued higher

2. **Post-Flop Play**
   - Made hands played for value
   - Draw hands evaluated based on pot odds
   - Semi-bluffing with strong draws
   - Check-raising with strong hands

3. **Position Strategy**
   - Tighter ranges in early position (90% multiplier)
   - Standard play in middle position (100% multiplier)
   - Looser/more aggressive in late position (115% multiplier)

4. **Betting Strategy**
   - Value bets: 60-80% of pot based on hand strength
   - Bluffs: 50-70% of pot for credibility
   - Steal attempts: 2.5-3x BB in late position

5. **Opponent Adaptation**
   - Tightens against aggressive players
   - Exploits passive players with more aggression
   - Adjusts for number of opponents in hand

## Configuration

The AI is configured via `ai_config.yaml`:

- **AI ID**: `sonnet_holdem_ai_v3`
- **Difficulty**: Expert
- **Base Aggression**: 0.70 (moderately aggressive)
- **Bluff Frequency**: 0.18 (18%)
- **Strategy**: Tight-aggressive with adaptive elements

## Testing Results

The AI has been tested with various scenarios:

1. **Pocket Aces Pre-Flop**: Correctly raises for value
2. **Flush Draw on Flop**: Checks to see turn card cheaply
3. **Weak Hand vs Raise**: Correctly folds

## File Structure

```
holdem_3/
├── ai_config.yaml    # AI configuration
├── ai_player.py      # AI implementation
└── README.md         # This file
```

## Implementation Details

### Hand Strength Thresholds
- Very Strong: 0.85+ (Always aggressive)
- Strong: 0.65-0.85 (Value betting)
- Medium: 0.45-0.65 (Cautious play)
- Playable: 0.30-0.45 (Selective play)
- Weak: <0.30 (Mostly fold)

### Key Methods

1. `evaluate_hand_strength()`: Evaluates hand strength (0.0-1.0)
2. `analyze_position()`: Determines position (early/middle/late)
3. `calculate_pot_odds()`: Computes pot odds for decision making
4. `make_move()`: Main decision-making method

### Decision Logic

The AI considers multiple factors:
- Raw hand strength
- Position multiplier
- Number of active opponents
- Opponent aggression levels
- Pot odds
- Stack-to-pot ratio
- Game phase (preflop/flop/turn/river)

## Usage

To use this AI in a battle:

1. Copy the `holdem_3` directory to the appropriate AI directory
2. Configure the battle JSON to include `sonnet_holdem_ai_v3`
3. Run the battle using the game engine

Example battle configuration:
```json
{
  "battle": {
    "rounds": 100,
    "timeout": 30,
    "verbose": false
  },
  "players": ["sonnet_holdem_ai_v3", "opponent_ai"],
  "mode": "traditional"
}
```

## Strategy Philosophy

This AI follows a tight-aggressive (TAG) strategy with adaptive elements:

- **Tight**: Plays strong starting hands, folds weak hands
- **Aggressive**: Bets and raises rather than calling
- **Adaptive**: Adjusts based on opponents and situation
- **Exploitative**: Exploits opponent weaknesses when detected

## Performance Optimization

- Efficient hand evaluation algorithms
- Pre-computed card value mappings
- Minimal computational overhead
- Fast decision making (typically <1 second)

## Future Enhancements

Potential improvements for future versions:
- Full Monte Carlo simulation for equity calculation
- More sophisticated opponent modeling with hand range estimation
- Game theory optimal (GTO) strategies for balanced play
- Learning from past games to identify patterns
- Advanced multi-street planning

## Author

**Claude Sonnet 4.5**

Version: 3.0
Date: 2025

---

*This AI is designed for competitive tournament play and aims to maximize long-term profitability through sound poker strategy and adaptive decision-making.*
