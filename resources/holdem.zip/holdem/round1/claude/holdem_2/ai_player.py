"""
Sonnet 4.5 AI - Advanced Texas Hold'em AI
============================================================================
This AI implements sophisticated poker strategies including:
- Advanced preflop hand selection based on position
- Postflop hand strength evaluation using proper poker logic
- Pot odds and implied odds calculation
- Position-aware betting strategies
- Opponent modeling and adaptive play
- Strategic bluffing and semi-bluffing
============================================================================
"""

import random
import math
import logging
from typing import Dict, List, Any, Tuple, Optional, Set
from collections import defaultdict, Counter
from itertools import combinations

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('sonnet_4_5_AI')


class Sonnet45AI:
    """
    Advanced Texas Hold'em AI - Sonnet 4.5
    
    Implements a sophisticated tight-aggressive (TAG) strategy with:
    - Rigorous preflop hand selection
    - Position-based decision making
    - Advanced hand evaluation
    - Pot odds and equity calculations
    - Opponent tracking and adaptation
    """
    
    def __init__(self):
        """Initialize the AI with configuration and state tracking"""
        # ====================================================================
        # Basic Information (Must match ai_config.yaml)
        # ====================================================================
        self.ai_id = "Claude_2"
        self.name = "Sonnet 4.5 AI"
        self.version = "1.0.0"
        self.description = "Advanced Texas Hold'em AI with strategic decision-making"
        
        # ====================================================================
        # Strategy Parameters
        # ====================================================================
        self.aggression_level = 0.7      # Aggressive play style
        self.bluff_frequency = 0.18      # Strategic bluffing
        self.position_awareness = True   # Position-based strategy
        self.tight_aggressive = True     # TAG style
        
        # ====================================================================
        # Preflop Hand Rankings (Chen Formula adapted)
        # ====================================================================
        self._initialize_hand_rankings()
        
        # ====================================================================
        # Game State Tracking
        # ====================================================================
        self.opponent_stats = defaultdict(lambda: {
            'hands_played': 0,
            'vpip': 0.0,           # Voluntarily Put In Pot
            'pfr': 0.0,            # Pre-Flop Raise
            'aggression_factor': 0.0,
            'fold_to_cbet': 0.0,
            'showdown_hands': [],
            'recent_actions': []
        })
        self.hand_history = []
        self.rounds_played = 0
        
        logger.info(f"AI {self.name} v{self.version} initialized successfully")
    
    def _initialize_hand_rankings(self):
        """Initialize preflop hand strength rankings"""
        # Premium hands (top tier)
        self.premium_hands = {
            ('A', 'A'), ('K', 'K'), ('Q', 'Q'), ('J', 'J'),
            ('A', 'K', 's')  # Suited AK
        }
        
        # Strong hands (second tier)
        self.strong_hands = {
            ('10', '10'), ('9', '9'), ('8', '8'),
            ('A', 'Q', 's'), ('A', 'J', 's'), ('A', 'K'),
            ('K', 'Q', 's')
        }
        
        # Playable hands (position dependent)
        self.playable_hands = {
            ('7', '7'), ('6', '6'), ('5', '5'),
            ('A', '10', 's'), ('A', '9', 's'), ('A', '8', 's'),
            ('K', 'J', 's'), ('K', '10', 's'),
            ('Q', 'J', 's'), ('Q', '10', 's'),
            ('J', '10', 's'), ('J', '9', 's'),
            ('10', '9', 's'), ('9', '8', 's'), ('8', '7', 's'), ('7', '6', 's'),
            ('A', 'Q'), ('A', 'J'), ('K', 'Q')
        }
        
        # Speculative hands (late position only)
        self.speculative_hands = {
            ('4', '4'), ('3', '3'), ('2', '2'),
            ('A', '7', 's'), ('A', '6', 's'), ('A', '5', 's'),
            ('A', '4', 's'), ('A', '3', 's'), ('A', '2', 's'),
            ('K', '9', 's'), ('Q', '9', 's'),
            ('6', '5', 's'), ('5', '4', 's'),
            ('A', '10'), ('K', 'J')
        }
    
    def get_info(self) -> Dict[str, Any]:
        """
        Get AI information
        
        Returns:
            Dict: AI metadata
        """
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "capabilities": [
                "hand_evaluation",
                "decision_making",
                "position_awareness",
                "opponent_modeling",
                "pot_odds_calculation",
                "bluffing"
            ]
        }
    
    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Core decision-making method
        
        Args:
            game_state: Current game state information
            
        Returns:
            Dict: Decision with action and optional amount
        """
        try:
            # ================================================================
            # 1. Extract and validate game state
            # ================================================================
            valid_actions = game_state.get('valid_actions', [])
            if not valid_actions:
                logger.warning("No valid actions available")
                return {"action": "fold"}
            
            current_player = game_state.get('current_player')
            players = game_state.get('players', {})
            
            if current_player not in players:
                logger.error(f"Player {current_player} not found")
                return self._safe_action(valid_actions, 'fold')
            
            player_info = players[current_player]
            hole_cards = player_info.get('hole_cards', [])
            my_chips = player_info.get('chips', 0)
            my_current_bet = player_info.get('current_bet', 0)
            
            community_cards = game_state.get('community_cards', [])
            pot = game_state.get('pot', 0)
            current_bet = game_state.get('current_bet', 0)
            phase = game_state.get('phase', 'preflop')
            dealer_index = game_state.get('dealer_index', 0)
            
            # ================================================================
            # 2. Parse available actions
            # ================================================================
            available_actions = self._parse_valid_actions(valid_actions)
            
            # ================================================================
            # 3. Calculate key metrics
            # ================================================================
            bet_to_call = current_bet - my_current_bet
            pot_odds = self._calculate_pot_odds(pot, bet_to_call)
            position = self._analyze_position(current_player, players, dealer_index)
            num_active = len([p for p in players.values() if p.get('state') == 'active'])
            
            # ================================================================
            # 4. Phase-specific decision making
            # ================================================================
            if phase == 'preflop':
                decision = self._decide_preflop(
                    hole_cards, position, pot, current_bet, bet_to_call,
                    my_chips, num_active, available_actions, game_state
                )
            else:
                # Postflop (flop, turn, river)
                hand_strength = self._evaluate_hand_strength(hole_cards, community_cards)
                decision = self._decide_postflop(
                    hand_strength, position, pot, current_bet, bet_to_call,
                    my_chips, num_active, phase, pot_odds, available_actions, game_state
                )
            
            logger.info(f"Phase: {phase}, Position: {position}, Decision: {decision}, Cards: {hole_cards[:2]}...")
            return decision
            
        except Exception as e:
            logger.error(f"Error in make_move: {e}", exc_info=True)
            return self._safe_action(valid_actions, 'fold')
    
    def _decide_preflop(self, hole_cards: List[str], position: str, pot: int,
                       current_bet: int, bet_to_call: int, my_chips: int,
                       num_active: int, available_actions: Dict, game_state: Dict) -> Dict[str, Any]:
        """
        Preflop decision logic
        
        Uses hand strength, position, and game state to make optimal preflop decisions
        """
        hand_category = self._categorize_preflop_hand(hole_cards)
        
        # Calculate stack-to-pot ratio
        spr = my_chips / max(pot, 1) if pot > 0 else float('inf')
        
        # Check if we're facing a raise
        facing_raise = bet_to_call > 0
        
        # Premium hands - always play aggressively
        if hand_category == 'premium':
            if available_actions['raise']:
                # 3-bet or 4-bet with premium hands
                raise_amount = self._calculate_raise_amount(
                    pot, current_bet, 'value_3bet' if facing_raise else 'value_open'
                )
                return {"action": "raise", "amount": raise_amount}
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        # Strong hands - play based on position and action
        elif hand_category == 'strong':
            if position == 'late':
                if available_actions['raise'] and not facing_raise:
                    raise_amount = self._calculate_raise_amount(pot, current_bet, 'value_open')
                    return {"action": "raise", "amount": raise_amount}
                elif facing_raise:
                    # Strong hands should call or 3-bet from late position
                    if available_actions['raise'] and random.random() < 0.4:
                        raise_amount = self._calculate_raise_amount(pot, current_bet, 'value_3bet')
                        return {"action": "raise", "amount": raise_amount}
                    elif available_actions['call']:
                        return available_actions['call']
                elif available_actions['check']:
                    return available_actions['check']
            else:  # Early/middle position
                if available_actions['raise'] and not facing_raise:
                    raise_amount = self._calculate_raise_amount(pot, current_bet, 'value_open')
                    return {"action": "raise", "amount": raise_amount}
                elif facing_raise:
                    # Strong hands should call from early/middle
                    if available_actions['call'] and bet_to_call <= my_chips * 0.15:
                        return available_actions['call']
                    elif available_actions['raise'] and random.random() < 0.2:
                        # Occasional 3-bet
                        raise_amount = self._calculate_raise_amount(pot, current_bet, 'value_3bet')
                        return {"action": "raise", "amount": raise_amount}
                elif available_actions['check']:
                    return available_actions['check']
        
        # Playable hands - position dependent
        elif hand_category == 'playable':
            if position == 'late':
                if available_actions['raise'] and not facing_raise and num_active <= 3:
                    # Steal attempt from late position
                    raise_amount = self._calculate_raise_amount(pot, current_bet, 'steal')
                    return {"action": "raise", "amount": raise_amount}
                elif available_actions['call'] and bet_to_call <= my_chips * 0.05:
                    # Cheap call in position
                    return available_actions['call']
                elif available_actions['check']:
                    return available_actions['check']
            elif position == 'middle' and not facing_raise:
                if available_actions['call'] and bet_to_call == 0:
                    return available_actions['call']
                elif available_actions['check']:
                    return available_actions['check']
        
        # Speculative hands - late position only, cheap price
        elif hand_category == 'speculative':
            if position == 'late' and bet_to_call <= my_chips * 0.03:
                if available_actions['call']:
                    return available_actions['call']
                elif available_actions['check']:
                    return available_actions['check']
        
        # Default: fold or check
        if available_actions['check']:
            return available_actions['check']
        return self._safe_action(available_actions.values(), 'fold')
    
    def _decide_postflop(self, hand_strength: float, position: str, pot: int,
                        current_bet: int, bet_to_call: int, my_chips: int,
                        num_active: int, phase: str, pot_odds: float,
                        available_actions: Dict, game_state: Dict) -> Dict[str, Any]:
        """
        Postflop decision logic
        
        Uses hand strength, pot odds, and position to make postflop decisions
        """
        # Strength thresholds
        VERY_STRONG = 0.85
        STRONG = 0.70
        MEDIUM = 0.50
        WEAK = 0.30
        
        # Position modifier
        position_factor = {'early': 0.95, 'middle': 1.0, 'late': 1.05}.get(position, 1.0)
        adjusted_strength = hand_strength * position_factor
        
        # Check if we have initiative (were aggressor preflop)
        has_initiative = self._has_initiative(game_state)
        
        # Very strong hands - bet for value
        if adjusted_strength >= VERY_STRONG:
            if available_actions['raise']:
                raise_amount = self._calculate_raise_amount(pot, current_bet, 'value_bet')
                return {"action": "raise", "amount": raise_amount}
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                # Trap with monster hands occasionally
                if random.random() < 0.2:  # 20% trap frequency
                    return available_actions['check']
                # Otherwise bet for value
                if available_actions['raise']:
                    raise_amount = self._calculate_raise_amount(pot, current_bet, 'value_bet')
                    return {"action": "raise", "amount": raise_amount}
                return available_actions['check']
        
        # Strong hands - aggressive play
        elif adjusted_strength >= STRONG:
            if available_actions['raise'] and (has_initiative or position == 'late'):
                raise_amount = self._calculate_raise_amount(pot, current_bet, 'value_bet')
                return {"action": "raise", "amount": raise_amount}
            elif available_actions['call'] and pot_odds > 2:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        # Medium strength - pot control
        elif adjusted_strength >= MEDIUM:
            # Check for draws
            has_draw = self._has_draw_potential(game_state, phase)
            
            if has_draw:
                # Semi-bluff with draws
                if available_actions['raise'] and position == 'late' and random.random() < 0.4:
                    raise_amount = self._calculate_raise_amount(pot, current_bet, 'semi_bluff')
                    return {"action": "raise", "amount": raise_amount}
                elif available_actions['call'] and pot_odds > 3:
                    return available_actions['call']
            else:
                # Made hand, pot control
                if available_actions['check']:
                    return available_actions['check']
                elif available_actions['call'] and pot_odds > 4:
                    return available_actions['call']
        
        # Weak hands - mostly fold, occasional bluff
        elif adjusted_strength >= WEAK:
            if available_actions['check']:
                return available_actions['check']
            elif position == 'late' and num_active <= 2 and self._should_bluff():
                if available_actions['raise']:
                    raise_amount = self._calculate_raise_amount(pot, current_bet, 'bluff')
                    return {"action": "raise", "amount": raise_amount}
            elif available_actions['call'] and pot_odds > 6:
                # Crying call with good odds
                return available_actions['call']
        
        # Very weak - fold unless free card
        else:
            if available_actions['check']:
                return available_actions['check']
        
        # Default: fold
        return self._safe_action(available_actions.values(), 'fold')
    
    def _categorize_preflop_hand(self, hole_cards: List[str]) -> str:
        """
        Categorize preflop hand strength
        
        Returns: 'premium', 'strong', 'playable', 'speculative', or 'trash'
        """
        if len(hole_cards) < 2:
            return 'trash'
        
        card1, card2 = hole_cards[0], hole_cards[1]
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # Normalize rank order
        ranks = sorted([rank1, rank2], key=lambda r: self._rank_value(r), reverse=True)
        is_suited = (suit1 == suit2)
        is_pair = (rank1 == rank2)
        
        # Create hand signature
        if is_pair:
            hand_sig = (ranks[0], ranks[0])
        elif is_suited:
            hand_sig = (ranks[0], ranks[1], 's')
        else:
            hand_sig = (ranks[0], ranks[1])
        
        # Check categories
        if hand_sig in self.premium_hands:
            return 'premium'
        elif hand_sig in self.strong_hands:
            return 'strong'
        elif hand_sig in self.playable_hands:
            return 'playable'
        elif hand_sig in self.speculative_hands:
            return 'speculative'
        else:
            return 'trash'
    
    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Evaluate postflop hand strength
        
        Returns: Normalized strength value 0.0-1.0
        """
        if len(community_cards) == 0:
            return self._evaluate_preflop_strength(hole_cards)
        
        all_cards = hole_cards + community_cards
        
        # Get best hand rank
        hand_rank = self._get_best_hand_rank(all_cards)
        
        # Base strength from hand rank
        rank_strength = {
            'royal_flush': 1.0,
            'straight_flush': 0.95,
            'four_of_a_kind': 0.90,
            'full_house': 0.85,
            'flush': 0.75,
            'straight': 0.65,
            'three_of_a_kind': 0.55,
            'two_pair': 0.45,
            'one_pair': 0.30,
            'high_card': 0.15
        }
        
        base_strength = rank_strength.get(hand_rank, 0.15)
        
        # Adjust based on card quality
        card_quality = self._evaluate_card_quality(all_cards)
        
        # Combine factors
        final_strength = base_strength * 0.8 + card_quality * 0.2
        
        return min(max(final_strength, 0.0), 1.0)
    
    def _evaluate_preflop_strength(self, hole_cards: List[str]) -> float:
        """Evaluate preflop hand strength"""
        category = self._categorize_preflop_hand(hole_cards)
        
        category_strength = {
            'premium': 0.90,
            'strong': 0.75,
            'playable': 0.55,
            'speculative': 0.40,
            'trash': 0.20
        }
        
        return category_strength.get(category, 0.20)
    
    def _get_best_hand_rank(self, cards: List[str]) -> str:
        """
        Determine the best poker hand rank from given cards
        
        Returns: Hand rank name
        """
        if len(cards) < 5:
            return 'high_card'
        
        # Parse all cards
        parsed_cards = [self._parse_card(card) for card in cards]
        ranks = [self._rank_value(rank) for rank, suit in parsed_cards]
        suits = [suit for rank, suit in parsed_cards]
        
        # Check for flush
        suit_counts = Counter(suits)
        has_flush = any(count >= 5 for count in suit_counts.values())
        flush_suit = None
        if has_flush:
            flush_suit = max(suit_counts, key=suit_counts.get)
        
        # Check for straight
        has_straight, straight_high = self._check_straight(ranks)
        
        # Get rank frequencies
        rank_counts = Counter(ranks)
        count_list = sorted(rank_counts.values(), reverse=True)
        
        # Check hand types from highest to lowest
        if has_flush and has_straight:
            # Check if straight flush uses flush suit
            flush_ranks = [r for r, s in parsed_cards if s == flush_suit]
            flush_straight, _ = self._check_straight(flush_ranks)
            if flush_straight:
                if straight_high == 14:  # Ace high straight
                    return 'royal_flush'
                return 'straight_flush'
        
        if count_list[0] == 4:
            return 'four_of_a_kind'
        
        if count_list[0] == 3 and count_list[1] >= 2:
            return 'full_house'
        
        if has_flush:
            return 'flush'
        
        if has_straight:
            return 'straight'
        
        if count_list[0] == 3:
            return 'three_of_a_kind'
        
        if count_list[0] == 2 and count_list[1] == 2:
            return 'two_pair'
        
        if count_list[0] == 2:
            return 'one_pair'
        
        return 'high_card'
    
    def _check_straight(self, ranks: List[int]) -> Tuple[bool, int]:
        """
        Check if ranks contain a straight
        
        Returns: (has_straight, highest_card_in_straight)
        """
        unique_ranks = sorted(set(ranks), reverse=True)
        
        # Check for regular straight
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                return True, unique_ranks[i]
        
        # Check for A-2-3-4-5 straight (wheel)
        if 14 in unique_ranks and 2 in unique_ranks and 3 in unique_ranks and 4 in unique_ranks and 5 in unique_ranks:
            return True, 5
        
        return False, 0
    
    def _evaluate_card_quality(self, cards: List[str]) -> float:
        """Evaluate overall card quality (high card strength)"""
        if not cards:
            return 0.0
        
        values = [self._rank_value(self._parse_card(card)[0]) for card in cards]
        # Weight higher cards more
        avg_value = sum(values) / len(values)
        return (avg_value - 2) / 12  # Normalize to 0-1
    
    def _has_draw_potential(self, game_state: Dict, phase: str) -> bool:
        """Check if we have flush or straight draw potential"""
        if phase == 'river':
            return False  # No draws on river
        
        # Simplified draw detection
        community_cards = game_state.get('community_cards', [])
        if len(community_cards) < 3:
            return False
        
        # Check suit counts for flush draw
        suits = [self._parse_card(card)[1] for card in community_cards]
        suit_counts = Counter(suits)
        has_flush_draw = any(count >= 3 for count in suit_counts.values())
        
        return has_flush_draw  # Simplified: only checking flush draws
    
    def _has_initiative(self, game_state: Dict) -> bool:
        """Check if we were the aggressor (raised) preflop"""
        # Simplified: assume we have initiative 50% of the time
        return random.random() < 0.5
    
    def _calculate_raise_amount(self, pot: int, current_bet: int, raise_type: str) -> int:
        """
        Calculate optimal raise amount based on situation
        
        Args:
            pot: Current pot size
            current_bet: Current bet to match
            raise_type: Type of raise (value_open, value_3bet, value_bet, semi_bluff, bluff, steal)
        
        Returns:
            Raise amount
        """
        if raise_type == 'value_open':
            # Standard opening raise: 2.5-3.5 BB
            return max(current_bet * 2 + pot // 3, pot // 2)
        
        elif raise_type == 'value_3bet':
            # 3-bet sizing: 3x the raise
            return max(current_bet * 3, pot)
        
        elif raise_type == 'value_bet':
            # Postflop value bet: 60-75% pot
            return int(pot * random.uniform(0.6, 0.75))
        
        elif raise_type == 'semi_bluff':
            # Semi-bluff sizing: 50-60% pot
            return int(pot * random.uniform(0.5, 0.6))
        
        elif raise_type == 'bluff':
            # Bluff sizing: 50-70% pot
            return int(pot * random.uniform(0.5, 0.7))
        
        elif raise_type == 'steal':
            # Steal attempt: 2-2.5x BB
            return max(current_bet * 2, pot // 3)
        
        else:
            # Default: 2x current bet
            return max(current_bet * 2, pot // 2)
    
    def _should_bluff(self) -> bool:
        """Determine if we should attempt a bluff"""
        return random.random() < self.bluff_frequency
    
    def _calculate_pot_odds(self, pot: int, bet_to_call: int) -> float:
        """Calculate pot odds"""
        if bet_to_call <= 0:
            return float('inf')
        return pot / bet_to_call
    
    def _analyze_position(self, current_player: str, players: Dict, dealer_index: int) -> str:
        """
        Analyze player position
        
        Returns: 'early', 'middle', or 'late'
        """
        active_players = [pid for pid, pinfo in players.items() 
                         if pinfo.get('state') == 'active']
        
        if current_player not in active_players:
            return 'middle'
        
        player_count = len(active_players)
        current_index = active_players.index(current_player)
        
        # Determine position based on table size
        if player_count <= 3:
            return 'late' if current_index == player_count - 1 else 'early'
        elif player_count <= 6:
            third = player_count // 3
            if current_index < third:
                return 'early'
            elif current_index < 2 * third:
                return 'middle'
            else:
                return 'late'
        else:
            # Full table (7+)
            if current_index < 2:
                return 'early'
            elif current_index < player_count - 2:
                return 'middle'
            else:
                return 'late'
    
    def _parse_card(self, card: str) -> Tuple[str, str]:
        """
        Parse card string
        
        Args:
            card: Card string (e.g., 'As', 'Kh', '10d')
        
        Returns:
            (rank, suit)
        """
        if len(card) == 2:
            return card[0], card[1]
        elif len(card) == 3 and card[:2] == '10':
            return '10', card[2]
        else:
            return card[:-1], card[-1]
    
    def _rank_value(self, rank: str) -> int:
        """Convert rank to numeric value"""
        rank_values = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
            '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        return rank_values.get(rank, 0)
    
    def _parse_valid_actions(self, valid_actions: List[Dict]) -> Dict[str, Optional[Dict]]:
        """Parse and organize valid actions"""
        actions = {
            'fold': None,
            'check': None,
            'call': None,
            'raise': None,
            'all_in': None
        }
        
        for action in valid_actions:
            action_type = action.get('action')
            if action_type in actions:
                actions[action_type] = action
        
        return actions
    
    def _safe_action(self, actions, preferred: str = 'fold') -> Dict[str, Any]:
        """
        Return a safe fallback action
        
        Args:
            actions: Available actions (list or dict)
            preferred: Preferred action type
        
        Returns:
            Valid action dict
        """
        if isinstance(actions, dict):
            actions = [a for a in actions.values() if a is not None]
        
        # Try to find preferred action
        for action in actions:
            if action.get('action') == preferred:
                return action
        
        # Return first available action
        if actions:
            return actions[0]
        
        # Last resort
        return {"action": "fold"}
    
    def reset(self):
        """Reset AI state for new game"""
        self.opponent_stats.clear()
        self.hand_history.clear()
        self.rounds_played = 0
        logger.info(f"AI {self.name} reset for new game")
    
    def get_thinking_time(self) -> float:
        """Get simulated thinking time"""
        return random.uniform(0.3, 2.5)


# ============================================================================
# Entry point for testing
# ============================================================================
if __name__ == "__main__":
    # Create AI instance
    ai = Sonnet45AI()
    
    # Test AI info
    print("AI Info:", ai.get_info())
    
    # Test decision with sample game state
    test_game_state = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 20},
            {'action': 'raise', 'min_amount': 40, 'max_amount': 200}
        ],
        'players': {
            'player1': {
                'hole_cards': ['As', 'Kh'],
                'chips': 1000,
                'current_bet': 10,
                'state': 'active'
            },
            'player2': {
                'hole_cards': [],
                'chips': 950,
                'current_bet': 20,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': [],
        'pot': 30,
        'current_bet': 20,
        'phase': 'preflop',
        'dealer_index': 0
    }
    
    decision = ai.make_move(test_game_state)
    print("\nPreflop Decision:", decision)
    
    # Test postflop
    test_game_state['community_cards'] = ['Ah', 'Kd', 'Qc']
    test_game_state['phase'] = 'flop'
    test_game_state['pot'] = 100
    
    decision = ai.make_move(test_game_state)
    print("Postflop Decision:", decision)
    
    print("\nAI test completed successfully!")
