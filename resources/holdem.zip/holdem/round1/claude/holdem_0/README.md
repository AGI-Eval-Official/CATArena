# Sonnet 4.5 AI - Texas Hold'em AI

## Overview

This is an advanced, competitive Texas Hold'em AI powered by Claude Sonnet 4.5. The AI implements sophisticated strategies combining game theory optimal (GTO) play with exploitative adjustments.

## Features

### Core Capabilities
- **Accurate Hand Evaluation**: Uses the game's poker_logic engine for precise hand strength assessment
- **Position-Aware Strategy**: Adjusts play based on table position (early, middle, late, button)
- **Mathematical Decision Making**: Calculates pot odds, equity, and hand potential
- **Adaptive Betting**: Context-sensitive bet sizing for value bets, bluffs, and steals
- **Phase-Specific Strategy**: Different approaches for pre-flop, flop, turn, and river

### Strategic Components

#### Pre-flop Strategy
- Premium hands (AA, KK, QQ, AKs): Aggressive raising
- Strong hands (AK, AQ, JJ, TT): Position-dependent aggression
- Playable hands: Selective play based on position and pot odds
- Marginal hands: Opportunistic stealing in late position

#### Post-flop Strategy
- **Very Strong Hands** (trips+): Value betting with occasional slow-playing
- **Strong Hands** (top pair+): Continuation betting and pot control
- **Medium Hands** (pairs, draws): Pot odds-based decisions
- **Weak Hands**: Selective bluffing in favorable situations

#### Key Features
1. **Hand Strength Evaluation**
   - Pre-flop: Chen formula-inspired rankings
   - Post-flop: Full poker_logic hand evaluation with kicker consideration

2. **Position Awareness**
   - Early position: Tighter range, conservative play
   - Middle position: Balanced approach
   - Late position & button: Wider range, more aggression

3. **Pot Odds Calculation**
   - Mathematical decision making for calls
   - Equity vs pot odds comparison
   - Hand potential factoring

4. **Bet Sizing**
   - Value bets: 50-85% pot
   - Continuation bets: 50-70% pot
   - Bluffs: 40-60% pot
   - Steals: 2-2.5x big blind

## File Structure

```
holdem_0/
├── ai_player.py       # Main AI implementation
├── ai_config.yaml     # Configuration file
└── README.md         # This file
```

## Configuration

The AI is configured via `ai_config.yaml`:
- **Strategy**: Moderate-high aggression (0.65), selective bluffing (0.12)
- **Difficulty**: Expert
- **Game Mode**: Traditional (52-card deck)

## Implementation Details

### Key Methods

- `make_move()`: Core decision-making entry point
- `_preflop_strategy()`: Pre-flop decision logic
- `_postflop_strategy()`: Post-flop decision logic
- `_evaluate_preflop_strength()`: Pre-flop hand strength evaluation
- `_evaluate_postflop_strength()`: Post-flop hand evaluation using poker_logic
- `_calculate_hand_potential()`: Draw and improvement potential
- `_analyze_position()`: Position determination
- `_calculate_pot_odds()`: Pot odds calculation
- `_get_raise_action()`: Valid raise action generation

### Dependencies

- Python 3.7+
- poker_logic engine from /data/CATArena/GamesEnv/games/holdem/engines/

## Testing

The AI has been tested against other AIs and demonstrates:
- Valid action selection
- Strategic hand evaluation
- Position-aware decision making
- Proper bet sizing

## Usage

The AI is automatically discovered by the game engine when placed in:
```
/data/CATArena/GamesEnv/ai_players/holdem/traditional/sonnet_4_5_ai/
```

To run battles:
```bash
cd /data/CATArena/GamesEnv/games/holdem
python cli_battle.py --players "sonnet_4_5_ai,other_ai" --games 10 --mode traditional
```

## Strategy Philosophy

The AI follows a **tight-aggressive** strategy:
1. Play strong hands aggressively
2. Fold marginal hands in unfavorable positions
3. Apply pressure with position advantage
4. Use mathematics (pot odds, equity) for borderline decisions
5. Mix value bets with selective bluffs to remain unpredictable

## Future Improvements

Potential enhancements:
- Opponent modeling and exploitation
- Tournament-specific ICM considerations
- Advanced GTO solver integration
- Meta-game adaptation
- Hand range analysis

## Author

Claude Sonnet 4.5

## Version

1.0.0
