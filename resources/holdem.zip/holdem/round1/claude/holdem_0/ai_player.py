"""
Claude Sonnet 4.5 Holdem AI - Advanced Strategy Implementation
==============================================================================
A competitive Texas Hold'em AI featuring:
- Comprehensive hand strength evaluation using poker_logic
- Position-aware strategy
- Pot odds and equity calculations
- Adaptive betting patterns
- Opponent modeling
==============================================================================
"""

import sys
import os
import random
import logging
from typing import Dict, List, Any, Tuple, Optional
from collections import defaultdict
from itertools import combinations

# Add game engine path to import poker logic
game_path = '/data/CATArena/GamesEnv/games/holdem'
if game_path not in sys.path:
    sys.path.insert(0, game_path)

try:
    from engines.poker_logic import (
        create_card_from_string,
        HandEvaluator,
        string_list_to_cards,
        HandRank
    )
    POKER_LOGIC_AVAILABLE = True
except ImportError:
    POKER_LOGIC_AVAILABLE = False
    logging.warning("Poker logic engine not available, using fallback evaluation")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('sonnet_4_5_ai')


class Sonnet_4_5_AI:
    """
    Advanced Texas Hold'em AI for Traditional Mode

    This AI implements a sophisticated strategy combining:
    - Accurate hand evaluation using the game's poker_logic engine
    - Position-based play adjustments
    - Mathematical pot odds calculations
    - Opponent tendency tracking
    - Game theory optimal (GTO) inspired decisions with exploitative adjustments
    """

    def __init__(self):
        """Initialize the AI with configuration and state tracking"""

        # ====================================================================
        # Basic Information (Required)
        # ====================================================================
        self.ai_id = "Claude_0"
        self.name = "Sonnet 4.5 AI"
        self.version = "1.0.0"
        self.description = "Advanced competitive Texas Hold'em AI powered by Claude Sonnet 4.5"

        # ====================================================================
        # Strategy Parameters
        # ====================================================================
        self.aggression_level = 0.65      # Moderate-high aggression
        self.bluff_frequency = 0.12       # Selective bluffing
        self.position_awareness = True
        self.tight_aggressive = True

        # Advanced parameters
        self.continuation_bet_frequency = 0.7  # C-bet frequency
        self.three_bet_frequency = 0.08        # 3-bet frequency
        self.fold_to_three_bet = 0.65          # Fold to 3-bet threshold

        # ====================================================================
        # Game State Tracking
        # ====================================================================
        self.opponent_stats = defaultdict(lambda: {
            'hands_played': 0,
            'vpip': 0.0,           # Voluntarily Put money In Pot
            'pfr': 0.0,            # Pre-Flop Raise
            'aggression_factor': 1.0,
            'fold_to_cbet': 0.5,
            'fold_to_bet': 0.5,
            'recent_actions': [],
            'showdown_hands': []
        })
        self.hand_history = []
        self.current_hand_actions = []
        self.hand_count = 0

        # Pre-flop hand rankings (Chen formula inspired)
        self._init_preflop_rankings()

        logger.info(f"AI {self.name} (v{self.version}) initialized successfully")

    def _init_preflop_rankings(self):
        """Initialize pre-flop hand strength rankings"""
        # Premium hands
        self.premium_hands = {
            'AA', 'KK', 'QQ', 'AKs', 'JJ'
        }

        # Strong hands
        self.strong_hands = {
            'AKo', 'AQs', 'AJs', 'KQs', 'TT', '99'
        }

        # Playable hands
        self.playable_hands = {
            'AQo', 'AJo', 'ATs', 'KQo', 'KJs', 'QJs', 'JTs',
            '88', '77', '66', 'A9s', 'A8s', 'KTs', 'QTs'
        }

    def get_info(self) -> Dict[str, Any]:
        """Return AI information for game engine identification"""
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "capabilities": [
                "hand_evaluation",
                "decision_making",
                "position_awareness",
                "pot_odds_calculation",
                "opponent_modeling",
                "equity_calculation"
            ]
        }

    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Core decision-making method

        Args:
            game_state: Complete game state including players, cards, pot, etc.

        Returns:
            Decision dictionary with action and optional amount
        """
        try:
            # ================================================================
            # 1. Extract and validate game state
            # ================================================================
            valid_actions = game_state.get('valid_actions', [])
            if not valid_actions:
                logger.warning("No valid actions available")
                return {"action": "fold"}

            current_player = game_state.get('current_player')
            players = game_state.get('players', {})

            if current_player not in players:
                logger.error(f"Current player {current_player} not found")
                return self._safe_action(valid_actions, 'fold')

            # Get player-specific information
            player_info = players[current_player]
            hole_cards = player_info.get('hole_cards', [])
            my_chips = player_info.get('chips', 0)
            my_current_bet = player_info.get('current_bet', 0)

            # Get game information
            community_cards = game_state.get('community_cards', [])
            pot = game_state.get('pot', 0)
            current_bet = game_state.get('current_bet', 0)
            phase = game_state.get('phase', 'preflop')
            dealer_index = game_state.get('dealer_index', 0)

            # ================================================================
            # 2. Parse available actions
            # ================================================================
            available_actions = self._parse_valid_actions(valid_actions)

            # ================================================================
            # 3. Evaluate hand strength
            # ================================================================
            if phase == 'preflop':
                hand_strength = self._evaluate_preflop_strength(hole_cards)
                hand_potential = 0.5  # Unknown potential pre-flop
            else:
                hand_strength = self._evaluate_postflop_strength(hole_cards, community_cards)
                hand_potential = self._calculate_hand_potential(hole_cards, community_cards)

            # ================================================================
            # 4. Calculate position advantage
            # ================================================================
            position = self._analyze_position(current_player, players, dealer_index)
            position_strength = {'early': 0.85, 'middle': 1.0, 'late': 1.2, 'button': 1.3}.get(position, 1.0)

            # ================================================================
            # 5. Calculate pot odds and equity
            # ================================================================
            bet_to_call = current_bet - my_current_bet
            pot_odds = self._calculate_pot_odds(pot, bet_to_call) if bet_to_call > 0 else float('inf')
            effective_stack = my_chips
            stack_to_pot_ratio = effective_stack / pot if pot > 0 else float('inf')

            # ================================================================
            # 6. Analyze opponents
            # ================================================================
            num_active_opponents = len([p for p, info in players.items()
                                       if p != current_player and info.get('state') == 'active'])

            # ================================================================
            # 7. Make strategic decision
            # ================================================================
            decision = self._make_strategic_decision(
                hand_strength=hand_strength,
                hand_potential=hand_potential,
                position=position,
                position_strength=position_strength,
                pot_odds=pot_odds,
                stack_to_pot_ratio=stack_to_pot_ratio,
                num_opponents=num_active_opponents,
                available_actions=available_actions,
                phase=phase,
                pot=pot,
                current_bet=current_bet,
                my_current_bet=my_current_bet,
                my_chips=my_chips,
                hole_cards=hole_cards,
                community_cards=community_cards
            )

            logger.info(f"Phase: {phase}, Hand: {hole_cards}, Strength: {hand_strength:.2f}, "
                       f"Position: {position}, Decision: {decision['action']}")

            return decision

        except Exception as e:
            logger.error(f"Error in make_move: {e}", exc_info=True)
            return self._safe_action(valid_actions, 'fold')

    def _parse_valid_actions(self, valid_actions: List[Dict]) -> Dict[str, Optional[Dict]]:
        """Parse available actions into a structured dictionary"""
        actions = {
            'fold': None,
            'check': None,
            'call': None,
            'raise': None,
            'all_in': None
        }

        for action in valid_actions:
            action_type = action.get('action')
            if action_type in actions:
                actions[action_type] = action

        return actions

    def _make_strategic_decision(
        self,
        hand_strength: float,
        hand_potential: float,
        position: str,
        position_strength: float,
        pot_odds: float,
        stack_to_pot_ratio: float,
        num_opponents: int,
        available_actions: Dict,
        phase: str,
        pot: int,
        current_bet: int,
        my_current_bet: int,
        my_chips: int,
        hole_cards: List[str],
        community_cards: List[str]
    ) -> Dict[str, Any]:
        """
        Advanced strategic decision making

        Combines multiple factors:
        - Hand strength and potential
        - Position
        - Pot odds
        - Stack sizes
        - Number of opponents
        - Game phase
        """

        # Adjust hand strength by position
        adjusted_strength = hand_strength * position_strength

        # Factor in hand potential for drawing situations
        if phase in ['flop', 'turn']:
            adjusted_strength = adjusted_strength * 0.7 + hand_potential * 0.3

        # Calculate bet size needed to call
        bet_to_call = current_bet - my_current_bet

        # ================================================================
        # Pre-flop Strategy
        # ================================================================
        if phase == 'preflop':
            return self._preflop_strategy(
                adjusted_strength, position, available_actions,
                pot, current_bet, my_current_bet, my_chips, num_opponents
            )

        # ================================================================
        # Post-flop Strategy
        # ================================================================
        else:
            return self._postflop_strategy(
                adjusted_strength, hand_potential, position, pot_odds,
                available_actions, phase, pot, current_bet,
                my_current_bet, my_chips, num_opponents
            )

    def _preflop_strategy(
        self,
        hand_strength: float,
        position: str,
        available_actions: Dict,
        pot: int,
        current_bet: int,
        my_current_bet: int,
        my_chips: int,
        num_opponents: int
    ) -> Dict[str, Any]:
        """Pre-flop decision strategy"""

        bet_to_call = current_bet - my_current_bet
        is_facing_raise = bet_to_call > 0

        # Premium hands (top 5%)
        if hand_strength >= 0.85:
            if available_actions['raise']:
                # Always raise/re-raise with premium hands
                return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'value', 3.0)
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                # Slow play occasionally in late position
                if position in ['late', 'button'] and random.random() < 0.15:
                    return available_actions['check']
                # Otherwise raise if possible
                if available_actions['raise']:
                    return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'value', 3.0)
                return available_actions['check']

        # Strong hands (top 15%)
        elif hand_strength >= 0.70:
            if is_facing_raise:
                # Call or 3-bet based on position
                if position in ['late', 'button'] and random.random() < self.three_bet_frequency:
                    if available_actions['raise']:
                        return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'value', 2.5)
                if available_actions['call']:
                    return available_actions['call']
            else:
                # Open raise in any position
                if available_actions['raise']:
                    return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'open', 2.5)
                elif available_actions['check']:
                    return available_actions['check']

        # Playable hands (top 30%)
        elif hand_strength >= 0.50:
            if is_facing_raise:
                # Fold to raise in early position
                if position == 'early':
                    if available_actions['fold']:
                        return available_actions['fold']
                # Call in middle/late position
                elif pot / max(bet_to_call, 1) > 2.5:  # Good pot odds
                    if available_actions['call']:
                        return available_actions['call']
            else:
                # Open raise in late position
                if position in ['late', 'button'] and available_actions['raise']:
                    return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'open', 2.0)
                elif available_actions['check']:
                    return available_actions['check']

        # Marginal hands (top 50%)
        elif hand_strength >= 0.35:
            if is_facing_raise:
                # Fold to raise
                if available_actions['fold']:
                    return available_actions['fold']
            else:
                # Steal attempt in late position with few opponents
                if position in ['late', 'button'] and num_opponents <= 2:
                    if available_actions['raise'] and random.random() < 0.4:
                        return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'steal', 2.0)
                if available_actions['check']:
                    return available_actions['check']

        # Weak hands - fold or check
        if available_actions['check']:
            return available_actions['check']
        if available_actions['fold']:
            return available_actions['fold']

        # Fallback
        return self._safe_action(list(available_actions.values()), 'fold')

    def _postflop_strategy(
        self,
        hand_strength: float,
        hand_potential: float,
        position: str,
        pot_odds: float,
        available_actions: Dict,
        phase: str,
        pot: int,
        current_bet: int,
        my_current_bet: int,
        my_chips: int,
        num_opponents: int
    ) -> Dict[str, Any]:
        """Post-flop decision strategy"""

        bet_to_call = current_bet - my_current_bet
        is_facing_bet = bet_to_call > 0

        # ================================================================
        # Very Strong Hands (Trips or better)
        # ================================================================
        if hand_strength >= 0.80:
            if available_actions['raise']:
                # Value bet/raise
                bet_size = 'large' if hand_strength >= 0.90 else 'medium'
                multiplier = 0.85 if bet_size == 'large' else 0.65
                return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'value', multiplier)
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                # Slow play occasionally on flop
                if phase == 'flop' and random.random() < 0.2:
                    return available_actions['check']
                # Otherwise try to build pot
                if available_actions['raise']:
                    return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'value', 0.65)
                return available_actions['check']

        # ================================================================
        # Strong Hands (Top pair good kicker, overpair, strong draws)
        # ================================================================
        elif hand_strength >= 0.60:
            if is_facing_bet:
                # Calculate if we have the right odds to call
                pot_odds_percentage = 1.0 / (pot_odds + 1) if pot_odds != float('inf') else 0
                required_equity = pot_odds_percentage

                # Call if we have sufficient equity
                if hand_strength + hand_potential * 0.3 >= required_equity * 0.8:
                    if available_actions['call']:
                        return available_actions['call']
                    elif available_actions['raise'] and hand_strength >= 0.70:
                        # Semi-bluff raise with strong hand
                        return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'value', 0.5)
                else:
                    if available_actions['fold']:
                        return available_actions['fold']
            else:
                # We're first to act or facing a check
                if available_actions['raise']:
                    # Continuation bet or value bet
                    return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'cbet', 0.6)
                elif available_actions['check']:
                    # Check for pot control
                    if num_opponents > 2:
                        return available_actions['check']
                    # Otherwise bet
                    if available_actions['raise']:
                        return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'value', 0.5)
                    return available_actions['check']

        # ================================================================
        # Medium Hands (Decent pair, good draws)
        # ================================================================
        elif hand_strength >= 0.40:
            if is_facing_bet:
                # Calculate pot odds
                pot_odds_percentage = 1.0 / (pot_odds + 1) if pot_odds != float('inf') else 0

                # Call with good pot odds or strong potential
                if pot_odds > 2.5 or hand_potential >= 0.6:
                    if available_actions['call']:
                        return available_actions['call']

                # Otherwise fold
                if available_actions['fold']:
                    return available_actions['fold']
            else:
                # Check or make a small continuation bet
                if available_actions['check']:
                    return available_actions['check']

                # Bluff occasionally in late position
                if position in ['late', 'button'] and random.random() < self.bluff_frequency:
                    if available_actions['raise']:
                        return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'bluff', 0.5)

                if available_actions['check']:
                    return available_actions['check']

        # ================================================================
        # Weak Hands
        # ================================================================
        else:
            if is_facing_bet:
                # Fold to any bet
                if available_actions['fold']:
                    return available_actions['fold']
            else:
                # Check
                if available_actions['check']:
                    return available_actions['check']

                # Bluff very occasionally in favorable situations
                if (position == 'button' and num_opponents == 1 and
                    phase == 'river' and random.random() < 0.1):
                    if available_actions['raise']:
                        return self._get_raise_action(available_actions['raise'], pot, current_bet, my_chips, 'bluff', 0.7)

        # ================================================================
        # Default fallback
        # ================================================================
        if available_actions['check']:
            return available_actions['check']
        if available_actions['fold']:
            return available_actions['fold']
        if available_actions['call']:
            return available_actions['call']

        return self._safe_action(list(available_actions.values()), 'fold')

    def _evaluate_preflop_strength(self, hole_cards: List[str]) -> float:
        """
        Evaluate pre-flop hand strength using advanced rankings

        Returns value between 0.0 and 1.0
        """
        if len(hole_cards) != 2:
            return 0.0

        card1, card2 = hole_cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)

        # Rank values
        rank_values = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
            '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }

        val1 = rank_values.get(rank1, 0)
        val2 = rank_values.get(rank2, 0)
        high_card = max(val1, val2)
        low_card = min(val1, val2)

        is_suited = (suit1 == suit2)
        is_pair = (val1 == val2)

        # Create hand notation for lookup
        if is_pair:
            hand_notation = f"{rank1}{rank2}"
        else:
            high_rank = rank1 if val1 > val2 else rank2
            low_rank = rank2 if val1 > val2 else rank1
            suited_char = 's' if is_suited else 'o'
            hand_notation = f"{high_rank}{low_rank}{suited_char}"

        # Check against hand categories
        if hand_notation in self.premium_hands or (is_pair and high_card >= 11):
            base_strength = 0.85 + (high_card - 11) * 0.03
        elif hand_notation in self.strong_hands:
            base_strength = 0.70 + (high_card - 10) * 0.03
        elif hand_notation in self.playable_hands:
            base_strength = 0.50 + (high_card - 9) * 0.02
        else:
            # Calculate based on card values
            if is_pair:
                base_strength = 0.35 + (high_card - 2) * 0.04
            else:
                base_strength = (high_card + low_card) / 28.0

                # Suited bonus
                if is_suited:
                    base_strength += 0.08

                # Connected bonus
                gap = abs(val1 - val2)
                if gap == 1:
                    base_strength += 0.06
                elif gap == 2:
                    base_strength += 0.03
                elif gap == 3:
                    base_strength += 0.01

                # High card bonus
                if high_card == 14:  # Ace
                    base_strength += 0.12
                elif high_card >= 12:  # K, Q
                    base_strength += 0.06

        return min(base_strength, 1.0)

    def _evaluate_postflop_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Evaluate post-flop hand strength using poker_logic engine

        Returns normalized strength between 0.0 and 1.0
        """
        if not POKER_LOGIC_AVAILABLE:
            return self._fallback_postflop_evaluation(hole_cards, community_cards)

        try:
            all_cards = hole_cards + community_cards
            if len(all_cards) < 5:
                # Not enough cards for full evaluation
                return self._evaluate_preflop_strength(hole_cards) * 0.5

            # Convert to Card objects
            card_objects = string_list_to_cards(all_cards)

            # Evaluate hand
            best_hand = HandEvaluator.evaluate_hand(card_objects)

            # Map hand rank to strength
            hand_rank_strength = {
                HandRank.HIGH_CARD: 0.15,
                HandRank.PAIR: 0.35,
                HandRank.TWO_PAIR: 0.50,
                HandRank.THREE_OF_A_KIND: 0.65,
                HandRank.STRAIGHT: 0.75,
                HandRank.FLUSH: 0.82,
                HandRank.FULL_HOUSE: 0.90,
                HandRank.FOUR_OF_A_KIND: 0.96,
                HandRank.STRAIGHT_FLUSH: 0.99,
                HandRank.ROYAL_FLUSH: 1.0
            }

            base_strength = hand_rank_strength.get(best_hand.rank, 0.15)

            # Adjust based on rank values (kicker strength)
            if best_hand.rank_values:
                high_value = best_hand.rank_values[0]
                # Bonus for high kickers
                kicker_bonus = (high_value - 7) / 100.0
                base_strength += kicker_bonus

            return min(base_strength, 1.0)

        except Exception as e:
            logger.warning(f"Error in postflop evaluation: {e}, using fallback")
            return self._fallback_postflop_evaluation(hole_cards, community_cards)

    def _fallback_postflop_evaluation(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Fallback evaluation if poker_logic is not available"""
        # Simple fallback based on card counting
        all_cards = hole_cards + community_cards

        if len(all_cards) < 5:
            return 0.3

        # Count ranks and suits
        ranks = []
        suits = []

        for card in all_cards:
            rank, suit = self._parse_card(card)
            ranks.append(rank)
            suits.append(suit)

        # Simple heuristics
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1

        max_count = max(rank_counts.values())
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        max_suit = max(suit_counts.values())

        # Estimate strength
        if max_count >= 4:
            return 0.95
        elif max_count == 3 and len(rank_counts) <= 3:
            return 0.88  # Full house possible
        elif max_suit >= 5:
            return 0.80
        elif max_count == 3:
            return 0.65
        elif max_count == 2 and len([c for c in rank_counts.values() if c == 2]) >= 2:
            return 0.50
        elif max_count == 2:
            return 0.35
        else:
            return 0.20

    def _calculate_hand_potential(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Calculate potential for hand improvement

        Returns value between 0.0 (no potential) and 1.0 (strong potential)
        """
        if len(community_cards) >= 5:
            # River - no more cards coming
            return 0.0

        # Simple potential calculation based on draws
        all_cards = hole_cards + community_cards

        # Count suits and ranks for draw potential
        suits = {}
        ranks = []

        for card in all_cards:
            rank, suit = self._parse_card(card)
            suits[suit] = suits.get(suit, 0) + 1
            rank_val = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                       '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}.get(rank, 0)
            ranks.append(rank_val)

        potential = 0.0

        # Flush draw potential
        max_suit_count = max(suits.values())
        if max_suit_count == 4:
            potential = max(potential, 0.8)  # Flush draw
        elif max_suit_count == 3:
            potential = max(potential, 0.4)  # Backdoor flush draw

        # Straight draw potential
        sorted_ranks = sorted(set(ranks))
        if len(sorted_ranks) >= 3:
            # Check for potential straights
            for i in range(len(sorted_ranks) - 2):
                gap = sorted_ranks[i + 2] - sorted_ranks[i]
                if gap <= 4:  # Potential for straight
                    potential = max(potential, 0.7)
                    break

        # Pair potential (if we have high cards)
        if not any(ranks.count(r) >= 2 for r in ranks):
            high_card = max(ranks) if ranks else 0
            if high_card >= 11:  # J or better
                potential = max(potential, 0.3)

        return potential

    def _analyze_position(self, current_player: str, players: Dict, dealer_index: int) -> str:
        """Determine player position (early, middle, late, button)"""
        active_players = [pid for pid, pinfo in players.items()
                         if pinfo.get('state') == 'active']

        if current_player not in active_players:
            return 'unknown'

        player_count = len(active_players)
        current_index = active_players.index(current_player)

        # Button is last to act
        if current_index == player_count - 1:
            return 'button'

        # Determine position based on player count
        if player_count <= 3:
            return 'late' if current_index > 0 else 'early'
        elif player_count <= 6:
            third = player_count // 3
            if current_index < third:
                return 'early'
            elif current_index < 2 * third:
                return 'middle'
            else:
                return 'late'
        else:
            if current_index < 2:
                return 'early'
            elif current_index < player_count - 3:
                return 'middle'
            else:
                return 'late'

    def _calculate_pot_odds(self, pot_size: int, bet_to_call: int) -> float:
        """Calculate pot odds"""
        if bet_to_call <= 0:
            return float('inf')
        return pot_size / bet_to_call

    def _get_raise_action(
        self,
        raise_action: Dict,
        pot: int,
        current_bet: int,
        my_chips: int,
        raise_type: str,
        multiplier: float = 1.0
    ) -> Dict[str, Any]:
        """
        Get a valid raise action from the available raise action

        Args:
            raise_action: The raise action dict from valid_actions
            pot: Current pot size
            current_bet: Current bet amount
            my_chips: Available chips
            raise_type: Type of raise for calculation
            multiplier: Size multiplier

        Returns:
            Valid raise action with proper amount
        """
        # If the action already has an amount specified, use it
        if 'amount' in raise_action and raise_action['amount'] > 0:
            return raise_action

        # Otherwise calculate based on min/max
        min_amount = raise_action.get('min_amount', current_bet * 2)
        max_amount = raise_action.get('max_amount', my_chips)

        # Calculate desired raise amount
        desired_amount = self._calculate_raise_amount(pot, current_bet, my_chips, raise_type, multiplier)

        # Clamp to valid range
        final_amount = max(min_amount, min(desired_amount, max_amount))

        return {"action": "raise", "amount": int(final_amount)}

    def _calculate_raise_amount(
        self,
        pot: int,
        current_bet: int,
        my_chips: int,
        raise_type: str,
        multiplier: float = 1.0
    ) -> int:
        """
        Calculate raise amount based on situation

        Args:
            pot: Current pot size
            current_bet: Current bet to match
            my_chips: Available chips
            raise_type: Type of raise ('value', 'bluff', 'steal', 'cbet', 'open')
            multiplier: Size multiplier
        """
        # Base raise amounts
        if raise_type == 'open':
            # Opening raise pre-flop (2.5-3x BB)
            base_raise = max(current_bet * 2, pot * 0.5)
        elif raise_type == 'value':
            # Value bet (50-80% pot)
            base_raise = int(pot * 0.65 * multiplier)
        elif raise_type == 'bluff':
            # Bluff (40-60% pot)
            base_raise = int(pot * 0.5 * multiplier)
        elif raise_type == 'steal':
            # Steal attempt (2-2.5x BB)
            base_raise = max(current_bet * 2, pot * 0.4)
        elif raise_type == 'cbet':
            # Continuation bet (50-70% pot)
            base_raise = int(pot * 0.6 * multiplier)
        else:
            base_raise = int(pot * 0.6)

        # Ensure minimum raise (at least 2x current bet)
        min_raise = current_bet * 2
        raise_amount = max(base_raise, min_raise)

        # Cap at available chips
        raise_amount = min(raise_amount, my_chips + current_bet)

        # Ensure it's at least current_bet + min_raise
        if raise_amount < current_bet * 2:
            raise_amount = min(current_bet * 2, my_chips + current_bet)

        return int(raise_amount)

    def _parse_card(self, card: str) -> Tuple[str, str]:
        """Parse card string into rank and suit"""
        if len(card) == 2:
            return card[0], card[1]
        elif len(card) == 3 and card[:2] == '10':
            return '10', card[2]
        else:
            return card[:-1], card[-1]

    def _safe_action(self, actions: List, preferred: str = 'fold') -> Dict[str, Any]:
        """Return a safe action when errors occur"""
        if isinstance(actions, list):
            for action in actions:
                if isinstance(action, dict) and action.get('action') == preferred:
                    return action
            # Return first available action
            if actions:
                return actions[0] if isinstance(actions[0], dict) else {"action": "fold"}

        return {"action": "fold"}

    def reset(self):
        """Reset AI state for a new game"""
        self.opponent_stats.clear()
        self.hand_history.clear()
        self.current_hand_actions.clear()
        self.hand_count = 0
        logger.info(f"AI {self.name} reset")


# ============================================================================
# Testing Code
# ============================================================================
if __name__ == "__main__":
    # Create AI instance
    ai = Sonnet_4_5_AI()

    # Test AI info
    print("="*70)
    print("AI Information:")
    print("="*70)
    info = ai.get_info()
    for key, value in info.items():
        print(f"{key}: {value}")

    # Test decision making with sample game state
    print("\n" + "="*70)
    print("Testing Decision Making:")
    print("="*70)

    test_states = [
        {
            'name': 'Pre-flop with premium hand (AA)',
            'state': {
                'valid_actions': [
                    {'action': 'fold'},
                    {'action': 'call', 'amount': 20},
                    {'action': 'raise', 'min_amount': 40, 'max_amount': 500}
                ],
                'players': {
                    'player1': {
                        'hole_cards': ['As', 'Ah'],
                        'chips': 1000,
                        'current_bet': 10,
                        'state': 'active'
                    },
                    'player2': {
                        'chips': 1000,
                        'current_bet': 20,
                        'state': 'active'
                    }
                },
                'current_player': 'player1',
                'community_cards': [],
                'pot': 30,
                'current_bet': 20,
                'phase': 'preflop',
                'dealer_index': 0
            }
        },
        {
            'name': 'Flop with top pair',
            'state': {
                'valid_actions': [
                    {'action': 'fold'},
                    {'action': 'check'},
                    {'action': 'raise', 'min_amount': 20, 'max_amount': 500}
                ],
                'players': {
                    'player1': {
                        'hole_cards': ['Ah', 'Kd'],
                        'chips': 950,
                        'current_bet': 0,
                        'state': 'active'
                    },
                    'player2': {
                        'chips': 950,
                        'current_bet': 0,
                        'state': 'active'
                    }
                },
                'current_player': 'player1',
                'community_cards': ['Ad', '8c', '3h'],
                'pot': 100,
                'current_bet': 0,
                'phase': 'flop',
                'dealer_index': 1
            }
        }
    ]

    for test in test_states:
        print(f"\nTest: {test['name']}")
        print(f"Hand: {test['state']['players']['player1']['hole_cards']}")
        print(f"Community: {test['state'].get('community_cards', [])}")
        decision = ai.make_move(test['state'])
        print(f"Decision: {decision}")

    print("\n" + "="*70)
    print("AI Testing Complete")
    print("="*70)
