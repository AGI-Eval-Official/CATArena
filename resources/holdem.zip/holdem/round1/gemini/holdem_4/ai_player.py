import random
from itertools import combinations

class GeminiHoldemAI:
    def __init__(self):
        self.ai_id = "Gemini_4"
        self.name = "Gemini Holdem AI 4"
        self.version = "1.0.0"
        self.description = "A strategic holdem AI using Monte Carlo simulation and a simplified CFR approach."
        self.simulations = 500

    def get_info(self):
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
        }

    def make_move(self, game_state):
        
        actions = self._get_abstract_actions(game_state)
        
        action_evs = {action: 0 for action in actions}

        for action in actions:
            action_evs[action] = self._calculate_action_ev(game_state, action)

        best_action = max(action_evs, key=action_evs.get)

        return self._get_game_action(game_state, best_action)


    def _calculate_action_ev(self, game_state, action):
        
        if action == "fold":
            return 0
        
        if action == "check":
            return self._monte_carlo_simulation(game_state) * game_state['pot']

        win_prob = self._monte_carlo_simulation(game_state)
        
        pot_size = game_state['pot']
        bet_to_call = 0
        
        valid_actions = game_state['valid_actions']
        can_call = any(a['action'] == 'call' for a in valid_actions)
        if can_call:
            bet_to_call = [a for a in valid_actions if a['action'] == 'call'][0].get('amount', 0)

        if action == "call":
            return (win_prob * (pot_size + bet_to_call)) - bet_to_call
        
        if action == "raise":
            min_raise = [a for a in valid_actions if a['action'] == 'raise'][0]['min_amount']
            # Assume opponent calls with a probability of 50%
            opponent_call_prob = 0.5
            
            ev_if_called = (win_prob * (pot_size + min_raise)) - min_raise
            ev_if_folded = pot_size
            
            return (opponent_call_prob * ev_if_called) + ((1 - opponent_call_prob) * ev_if_folded)

        return 0

    def _get_abstract_actions(self, game_state):
        actions = ["fold"]
        valid_actions = game_state['valid_actions']
        if any(a['action'] == 'call' for a in valid_actions):
            actions.append("call")
        if any(a['action'] == 'raise' for a in valid_actions):
            actions.append("raise")
        if any(a['action'] == 'check' for a in valid_actions):
            actions.append("check")
        return actions

    def _get_game_action(self, game_state, abstract_action):
        valid_actions = game_state['valid_actions']
        if abstract_action == "fold":
            return {"action": "fold"}
        if abstract_action == "check":
            return {"action": "check"}
        if abstract_action == "call":
            return {"action": "call"}
        if abstract_action == "raise":
            min_raise = [a for a in valid_actions if a['action'] == 'raise'][0]['min_amount']
            return {"action": "raise", "amount": min_raise}
        return {"action": "fold"}


    def _monte_carlo_simulation(self, game_state):
        my_hand = game_state['players'][game_state['current_player']]['hole_cards']
        community_cards = game_state['community_cards']
        
        deck = self._get_deck(my_hand + community_cards)
        
        wins = 0
        for _ in range(self.simulations):
            
            remaining_community = 5 - len(community_cards)
            sim_community = community_cards + random.sample(deck, remaining_community)
            
            # Assume one opponent
            opponent_hand = random.sample(deck, 2)
            
            my_best_hand = self._get_best_hand(my_hand + sim_community)
            opponent_best_hand = self._get_best_hand(opponent_hand + sim_community)

            if self._compare_hands(my_best_hand, opponent_best_hand) >= 0:
                wins += 1
        
        return wins / self.simulations

    def _get_deck(self, excluded_cards):
        ranks = '23456789TJQKA'
        suits = 'shdc'
        deck = [r + s for r in ranks for s in suits]
        for card in excluded_cards:
            if card in deck:
                deck.remove(card)
        return deck

    def _get_best_hand(self, all_cards):
        best_hand_val = -1
        best_hand = None
        for hand_cards in combinations(all_cards, 5):
            hand_val = self._evaluate_hand(hand_cards)
            if hand_val > best_hand_val:
                best_hand_val = hand_val
                best_hand = hand_cards
        return best_hand

    def _evaluate_hand(self, hand):
        ranks = sorted(['--23456789TJQKA'.index(r) for r, s in hand], reverse=True)
        suits = [s for r, s in hand]
        is_flush = len(set(suits)) == 1
        is_straight = all(ranks[i] == ranks[i+1] + 1 for i in range(4)) or (ranks[0]==14 and ranks[1]==5 and all(ranks[i] == ranks[i+1] + 1 for i in range(1,4)))


        if is_straight and is_flush: return 8
        if ranks.count(ranks[0]) == 4 or ranks.count(ranks[1]) == 4: return 7
        if (ranks.count(ranks[0]) == 3 and ranks.count(ranks[3]) == 2) or \
           (ranks.count(ranks[0]) == 2 and ranks.count(ranks[2]) == 3): return 6
        if is_flush: return 5
        if is_straight: return 4
        if ranks.count(ranks[0]) == 3 or ranks.count(ranks[1]) == 3 or ranks.count(ranks[2]) == 3: return 3
        
        pairs = 0
        for r in set(ranks):
            if ranks.count(r) == 2:
                pairs += 1
        if pairs >= 2: return 2
        if pairs == 1: return 1
        return 0

    def _compare_hands(self, hand1, hand2):
        val1 = self._evaluate_hand(hand1)
        val2 = self._evaluate_hand(hand2)
        if val1 > val2: return 1
        if val1 < val2: return -1
        
        # Tie-breaker
        ranks1 = sorted(['--23456789TJQKA'.index(r) for r, s in hand1], reverse=True)
        ranks2 = sorted(['--23456789TJQKA'.index(r) for r, s in hand2], reverse=True)
        for r1, r2 in zip(ranks1, ranks2):
            if r1 > r2: return 1
            if r1 < r2: return -1
        return 0

if __name__ == '__main__':
    ai = GeminiHoldemAI()
    print("AI initialized")