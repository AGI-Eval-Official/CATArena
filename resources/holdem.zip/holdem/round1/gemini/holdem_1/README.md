# 德州扑克AI开发模版 - Traditional模式

这是一个完整的德州扑克AI开发模版，适用于Traditional模式。本模版提供了所有必需的文件和详细的开发指南，让AI大模型能够快速理解并仿写出自己的AI选手。

## 📁 文件结构

```
traditional/
├── ai_config.yaml    # AI配置文件
├── ai_player.py      # AI实现文件
└── README.md         # 说明文档（本文件）
```

## 🎯 快速开始

### 1. 修改配置文件

编辑 `ai_config.yaml`，修改以下必需字段：

```yaml
ai_id: your_unique_ai_id          # 必须唯一，建议格式：作者名_ai名_版本
ai_name: "Your AI Name"           # AI显示名称
author: "Your Name"               # 作者名称
description: "Your AI description" # AI描述
```

### 2. 实现AI逻辑

编辑 `ai_player.py`，修改类名和实现你的策略：

```python
class YourAIName:  # 修改类名
    def __init__(self):
        self.ai_id = "your_unique_ai_id"  # 与配置文件保持一致
        # ... 其他初始化代码
```

### 3. 测试AI

运行测试代码验证AI是否正常工作：

```bash
cd /path/to/your/ai/directory
python ai_player.py
```

## 📋 必需实现的方法

### 1. `__init__(self)`
- **作用**: 初始化AI，设置基本信息和策略参数
- **必需设置**: `ai_id`, `name`, `version`, `description`
- **示例**:
```python
def __init__(self):
    self.ai_id = "my_ai"
    self.name = "My AI"
    self.version = "1.0"
    self.description = "My poker AI"
```

### 2. `get_info(self) -> Dict[str, Any]`
- **作用**: 返回AI基本信息
- **必需返回字段**: `ai_id`, `name`, `version`, `description`
- **可选返回字段**: `capabilities`
- **示例**:
```python
def get_info(self):
    return {
        "ai_id": self.ai_id,
        "name": self.name,
        "version": self.version,
        "description": self.description,
        "capabilities": ["hand_evaluation", "decision_making"]
    }
```

### 3. `make_move(self, game_state: Dict) -> Dict[str, Any]`
- **作用**: 核心决策方法，根据游戏状态做出决策
- **输入参数**: `game_state` - 包含游戏状态的字典
- **返回格式**: `{"action": "行动类型", "amount": 金额}`
- **可能的行动**: `fold`, `check`, `call`, `raise`, `all_in`

## 🎮 游戏状态格式

`make_move` 方法接收的 `game_state` 包含以下信息：

```python
game_state = {
    # 可执行的行动列表
    "valid_actions": [
        {"action": "fold"},
        {"action": "call", "amount": 20},
        {"action": "raise", "min_amount": 40, "max_amount": 200}
    ],
    
    # 玩家信息
    "players": {
        "player1": {
            "hole_cards": ["As", "Kh"],      # 手牌
            "chips": 1000,                   # 剩余筹码
            "current_bet": 10,               # 当前下注额
            "state": "active"                # 玩家状态
        }
    },
    
    "current_player": "player1",             # 当前玩家ID
    "community_cards": ["Qd", "Jc", "10s"], # 公共牌
    "pot": 100,                              # 底池大小
    "current_bet": 20,                       # 当前最高下注额
    "phase": "flop",                         # 游戏阶段
    "dealer_index": 0                        # 庄家位置
}
```

## 🃏 牌面表示格式

牌面使用字符串表示，格式为：`牌面值 + 花色`

### 牌面值
- 数字牌: `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `10`
- 人头牌: `J`, `Q`, `K`, `A`

### 花色
- 黑桃: `s` (spades)
- 红心: `h` (hearts)  
- 方块: `d` (diamonds)
- 梅花: `c` (clubs)

### 示例
- `As` = 黑桃A
- `Kh` = 红心K
- `10d` = 方块10
- `2c` = 梅花2

## 🎯 决策返回格式

`make_move` 方法必须返回以下格式的字典：

### 弃牌
```python
{"action": "fold"}
```

### 过牌
```python
{"action": "check"}
```

### 跟注
```python
{"action": "call"}
```

### 加注
```python
{"action": "raise", "amount": 100}  # amount为总下注额
```

### 全押
```python
{"action": "all_in"}
```

## ⚙️ 配置文件详解

### 必需配置项

```yaml
# 基本信息
ai_id: unique_identifier        # 必须唯一
ai_name: "Display Name"         # 显示名称
version: "1.0"                  # 版本号
description: "AI description"   # 描述
mode: traditional              # 固定为traditional
author: "Author Name"          # 作者
difficulty: intermediate       # 难度等级

# AI能力
capabilities:
  - hand_evaluation            # 手牌评估
  - decision_making           # 决策制定
```

### 可选配置项

```yaml
# 策略参数
strategy:
  aggression_level: 0.6        # 激进程度 (0.0-1.0)
  bluff_frequency: 0.15        # 虚张声势频率
  position_awareness: true     # 位置感知

# 性能参数  
performance:
  thinking_time_min: 0.5       # 最小思考时间
  thinking_time_max: 3.0       # 最大思考时间
  memory_enabled: true         # 记忆功能

# 游戏设置
game_settings:
  starting_chips: 1000         # 起始筹码
  min_bet: 10                  # 最小下注
```

## 🧠 AI策略开发指南

### 1. 手牌评估策略

实现 `evaluate_hand_strength` 方法来评估手牌强度：

```python
def evaluate_hand_strength(self, hole_cards, community_cards):
    # 返回0.0-1.0之间的值
    # 1.0表示最强手牌，0.0表示最弱手牌
    pass
```

### 2. 位置感知策略

利用 `analyze_position` 方法分析位置优势：

```python
def analyze_position(self, current_player, players, dealer_index):
    # 返回 'early', 'middle', 'late'
    # 晚期位置通常更有优势
    pass
```

### 3. 底池赔率计算

使用 `calculate_pot_odds` 方法计算是否值得跟注：

```python
def calculate_pot_odds(self, pot_size, bet_to_call):
    # 返回底池赔率
    # 赔率越高，跟注越划算
    return pot_size / bet_to_call if bet_to_call > 0 else float('inf')
```

## 重要注意事项

1. **配置一致性**：确保 `ai_config.yaml` 和 `ai_player.py` 中的信息一致
2. **错误处理**：必须处理各种异常情况，避免AI崩溃
3. **性能考虑**：Variant模式应保持快速响应
4. **测试充分**：在各种游戏状态下测试AI行为
5. **日志记录**：适当的日志有助于调试和优化

## 部署说明

1. **文件完整性**：确保所有必需文件都存在
2. **依赖检查**：确认Python环境和依赖库
3. **权限设置**：确保文件有适当的读写权限
4. **配置验证**：部署前验证配置文件格式

## 技术支持

如果在开发过程中遇到问题：

1. 检查日志输出
2. 验证配置文件格式
3. 测试基本功能
4. 参考现有AI实现
5. 查看游戏引擎文档

