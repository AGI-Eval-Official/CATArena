import random
import math
import logging
from typing import Dict, List, Any, Tuple, Optional
from collections import defaultdict
from itertools import combinations

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('gemini_ai')


class GeminiAI:
    """
    德州扑克AI - Traditional模式模版
    
    这个类实现了一个完整的德州扑克AI，包含以下核心功能：
    1. 手牌评估和强度计算
    2. 决策制定逻辑
    3. 位置分析
    4. 对手建模（可选）
    5. 底池赔率计算
    
    必须实现的方法：
    - __init__(): 初始化AI
    - get_info(): 返回AI信息
    - make_move(): 核心决策方法
    - reset(): 重置AI状态（可选）
    """
    
    def __init__(self):
        """
        初始化AI
        
        在这里设置AI的基本信息和初始状态。
        这些信息应该与ai_config.yaml中的配置保持一致。
        """
        # ====================================================================
        # 基本信息 (必需) - 与ai_config.yaml保持一致
        # ====================================================================
        self.ai_id = "Gemini_3"
        self.name = "Gemini AI"
        self.version = "1.0.0"
        self.description = "A strategic Texas Hold'em AI."
        
        # ====================================================================
        # 策略参数 (可根据需要调整)
        # ====================================================================
        self.aggression_level = 0.6      # 激进程度 (0.0-1.0)
        self.bluff_frequency = 0.15      # 虚张声势频率 (0.0-1.0)
        self.position_awareness = True   # 是否考虑位置
        self.tight_aggressive = True     # 是否采用紧凶策略
        
        # ====================================================================
        # 游戏状态追踪 (可选，用于高级策略)
        # ====================================================================
        self.opponent_stats = defaultdict(lambda: {
            'hands_played': 0,
            'vpip': 0,  # Voluntarily Put money In Pot
            'pfr': 0,   # Pre-Flop Raise
            'aggression': 0,
            'fold_to_bet': 0,
            'recent_actions': []
        })
        self.hand_history = []
        self.current_hand_actions = []
        
        logger.info(f"AI {self.name} initialized successfully")
    
    def get_info(self) -> Dict[str, Any]:
        """
        获取AI信息 (必需方法)
        
        返回AI的基本信息，用于游戏引擎识别和显示。
        
        Returns:
            Dict: 包含AI信息的字典，必须包含以下字段：
                - ai_id: AI唯一标识符
                - name: AI显示名称
                - version: AI版本
                - description: AI描述
                - capabilities: AI能力列表 (可选)
        """
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "capabilities": [
                "hand_evaluation",
                "decision_making", 
                "position_awareness",
                "pot_odds_calculation"
            ]
        }
    
    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        核心决策方法 (必需方法)
        
        根据当前游戏状态做出决策。这是AI的核心方法，必须实现。
        
        Args:
            game_state (Dict): 游戏状态信息，包含以下字段：
                - valid_actions (List): 可执行的行动列表
                - players (Dict): 玩家信息
                - current_player (str): 当前玩家ID
                - community_cards (List): 公共牌
                - pot (int): 底池大小
                - current_bet (int): 当前下注额
                - phase (str): 游戏阶段 ('preflop', 'flop', 'turn', 'river')
                - dealer_index (int): 庄家位置
                
        Returns:
            Dict: 决策结果，必须包含以下字段：
                - action (str): 行动类型 ('fold', 'check', 'call', 'raise', 'all_in')
                - amount (int): 下注金额 (仅在raise时需要)
                
        示例返回值：
            {"action": "raise", "amount": 100}
            {"action": "call"}
            {"action": "fold"}
        """
        try:
            # ================================================================
            # 1. 验证输入和获取基本信息
            # ================================================================
            valid_actions = game_state.get('valid_actions', [])
            if not valid_actions:
                logger.warning("No valid actions available, folding")
                return {"action": "fold", "amount": 0}
            
            # 获取当前玩家信息
            current_player = game_state.get('current_player')
            players = game_state.get('players', {})
            
            if current_player not in players:
                logger.error(f"Current player {current_player} not found in players")
                return self._safe_fold(valid_actions)
            
            player_info = players[current_player]
            hole_cards = player_info.get('hole_cards', [])
            my_chips = player_info.get('chips', 0)
            my_current_bet = player_info.get('current_bet', 0)
            
            # 获取游戏信息
            community_cards = game_state.get('community_cards', [])
            pot = game_state.get('pot', 0)
            current_bet = game_state.get('current_bet', 0)
            phase = game_state.get('phase', 'preflop')
            dealer_index = game_state.get('dealer_index', 0)
            
            # ================================================================
            # 2. 分析可用行动
            # ================================================================
            available_actions = self._parse_valid_actions(valid_actions)
            
            # ================================================================
            # 3. 手牌评估
            # ================================================================
            hand_strength = self.evaluate_hand_strength(hole_cards, community_cards)
            
            # ================================================================
            # 4. 位置分析
            # ================================================================
            position = self.analyze_position(current_player, players, dealer_index)
            
            # ================================================================
            # 5. 底池赔率计算
            # ================================================================
            bet_to_call = current_bet - my_current_bet
            pot_odds = self.calculate_pot_odds(pot, bet_to_call) if bet_to_call > 0 else float('inf')
            
            # ================================================================
            # 6. 决策逻辑
            # ================================================================
            decision = self._make_decision(
                hand_strength=hand_strength,
                position=position,
                pot_odds=pot_odds,
                available_actions=available_actions,
                game_state=game_state
            )
            
            logger.info(f"Decision: {decision}, Hand: {hole_cards}, Strength: {hand_strength:.3f}, Position: {position}")
            return decision
            
        except Exception as e:
            logger.error(f"Error in make_move: {e}")
            return self._safe_fold(valid_actions)
    
    def _parse_valid_actions(self, valid_actions: List[Dict]) -> Dict[str, Optional[Dict]]:
        """
        解析可用行动
        
        Args:
            valid_actions: 可用行动列表
            
        Returns:
            Dict: 解析后的行动字典
        """
        actions = {
            'fold': None,
            'check': None,
            'call': None,
            'raise': None,
            'all_in': None
        }
        
        for action in valid_actions:
            action_type = action.get('action')
            if action_type in actions:
                actions[action_type] = action
                
        return actions
    
    def _make_decision(self, hand_strength: float, position: str, pot_odds: float, 
                      available_actions: Dict, game_state: Dict) -> Dict[str, Any]:
        """
        核心决策逻辑
        
        根据手牌强度、位置、底池赔率等因素做出决策。
        这里实现了一个基础的紧凶策略，你可以根据需要修改。
        
        Args:
            hand_strength: 手牌强度 (0.0-1.0)
            position: 位置 ('early', 'middle', 'late')
            pot_odds: 底池赔率
            available_actions: 可用行动
            game_state: 游戏状态
            
        Returns:
            Dict: 决策结果
        """
        # ================================================================
        # 决策阈值 (可根据策略调整)
        # ================================================================
        VERY_STRONG_THRESHOLD = 0.8    # 非常强的手牌
        STRONG_THRESHOLD = 0.6         # 强手牌
        PLAYABLE_THRESHOLD = 0.4       # 可玩手牌
        WEAK_THRESHOLD = 0.2           # 弱手牌
        
        # ================================================================
        # 位置调整因子
        # ================================================================
        position_factor = {
            'early': 0.9,    # 早期位置更保守
            'middle': 1.0,   # 中期位置正常
            'late': 1.1      # 晚期位置更激进
        }.get(position, 1.0)
        
        adjusted_strength = hand_strength * position_factor

        # Check for draws
        all_cards = game_state['players'][game_state['current_player']]['hole_cards'] + game_state['community_cards']
        flush_draw, straight_draw = self._check_draws(all_cards)
        has_strong_draw = flush_draw or straight_draw

        # Opponent modeling placeholder
        opponent_factor = random.uniform(0.9, 1.1)
        adjusted_strength *= opponent_factor
        
        # ================================================================
        # 决策逻辑
        # ================================================================
        
        # 非常强的手牌 - 总是激进
        if adjusted_strength >= VERY_STRONG_THRESHOLD:
            if available_actions['raise']:
                amount = self._calculate_raise_amount(game_state, 'value_bet', hand_strength)
                return {"action": "raise", "amount": amount}
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        # 强手牌 - 为价值下注
        elif adjusted_strength >= STRONG_THRESHOLD:
            if available_actions['raise'] and (position == 'late' or pot_odds < 3):
                amount = self._calculate_raise_amount(game_state, 'value_bet', hand_strength)
                return {"action": "raise", "amount": amount}
            elif available_actions['call'] and pot_odds > 2:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        # 可玩手牌 - 根据情况决定
        elif adjusted_strength >= PLAYABLE_THRESHOLD or has_strong_draw:
            if has_strong_draw and available_actions['call'] and pot_odds > 4: # Semi-bluff with draws
                return available_actions['call']
            if available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 3:
                return available_actions['call']
            elif position == 'late' and self._should_bluff() and available_actions['raise']:
                amount = self._calculate_raise_amount(game_state, 'bluff', hand_strength)
                return {"action": "raise", "amount": amount}
        
        # 弱手牌 - 大多数情况下弃牌
        else:
            if available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 6:
                return available_actions['call']
        
        # 默认弃牌
        if available_actions['fold']:
            return available_actions['fold']
        
        # 后备选择
        return list(available_actions.values())[0] if available_actions else {"action": "fold"}
    
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        评估手牌强度
        
        这是AI的核心方法之一，用于评估当前手牌的强度。
        返回值在0.0到1.0之间，1.0表示最强手牌。
        
        Args:
            hole_cards: 手牌 (例如: ['As', 'Kh'])
            community_cards: 公共牌 (例如: ['Qd', 'Jc', '10s'])
            
        Returns:
            float: 手牌强度 (0.0-1.0)
        """
        if len(community_cards) == 0:
            # 翻牌前手牌强度评估
            return self._evaluate_preflop_strength(hole_cards)
        else:
            # 翻牌后手牌强度评估
            all_cards = hole_cards + community_cards
            return self._evaluate_postflop_strength(all_cards)
    
    def _evaluate_preflop_strength(self, hole_cards: List[str]) -> float:
        """
        评估翻牌前手牌强度
        
        Args:
            hole_cards: 手牌
            
        Returns:
            float: 手牌强度
        """
        if len(hole_cards) != 2:
            return 0.0
        
        card1, card2 = hole_cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # 转换牌面值为数字 (A=14, K=13, Q=12, J=11)
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(rank1, 0)
        val2 = rank_values.get(rank2, 0)
        
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        is_suited = (suit1 == suit2)
        is_pair = (val1 == val2)
        
        # 基础强度计算
        if is_pair:
            # 对子
            if high_card >= 13:  # AA, KK, QQ
                return 0.9 + (high_card - 13) * 0.03
            elif high_card >= 10:  # JJ, 10-10
                return 0.75 + (high_card - 10) * 0.05
            else:  # 小对子
                return 0.4 + (high_card - 2) * 0.04
        else:
            # 非对子
            base_strength = (high_card + low_card) / 28.0  # 标准化到0-1
            
            # 同花加成
            if is_suited:
                base_strength += 0.1
            
            # 连牌加成
            if abs(val1 - val2) == 1:
                base_strength += 0.05
            elif abs(val1 - val2) <= 3:
                base_strength += 0.02
            
            # 高牌加成
            if high_card == 14:  # A
                base_strength += 0.1
            elif high_card >= 12:  # K, Q
                base_strength += 0.05
            
            return min(base_strength, 0.95)
    
    def _evaluate_postflop_strength(self, all_cards: List[str]) -> float:
        """
        评估翻牌后手牌强度
        
        这里实现了一个简化的手牌强度评估。
        在实际应用中，你可能需要更复杂的算法。
        
        Args:
            all_cards: 所有可用牌 (手牌 + 公共牌)
            
        Returns:
            float: 手牌强度
        """
        # 简化实现：基于牌型强度
        hand_rank, _ = self._get_hand_rank(all_cards)
        
        # 手牌排名到强度的映射
        rank_to_strength = {
            'royal_flush': 1.0,
            'straight_flush': 0.95,
            'four_of_a_kind': 0.9,
            'full_house': 0.85,
            'flush': 0.75,
            'straight': 0.65,
            'three_of_a_kind': 0.55,
            'two_pair': 0.45,
            'one_pair': 0.35,
            'high_card': 0.2
        }
        
        strength = rank_to_strength.get(hand_rank, 0.2)

        # Check for draws
        flush_draw, straight_draw = self._check_draws(all_cards)
        if flush_draw:
            strength += 0.1
        if straight_draw:
            strength += 0.1
            
        return min(strength, 1.0)

    def _check_draws(self, all_cards: List[str]) -> Tuple[bool, bool]:
        """
        Check for flush and straight draws.
        """
        if not all_cards:
            return False, False

        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        parsed_cards = []
        for card in all_cards:
            rank, suit = self._parse_card(card)
            parsed_cards.append((rank_map[rank], suit))

        # Flush draw
        suit_counts = defaultdict(int)
        for _, suit in parsed_cards:
            suit_counts[suit] += 1
        flush_draw = any(count == 4 for count in suit_counts.values())

        # Straight draw
        ranks = sorted(list(set(c[0] for c in parsed_cards)))
        straight_draw = False
        if len(ranks) >= 4:
            for i in range(len(ranks) - 3):
                if ranks[i+3] - ranks[i] == 3:
                    straight_draw = True
                    break
            # Check for A-2-3-4
            if not straight_draw and set(ranks).issuperset({14, 2, 3, 4}):
                straight_draw = True
        
        return flush_draw, straight_draw
    
    def _get_hand_rank(self, cards: List[str]) -> Tuple[str, List[int]]:
        """
        获取手牌排名
        
        这是一个简化的实现，仅用于演示。
        实际应用中需要更精确的手牌评估算法。
        
        Args:
            cards: 牌列表
            
        Returns:
            str: 手牌排名
        """
        if not cards:
            return 'high_card', []

        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        suit_map = {'s': 0, 'h': 1, 'd': 2, 'c': 3}
        
        parsed_cards = []
        for card in cards:
            rank, suit = self._parse_card(card)
            parsed_cards.append((rank_map[rank], suit_map[suit]))

        best_rank = 'high_card'
        best_hand_ranks = []

        for hand_combination in combinations(parsed_cards, 5):
            ranks = sorted([c[0] for c in hand_combination], reverse=True)
            suits = [c[1] for c in hand_combination]
            
            is_flush = len(set(suits)) == 1
            
            rank_counts = defaultdict(int)
            for r in ranks:
                rank_counts[r] += 1
            
            sorted_counts = sorted(rank_counts.items(), key=lambda item: (item[1], item[0]), reverse=True)
            
            is_straight = False
            if len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4):
                is_straight = True
            # Ace-low straight
            if set(ranks) == {14, 2, 3, 4, 5}:
                is_straight = True
                ranks = [5, 4, 3, 2, 1]

            hand_rank = 'high_card'
            hand_ranks = ranks

            if is_straight and is_flush:
                if ranks[0] == 14:
                    hand_rank = 'royal_flush'
                else:
                    hand_rank = 'straight_flush'
            elif sorted_counts[0][1] == 4:
                hand_rank = 'four_of_a_kind'
                hand_ranks = [sorted_counts[0][0]] * 4 + [sorted_counts[1][0]]
            elif sorted_counts[0][1] == 3 and sorted_counts[1][1] == 2:
                hand_rank = 'full_house'
                hand_ranks = [sorted_counts[0][0]] * 3 + [sorted_counts[1][0]] * 2
            elif is_flush:
                hand_rank = 'flush'
            elif is_straight:
                hand_rank = 'straight'
            elif sorted_counts[0][1] == 3:
                hand_rank = 'three_of_a_kind'
                hand_ranks = [sorted_counts[0][0]] * 3 + [r for r in ranks if r != sorted_counts[0][0]]
            elif sorted_counts[0][1] == 2 and sorted_counts[1][1] == 2:
                hand_rank = 'two_pair'
                pairs = [sorted_counts[0][0], sorted_counts[1][0]]
                hand_ranks = [pairs[0]]*2 + [pairs[1]]*2 + [r for r in ranks if r not in pairs]
            elif sorted_counts[0][1] == 2:
                hand_rank = 'one_pair'
                pair = sorted_counts[0][0]
                hand_ranks = [pair]*2 + [r for r in ranks if r != pair]

            rank_order = ['royal_flush', 'straight_flush', 'four_of_a_kind', 'full_house', 'flush', 'straight', 'three_of_a_kind', 'two_pair', 'one_pair', 'high_card']
            
            if rank_order.index(hand_rank) < rank_order.index(best_rank):
                best_rank = hand_rank
                best_hand_ranks = hand_ranks
            elif hand_rank == best_rank:
                if best_hand_ranks:
                    for i in range(len(hand_ranks)):
                        if hand_ranks[i] > best_hand_ranks[i]:
                            best_hand_ranks = hand_ranks
                            break
                        elif hand_ranks[i] < best_hand_ranks[i]:
                            break
                else:
                    best_hand_ranks = hand_ranks


        return best_rank, best_hand_ranks

    def analyze_position(self, current_player: str, players: Dict, dealer_index: int) -> str:
        """
        分析玩家位置
        
        位置是德州扑克中的重要因素，影响决策策略。
        
        Args:
            current_player: 当前玩家ID
            players: 所有玩家信息
            dealer_index: 庄家位置
            
        Returns:
            str: 位置类型 ('early', 'middle', 'late')
        """
        active_players = [pid for pid, pinfo in players.items() 
                         if pinfo.get('state') == 'active']
        
        if current_player not in active_players:
            return 'unknown'
        
        player_count = len(active_players)
        current_index = active_players.index(current_player)
        
        # 根据玩家数量和位置确定早中晚期
        if player_count <= 3:
            return 'late' if current_index == player_count - 1 else 'early'
        elif player_count <= 6:
            if current_index < player_count // 3:
                return 'early'
            elif current_index < 2 * player_count // 3:
                return 'middle'
            else:
                return 'late'
        else:
            if current_index < 2:
                return 'early'
            elif current_index < player_count - 2:
                return 'middle'
            else:
                return 'late'
    
    def calculate_pot_odds(self, pot_size: int, bet_to_call: int) -> float:
        """
        计算底池赔率
        
        底池赔率 = 底池大小 / 需要跟注的金额
        
        Args:
            pot_size: 底池大小
            bet_to_call: 需要跟注的金额
            
        Returns:
            float: 底池赔率
        """
        if bet_to_call <= 0:
            return float('inf')
        return pot_size / bet_to_call
    
    def _calculate_raise_amount(self, game_state: Dict, raise_type: str, hand_strength: float) -> int:
        """
        计算加注金额
        
        Args:
            game_state: 游戏状态
            raise_type: 加注类型 ('value_bet', 'bluff', 'protection')
            
        Returns:
            int: 加注金额
        """
        pot = game_state.get('pot', 0)
        current_bet = game_state.get('current_bet', 0)
        
        # 根据加注类型确定倍数
        if raise_type == 'value_bet':
            multiplier = 0.5 + (hand_strength - 0.6) * 2 # 0.5 to 1.0
        elif raise_type == 'bluff':
            multiplier = 0.4 + random.uniform(-0.1, 0.1) # 0.3 to 0.5
        else: # protection
            multiplier = 0.6 + (hand_strength - 0.6) * 1.5 # 0.6 to 0.9
        
        raise_amount = int(pot * multiplier)
        
        # 确保加注金额合理
        min_raise = current_bet * 2
        max_raise = pot * 2
        
        return max(min_raise, min(raise_amount, max_raise))
    
    def _should_bluff(self) -> bool:
        """
        判断是否应该虚张声势
        
        Returns:
            bool: 是否应该虚张声势
        """
        return random.random() < self.bluff_frequency
    
    def _parse_card(self, card: str) -> Tuple[str, str]:
        """
        解析牌面
        
        Args:
            card: 牌面字符串 (例如: 'As', 'Kh', '10d')
            
        Returns:
            Tuple[str, str]: (牌面值, 花色)
        """
        if len(card) == 2:
            return card[0], card[1]
        elif len(card) == 3 and card[:2] == '10':
            return '10', card[2]
        else:
            return card[:-1], card[-1]
    
    def _safe_fold(self, valid_actions: List[Dict]) -> Dict[str, Any]:
        """
        安全弃牌
        
        当出现错误时的安全选择
        
        Args:
            valid_actions: 可用行动列表
            
        Returns:
            Dict: 弃牌行动
        """
        fold_action = next((a for a in valid_actions if a.get('action') == 'fold'), None)
        if fold_action:
            return fold_action
        return {"action": "fold", "amount": 0}
    
    def reset(self):
        """
        重置AI状态 (可选方法)
        
        在新游戏开始时调用，用于清理AI的内部状态。
        """
        self.opponent_stats.clear()
        self.hand_history.clear()
        self.current_hand_actions.clear()
        logger.info(f"AI {self.name} reset successfully")
    
    def get_thinking_time(self) -> float:
        """
        获取思考时间 (可选方法)
        
        返回AI需要的思考时间（秒）。
        这会让AI看起来更像人类玩家。
        
        Returns:
            float: 思考时间（秒）
        """
        return random.uniform(0.5, 3.0)


# ============================================================================
# 使用示例和测试代码
# ============================================================================
if __name__ == "__main__":
    # 创建AI实例
    ai = GeminiAI()
    
    # 测试AI信息
    print("AI Info:", ai.get_info())
    
    # 测试决策（模拟游戏状态）
    test_game_state = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 20},
            {'action': 'raise', 'min_amount': 40, 'max_amount': 200}
        ],
        'players': {
            'player1': {
                'hole_cards': ['As', 'Kh'],
                'chips': 1000,
                'current_bet': 10,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': [],
        'pot': 30,
        'current_bet': 20,
        'phase': 'preflop',
        'dealer_index': 0
    }
    
    decision = ai.make_move(test_game_state)
    print("Decision:", decision)
    
    # 测试手牌评估
    strength = ai.evaluate_hand_strength(['As', 'Kh'], [])
    print(f"Hand strength: {strength:.3f}")

    # Test hand ranking
    cards = ['As', 'Ks', 'Qs', 'Js', '10s']
    print(f"Hand: {cards}, Rank: {ai._get_hand_rank(cards)}")

    cards = ['5c', '6c', '7c', '8c', '9c']
    print(f"Hand: {cards}, Rank: {ai._get_hand_rank(cards)}")

    cards = ['Ah', 'Ad', 'As', 'Ac', '2d']
    print(f"Hand: {cards}, Rank: {ai._get_hand_rank(cards)}")

    cards = ['Kh', 'Kd', 'Ks', 'Qc', 'Qd']
    print(f"Hand: {cards}, Rank: {ai._get_hand_rank(cards)}")

    cards = ['2h', '3h', '8h', 'Qh', 'Ah']
    print(f"Hand: {cards}, Rank: {ai._get_hand_rank(cards)}")

    cards = ['2d', '3h', '4s', '5c', '6d']
    print(f"Hand: {cards}, Rank: {ai._get_hand_rank(cards)}")

    cards = ['7h', '7d', '7s', '2c', '3d']
    print(f"Hand: {cards}, Rank: {ai._get_hand_rank(cards)}")

    cards = ['8h', '8d', '9s', '9c', 'Ad']
    print(f"Hand: {cards}, Rank: {ai._get_hand_rank(cards)}")

    cards = ['Qh', 'Qd', '2s', '3c', '4d']
    print(f"Hand: {cards}, Rank: {ai._get_hand_rank(cards)}")

    cards = ['Ah', '2d', '3s', '4c', '6d']
    print(f"Hand: {cards}, Rank: {ai._get_hand_rank(cards)}")
