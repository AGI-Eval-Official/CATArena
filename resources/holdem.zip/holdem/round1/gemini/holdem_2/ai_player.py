"""
德州扑克AI - Gemini
============================================================================
"""

import random
import math
import logging
from typing import Dict, List, Any, Tuple, Optional
from collections import defaultdict
from itertools import combinations

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('gemini_holdem_ai')


class GeminiHoldemAI:
    """
    德州扑克AI - Gemini
    """
    
    def __init__(self):
        """
        初始化AI
        """
        # ====================================================================
        # 基本信息 (必需) - 与ai_config.yaml保持一致
        # ====================================================================
        self.ai_id = "Gemini_2"
        self.name = "gemini_holdem_2_ai"
        self.version = "1.0.0"
        self.description = "A strategic and competitive AI for Texas Hold'em"
        
        # ====================================================================
        # 策略参数 (可根据需要调整)
        # ====================================================================
        self.aggression_level = 0.6
        self.bluff_frequency = 0.15
        self.position_awareness = True
        self.tight_aggressive = True
        
        # ====================================================================
        # 游戏状态追踪 (可选，用于高级策略)
        # ====================================================================
        self.opponent_stats = defaultdict(lambda: {
            'hands_played': 0,
            'vpip': 0,
            'pfr': 0,
            'aggression': 0,
            'fold_to_bet': 0,
            'recent_actions': []
        })
        self.hand_history = []
        self.current_hand_actions = []
        
        logger.info(f"AI {self.name} initialized successfully")
    
    def get_info(self) -> Dict[str, Any]:
        """
        获取AI信息 (必需方法)
        """
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "capabilities": [
                "hand_evaluation",
                "decision_making", 
                "position_awareness",
                "pot_odds_calculation"
            ]
        }
    
    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        核心决策方法 (必需方法)
        """
        try:
            valid_actions = game_state.get('valid_actions', [])
            if not valid_actions:
                logger.warning("No valid actions available, folding")
                return {"action": "fold", "amount": 0}
            
            current_player = game_state.get('current_player')
            players = game_state.get('players', {})
            
            if current_player not in players:
                logger.error(f"Current player {current_player} not found in players")
                return self._safe_fold(valid_actions)
            
            player_info = players[current_player]
            hole_cards = player_info.get('hole_cards', [])
            my_chips = player_info.get('chips', 0)
            my_current_bet = player_info.get('current_bet', 0)
            
            community_cards = game_state.get('community_cards', [])
            pot = game_state.get('pot', 0)
            current_bet = game_state.get('current_bet', 0)
            phase = game_state.get('phase', 'preflop')
            dealer_index = game_state.get('dealer_index', 0)
            
            available_actions = self._parse_valid_actions(valid_actions)
            
            hand_strength = self.evaluate_hand_strength(hole_cards, community_cards)
            
            position = self.analyze_position(current_player, players, dealer_index)
            
            bet_to_call = current_bet - my_current_bet
            pot_odds = self.calculate_pot_odds(pot, bet_to_call) if bet_to_call > 0 else float('inf')
            
            decision = self._make_decision(
                hand_strength=hand_strength,
                position=position,
                pot_odds=pot_odds,
                available_actions=available_actions,
                game_state=game_state
            )
            
            logger.info(f"Decision: {decision}, Hand: {hole_cards}, Strength: {hand_strength:.3f}, Position: {position}")
            return decision
            
        except Exception as e:
            logger.error(f"Error in make_move: {e}")
            return self._safe_fold(valid_actions)
    
    def _parse_valid_actions(self, valid_actions: List[Dict]) -> Dict[str, Optional[Dict]]:
        actions = {
            'fold': None,
            'check': None,
            'call': None,
            'raise': None,
            'all_in': None
        }
        
        for action in valid_actions:
            action_type = action.get('action')
            if action_type in actions:
                actions[action_type] = action
                
        return actions
    
    def _make_decision(self, hand_strength: float, position: str, pot_odds: float, 
                      available_actions: Dict, game_state: Dict) -> Dict[str, Any]:
        VERY_STRONG_THRESHOLD = 0.8
        STRONG_THRESHOLD = 0.6
        PLAYABLE_THRESHOLD = 0.4
        
        position_factor = {
            'early': 0.9,
            'middle': 1.0,
            'late': 1.1
        }.get(position, 1.0)
        
        adjusted_strength = hand_strength * position_factor
        
        if adjusted_strength >= VERY_STRONG_THRESHOLD:
            if available_actions['raise']:
                amount = self._calculate_raise_amount(game_state, 'value_bet')
                return {"action": "raise", "amount": amount}
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        elif adjusted_strength >= STRONG_THRESHOLD:
            if available_actions['raise'] and (position == 'late' or pot_odds < 3):
                amount = self._calculate_raise_amount(game_state, 'value_bet')
                return {"action": "raise", "amount": amount}
            elif available_actions['call'] and pot_odds > 2:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        elif adjusted_strength >= PLAYABLE_THRESHOLD:
            if available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 3:
                return available_actions['call']
            elif position == 'late' and self._should_bluff() and available_actions['raise']:
                amount = self._calculate_raise_amount(game_state, 'bluff')
                return {"action": "raise", "amount": amount}
        
        else:
            if available_actions['check']:
                return available_actions['check']
        
        if available_actions['fold']:
            return available_actions['fold']
        
        return list(available_actions.values())[0] if available_actions else {"action": "fold"}
    
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if len(community_cards) == 0:
            return self._evaluate_preflop_strength(hole_cards)
        else:
            all_cards = hole_cards + community_cards
            return self._evaluate_postflop_strength(all_cards)
    
    def _evaluate_preflop_strength(self, hole_cards: List[str]) -> float:
        if len(hole_cards) != 2:
            return 0.0
        
        card1, card2 = hole_cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(rank1, 0)
        val2 = rank_values.get(rank2, 0)
        
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        is_suited = (suit1 == suit2)
        is_pair = (val1 == val2)
        
        if is_pair:
            if high_card >= 13:
                return 0.9 + (high_card - 13) * 0.03
            elif high_card >= 10:
                return 0.75 + (high_card - 10) * 0.05
            else:
                return 0.4 + (high_card - 2) * 0.04
        else:
            base_strength = (high_card + low_card) / 28.0
            
            if is_suited:
                base_strength += 0.1
            
            if abs(val1 - val2) == 1:
                base_strength += 0.05
            elif abs(val1 - val2) <= 3:
                base_strength += 0.02
            
            if high_card == 14:
                base_strength += 0.1
            elif high_card >= 12:
                base_strength += 0.05
            
            return min(base_strength, 0.95)
    
    def _evaluate_postflop_strength(self, all_cards: List[str]) -> float:
        best_rank = self._get_best_hand_rank(all_cards)
        
        rank_to_strength = {
            'royal_flush': 1.0,
            'straight_flush': 0.95,
            'four_of_a_kind': 0.9,
            'full_house': 0.85,
            'flush': 0.75,
            'straight': 0.65,
            'three_of_a_kind': 0.55,
            'two_pair': 0.45,
            'one_pair': 0.35,
            'high_card': 0.2
        }
        
        return rank_to_strength.get(best_rank, 0.2)

    def _get_best_hand_rank(self, all_cards: List[str]) -> str:
        if len(all_cards) < 5:
            return 'high_card'

        best_rank = 'high_card'
        
        for hand_combination in combinations(all_cards, 5):
            rank = self._get_hand_rank(list(hand_combination))
            if self._compare_ranks(rank, best_rank) > 0:
                best_rank = rank
        return best_rank

    def _get_hand_rank(self, hand: List[str]) -> str:
        ranks = '23456789TJQKA'
        suits = 'shdc'
        
        hand_ranks = sorted([ranks.index(r[0]) for r in hand], reverse=True)
        hand_suits = [s[1] for s in hand]

        is_flush = len(set(hand_suits)) == 1
        is_straight = all(hand_ranks[i] - hand_ranks[i+1] == 1 for i in range(len(hand_ranks)-1)) or hand_ranks == [12, 3, 2, 1, 0] # Ace-low straight

        rank_counts = defaultdict(int)
        for r in hand_ranks:
            rank_counts[r] += 1
        
        counts = sorted(rank_counts.values(), reverse=True)

        if is_straight and is_flush and hand_ranks[0] == 12:
            return 'royal_flush'
        if is_straight and is_flush:
            return 'straight_flush'
        if counts[0] == 4:
            return 'four_of_a_kind'
        if counts == [3, 2]:
            return 'full_house'
        if is_flush:
            return 'flush'
        if is_straight:
            return 'straight'
        if counts[0] == 3:
            return 'three_of_a_kind'
        if counts == [2, 2, 1]:
            return 'two_pair'
        if counts[0] == 2:
            return 'one_pair'
        return 'high_card'

    def _compare_ranks(self, rank1, rank2):
        rank_order = {
            'high_card': 0, 'one_pair': 1, 'two_pair': 2, 'three_of_a_kind': 3,
            'straight': 4, 'flush': 5, 'full_house': 6, 'four_of_a_kind': 7,
            'straight_flush': 8, 'royal_flush': 9
        }
        return rank_order[rank1] - rank_order[rank2]

    def analyze_position(self, current_player: str, players: Dict, dealer_index: int) -> str:
        active_players = [pid for pid, pinfo in players.items() 
                         if pinfo.get('state') == 'active']
        
        if current_player not in active_players:
            return 'unknown'
        
        player_count = len(active_players)
        current_index = active_players.index(current_player)
        
        if player_count <= 3:
            return 'late' if current_index == player_count - 1 else 'early'
        elif player_count <= 6:
            if current_index < player_count // 3:
                return 'early'
            elif current_index < 2 * player_count // 3:
                return 'middle'
            else:
                return 'late'
        else:
            if current_index < 2:
                return 'early'
            elif current_index < player_count - 2:
                return 'middle'
            else:
                return 'late'
    
    def calculate_pot_odds(self, pot_size: int, bet_to_call: int) -> float:
        if bet_to_call <= 0:
            return float('inf')
        return pot_size / bet_to_call
    
    def _calculate_raise_amount(self, game_state: Dict, raise_type: str) -> int:
        pot = game_state.get('pot', 0)
        current_bet = game_state.get('current_bet', 0)
        
        multipliers = {
            'value_bet': 0.7,
            'bluff': 0.5,
            'protection': 0.8
        }
        
        multiplier = multipliers.get(raise_type, 0.6)
        raise_amount = int(pot * multiplier)
        
        min_raise = current_bet * 2
        
        # Ensure raise amount is at least the minimum raise
        raise_amount = max(raise_amount, min_raise)

        # Ensure raise amount is within valid range if available
        valid_actions = game_state.get('valid_actions', [])
        raise_action_info = next((a for a in valid_actions if a.get('action') == 'raise'), None)
        if raise_action_info:
            min_raise_allowed = raise_action_info.get('min_amount', min_raise)
            max_raise_allowed = raise_action_info.get('max_amount', raise_amount)
            raise_amount = max(min_raise_allowed, min(raise_amount, max_raise_allowed))

        return raise_amount
    
    def _should_bluff(self) -> bool:
        return random.random() < self.bluff_frequency
    
    def _parse_card(self, card: str) -> Tuple[str, str]:
        if len(card) == 3 and card.startswith('10'):
            return 'T', card[2]
        return card[0], card[1]
    
    def _safe_fold(self, valid_actions: List[Dict]) -> Dict[str, Any]:
        fold_action = next((a for a in valid_actions if a.get('action') == 'fold'), None)
        if fold_action:
            return fold_action
        return {"action": "fold", "amount": 0}
    
    def reset(self):
        self.opponent_stats.clear()
        self.hand_history.clear()
        self.current_hand_actions.clear()
        logger.info(f"AI {self.name} reset successfully")
    
    def get_thinking_time(self) -> float:
        return random.uniform(0.5, 2.0)


if __name__ == "__main__":
    ai = GeminiHoldemAI()
    
    print("AI Info:", ai.get_info())
    
    test_game_state = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 20},
            {'action': 'raise', 'min_amount': 40, 'max_amount': 200}
        ],
        'players': {
            'player1': {
                'hole_cards': ['As', 'Kh'],
                'chips': 1000,
                'current_bet': 10,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': [],
        'pot': 30,
        'current_bet': 20,
        'phase': 'preflop',
        'dealer_index': 0
    }
    
    decision = ai.make_move(test_game_state)
    print("Decision:", decision)
    
    strength = ai.evaluate_hand_strength(['As', 'Kh'], [])
    print(f"Hand strength: {strength:.3f}")

    # Test post-flop hand evaluation
    post_flop_strength = ai.evaluate_hand_strength(['As', 'Kh'], ['Qd', 'Jc', 'Ts'])
    print(f"Post-flop hand strength: {post_flop_strength:.3f}")
