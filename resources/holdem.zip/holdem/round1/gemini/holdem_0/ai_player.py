"""
Gemini Traditional AI for Texas Hold'em
============================================================================
This file contains the implementation of the Gemini Traditional AI for the
CATArena Texas Hold'em game.
============================================================================
"""

import random
import logging
from typing import Dict, List, Any, Tuple
from collections import defaultdict
from itertools import combinations

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('gemini_traditional_ai')

class GeminiTraditionalAI:
    """
    The Gemini Traditional AI for Texas Hold'em.
    """

    def __init__(self):
        """
        Initializes the AI.
        """
        self.ai_id = "Gemini_0"
        self.name = "Gemini Traditional AI"
        self.version = "1.0"
        self.description = "A strategic AI for traditional Texas Hold'em, developed by Gemini."
        self.author = "Gemini"

    def get_info(self) -> Dict[str, Any]:
        """
        Returns the AI's information.
        """
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "capabilities": [
                "hand_evaluation",
                "decision_making",
                "position_awareness",
                "pot_odds_calculation"
            ]
        }

    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Makes a move based on the current game state.
        """
        try:
            # Extract necessary information from the game state
            valid_actions = game_state.get('valid_actions', [])
            if not valid_actions:
                return {"action": "fold"}

            current_player_id = game_state.get('current_player')
            players = game_state.get('players', {})
            player_info = players.get(current_player_id, {})
            hole_cards = player_info.get('hole_cards', [])
            my_chips = player_info.get('chips', 0)
            my_current_bet = player_info.get('current_bet', 0)

            community_cards = game_state.get('community_cards', [])
            pot = game_state.get('pot', 0)
            current_bet = game_state.get('current_bet', 0)
            phase = game_state.get('phase', 'preflop')
            dealer_index = game_state.get('dealer_index', 0)

            # Parse available actions
            available_actions = self._parse_valid_actions(valid_actions)

            # Evaluate hand strength
            hand_strength, best_hand = self.evaluate_hand_strength(hole_cards, community_cards)

            # Analyze position
            position = self.analyze_position(current_player_id, players, dealer_index)

            # Calculate pot odds
            bet_to_call = current_bet - my_current_bet
            pot_odds = self.calculate_pot_odds(pot, bet_to_call)

            # Make a decision
            decision = self._make_decision(
                hand_strength=hand_strength,
                position=position,
                pot_odds=pot_odds,
                available_actions=available_actions,
                game_state=game_state,
                my_chips=my_chips
            )

            logger.info(f"Decision: {decision}, Hand: {hole_cards}, Community: {community_cards}, Strength: {hand_strength:.3f}, Position: {position}")
            return decision

        except Exception as e:
            logger.error(f"Error in make_move: {e}", exc_info=True)
            return self._safe_fold(valid_actions)

    def _parse_valid_actions(self, valid_actions: List[Dict]) -> Dict[str, Any]:
        """
        Parses the list of valid actions into a dictionary.
        """
        actions = {}
        for action in valid_actions:
            actions[action['action']] = action
        return actions

    def _make_decision(self, hand_strength: float, position: str, pot_odds: float,
                       available_actions: Dict, game_state: Dict, my_chips: int) -> Dict[str, Any]:
        """
        The core decision-making logic.
        """
        bet_to_call = game_state['current_bet'] - game_state['players'][game_state['current_player']]['current_bet']

        # Pre-flop strategy
        if game_state['phase'] == 'preflop':
            return self._preflop_strategy(hand_strength, position, available_actions, game_state)

        # Post-flop strategy
        else:
            return self._postflop_strategy(hand_strength, pot_odds, available_actions, game_state, my_chips)

    def _preflop_strategy(self, hand_strength: float, position: str, available_actions: Dict, game_state: Dict) -> Dict[str, Any]:
        """
        Pre-flop decision making.
        """
        current_bet = game_state['current_bet']
        my_current_bet = game_state['players'][game_state['current_player']]['current_bet']
        bet_to_call = current_bet - my_current_bet

        # Premium hands
        if hand_strength > 0.85:
            if 'raise' in available_actions:
                return self._get_raise_action(available_actions, game_state, 3)
            else:
                return available_actions.get('call', available_actions.get('check', available_actions['fold']))

        # Strong hands
        elif hand_strength > 0.7:
            if position in ['late', 'middle']:
                if 'raise' in available_actions:
                    return self._get_raise_action(available_actions, game_state, 2.5)
            if bet_to_call == 0:
                return available_actions.get('check', available_actions['fold'])
            else:
                return available_actions.get('call', available_actions['fold'])

        # Speculative hands
        elif hand_strength > 0.5:
            if position == 'late' and bet_to_call <= game_state['pot'] * 0.1:
                return available_actions.get('call', available_actions.get('check', available_actions['fold']))
            if bet_to_call == 0:
                return available_actions.get('check', available_actions['fold'])

        return available_actions.get('fold')

    def _postflop_strategy(self, hand_strength: float, pot_odds: float, available_actions: Dict, game_state: Dict, my_chips: int) -> Dict[str, Any]:
        """
        Post-flop decision making.
        """
        bet_to_call = game_state['current_bet'] - game_state['players'][game_state['current_player']]['current_bet']

        # Very strong hands (value betting)
        if hand_strength > 0.8:
            if 'raise' in available_actions:
                return self._get_raise_action(available_actions, game_state, 0.75)
            else:
                return available_actions.get('call', available_actions.get('check', available_actions['fold']))

        # Good hands
        elif hand_strength > 0.6:
            if 'raise' in available_actions:
                return self._get_raise_action(available_actions, game_state, 0.5)
            elif bet_to_call > 0:
                if pot_odds > 2:
                    return available_actions['call']
            else:
                return available_actions['check']

        # Drawing hands
        elif hand_strength > 0.4:
            if bet_to_call > 0:
                # Calling if pot odds are good
                if pot_odds > 4: # Simplified odds for draws
                    return available_actions['call']
            else:
                return available_actions['check']

        # Weak hands
        if bet_to_call == 0:
            return available_actions.get('check', available_actions['fold'])
        else:
            return available_actions['fold']

    def _get_raise_action(self, available_actions: Dict, game_state: Dict, multiplier: float) -> Dict[str, Any]:
        """
        Calculates the raise amount.
        """
        raise_action = available_actions['raise']
        min_raise = raise_action['min_amount']
        max_raise = raise_action['max_amount']

        if game_state['phase'] == 'preflop':
            amount = game_state['current_bet'] * multiplier
        else:
            amount = game_state['pot'] * multiplier

        amount = int(max(min_raise, min(amount, max_raise)))
        return {"action": "raise", "amount": amount}

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[float, str]:
        """
        Evaluates the strength of the hand.
        """
        if not hole_cards:
            return 0.0, "No cards"

        if not community_cards:
            return self._preflop_hand_strength(hole_cards), "Pre-flop"
        else:
            return self._postflop_hand_strength(hole_cards, community_cards)

    def _preflop_hand_strength(self, hole_cards: List[str]) -> float:
        """
        Evaluates pre-flop hand strength based on a simplified Sklansky-Malmuth starting hands table.
        """
        card1, card2 = hole_cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        rank_map = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, '10': 10, '9': 9, '8': 8, '7': 7, '6': 6, '5': 5, '4': 4, '3': 3, '2': 2}
        r1 = rank_map[rank1]
        r2 = rank_map[rank2]

        suited = suit1 == suit2
        pair = r1 == r2
        
        # Higher card first
        if r2 > r1:
            r1, r2 = r2, r1

        # Hand strength groups (simplified)
        if pair:
            if r1 >= 12: return 0.9 # AA, KK, QQ
            if r1 >= 10: return 0.8 # JJ, TT
            if r1 >= 7: return 0.7 # 99, 88, 77
            return 0.6 # 66-22
        
        if suited:
            if r1 == 14 and r2 >= 12: return 0.85 # AKs, AQs
            if r1 >= 12 and r2 >= 11: return 0.8 # KQs, KJs
            if r1 == 14 and r2 >= 10: return 0.75 # AJs, ATs
            if r1 >= 10 and r2 >= 9 and abs(r1-r2) <= 2: return 0.65 # QJs, JTs, T9s etc.
            return 0.5

        # Off-suit
        if r1 == 14 and r2 >= 12: return 0.75 # AKo, AQo
        if r1 >= 12 and r2 >= 11: return 0.7 # KQo
        if r1 == 14 and r2 >= 10: return 0.65 # AJo, ATo
        
        return 0.4


    def _postflop_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[float, str]:
        """
        Evaluates post-flop hand strength.
        """
        all_cards = hole_cards + community_cards
        best_rank = 0
        best_hand_name = "High Card"

        if len(all_cards) < 5:
            return 0.0, "Not enough cards"

        for hand_combination in combinations(all_cards, 5):
            rank, hand_name = self._evaluate_five_card_hand(list(hand_combination))
            if rank > best_rank:
                best_rank = rank
                best_hand_name = hand_name
        
        # Normalize rank to a 0-1 scale
        strength = best_rank / 9.0
        return strength, best_hand_name

    def _evaluate_five_card_hand(self, hand: List[str]) -> Tuple[int, str]:
        """
        Evaluates a five-card hand and returns its rank and name.
        Rank: 9 (Royal Flush) to 0 (High Card).
        """
        ranks = sorted([self._get_rank_value(c) for c in hand], reverse=True)
        suits = [self._get_suit(c) for c in hand]
        
        is_flush = len(set(suits)) == 1
        is_straight = all(ranks[i] == ranks[i+1] + 1 for i in range(len(ranks)-1)) or ranks == [14, 5, 4, 3, 2] # Ace-low straight

        if is_straight and is_flush:
            if ranks[0] == 14: return 9, "Royal Flush"
            return 8, "Straight Flush"

        rank_counts = defaultdict(int)
        for r in ranks:
            rank_counts[r] += 1
        counts = sorted(rank_counts.values(), reverse=True)

        if counts[0] == 4: return 7, "Four of a Kind"
        if counts == [3, 2]: return 6, "Full House"
        if is_flush: return 5, "Flush"
        if is_straight: return 4, "Straight"
        if counts[0] == 3: return 3, "Three of a Kind"
        if counts == [2, 2, 1]: return 2, "Two Pair"
        if counts[0] == 2: return 1, "One Pair"
        return 0, "High Card"

    def _get_rank_value(self, card: str) -> int:
        rank = self._parse_card(card)[0]
        return {'A': 14, 'K': 13, 'Q': 12, 'J': 11, '10': 10, '9': 9, '8': 8, '7': 7, '6': 6, '5': 5, '4': 4, '3': 3, '2': 2}[rank]

    def _get_suit(self, card: str) -> str:
        return self._parse_card(card)[1]

    def analyze_position(self, current_player: str, players: Dict, dealer_index: int) -> str:
        """
        Analyzes the player's position at the table.
        """
        active_players = [pid for pid, pinfo in players.items() if pinfo.get('state') == 'active']
        player_count = len(active_players)
        
        if current_player not in active_players:
            return 'unknown'
            
        my_index = active_players.index(current_player)
        
        # Simplified position analysis
        if player_count <= 3:
            return 'late'
        if my_index <= player_count / 3:
            return 'early'
        if my_index <= 2 * player_count / 3:
            return 'middle'
        return 'late'

    def calculate_pot_odds(self, pot_size: int, bet_to_call: int) -> float:
        """
        Calculates pot odds.
        """
        if bet_to_call <= 0:
            return float('inf')
        return pot_size / bet_to_call

    def _parse_card(self, card: str) -> Tuple[str, str]:
        """
        Parses a card string into rank and suit.
        """
        if len(card) == 3: # 10
            return card[:2], card[2]
        return card[0], card[1]

    def _safe_fold(self, valid_actions: List[Dict]) -> Dict[str, Any]:
        """
        Returns a fold action, used as a fallback.
        """
        for action in valid_actions:
            if action['action'] == 'fold':
                return action
        return {"action": "fold"}

if __name__ == '__main__':
    # Example of how to use the AI
    ai = GeminiTraditionalAI()
    print(ai.get_info())

    # Example game state
    game_state = {
        'valid_actions': [{'action': 'fold'}, {'action': 'call', 'amount': 20}, {'action': 'raise', 'min_amount': 40, 'max_amount': 200}],
        'players': {
            'player1': {'hole_cards': ['A', 'K'], 'chips': 1000, 'current_bet': 10, 'state': 'active'},
            'player2': {'hole_cards': [], 'chips': 1000, 'current_bet': 20, 'state': 'active'}
        },
        'current_player': 'player1',
        'community_cards': ['Q', 'J', '10'],
        'pot': 50,
        'current_bet': 20,
        'phase': 'flop',
        'dealer_index': 0
    }
    # The example game_state is simplified and may not match the actual game state format.
    # move = ai.make_move(game_state)
    # print(f"AI's move: {move}")
