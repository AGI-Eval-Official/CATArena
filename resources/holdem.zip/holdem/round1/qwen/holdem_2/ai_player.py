"""
Qwen Code德州扑克AI - Traditional模式
============================================================================
这是一个高级的德州扑克AI实现，包含以下核心功能：
1. 精确的手牌评估和强度计算
2. 位置感知的决策制定逻辑
3. 动态对手建模
4. 底池赔率和期望值计算
5. 战略性虚张声势
6. 手牌范围分析

这个AI采用紧凶策略（Tight-Aggressive），在有利位置更加激进，
并根据对手行为动态调整策略。
============================================================================
"""

import random
import math
import logging
from typing import Dict, List, Any, Tuple, Optional
from collections import defaultdict, Counter
from itertools import combinations


class QwenCodeAI:
    """
    德州扑克AI - Traditional模式
    
    这个类实现了一个高级的德州扑克AI，专为竞技对战设计。
    """
    
    def __init__(self):
        """
        初始化AI
        """
        # ====================================================================
        # 基本信息 (必需) - 与ai_config.yaml保持一致
        # ====================================================================
        self.ai_id = "Qwen_2"
        self.name = "Qwen Code AI"
        self.version = "1.0"
        self.description = "A strategic Texas Hold'em AI developed by Qwen Code"
        
        # ====================================================================
        # 策略参数
        # ====================================================================
        self.aggression_level = 0.7      # 激进程度
        self.bluff_frequency = 0.18      # 虚张声势频率
        self.tight_aggressive = True     # 紧凶策略
        
        # ====================================================================
        # 游戏状态追踪 - 用于对手建模和自适应策略
        # ====================================================================
        self.opponent_stats = defaultdict(lambda: {
            'hands_played': 0,
            'vpip': 0.0,      # Voluntarily Put money In Pot (入场率)
            'pfr': 0.0,       # Pre-Flop Raise (翻牌前加注率)
            'aggression': 0.0, # 攻击性指标
            'fold_to_bet': 0.0, # 面对下注的弃牌率
            'recent_actions': [],
            'bet_sizes': [],
            'positions_played': defaultdict(int),
            'showdowns': 0,
            'wins_at_showdown': 0
        })
        self.hand_history = []
        self.current_session_hands = 0
        self.table_players = []  # 当前桌子的玩家列表
        
        # 手牌强度缓存
        self._hand_strength_cache = {}
        
        # 牌面值映射
        self.rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                           '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        self.suit_values = {'h': 0, 'd': 1, 'c': 2, 's': 3}
        
        # 预计算的翻牌前手牌强度表（基于Skalansky-Malmuth分类）
        self._preflop_strength_table = self._build_preflop_strength_table()
    
    def get_info(self) -> Dict[str, Any]:
        """
        获取AI信息 (必需方法)
        """
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "capabilities": [
                "hand_evaluation",
                "decision_making", 
                "position_awareness",
                "pot_odds_calculation",
                "opponent_modeling",
                "bluffing"
            ]
        }
    
    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        核心决策方法 (必需方法)
        """
        try:
            # 验证输入
            valid_actions = game_state.get('valid_actions', [])
            if not valid_actions:
                return {"action": "fold"}
            
            current_player = game_state.get('current_player')
            players = game_state.get('players', {})
            
            if current_player not in players:
                return self._safe_fold(valid_actions)
            
            player_info = players[current_player]
            hole_cards = player_info.get('hole_cards', [])
            my_chips = player_info.get('chips', 0)
            my_current_bet = player_info.get('current_bet', 0)
            
            community_cards = game_state.get('community_cards', [])
            pot = game_state.get('pot', 0)
            current_bet = game_state.get('current_bet', 0)
            phase = game_state.get('phase', 'preflop')
            dealer_index = game_state.get('dealer_index', 0)
            
            # 更新对手统计数据
            self._update_opponent_stats(game_state)
            
            # 解析可用行动
            available_actions = self._parse_valid_actions(valid_actions)
            
            # 手牌评估
            hand_strength = self.evaluate_hand_strength(hole_cards, community_cards)
            
            # 位置分析
            position = self.analyze_position(current_player, players, dealer_index)
            
            # 计算需要跟注的金额和底池赔率
            bet_to_call = current_bet - my_current_bet
            pot_odds = self.calculate_pot_odds(pot, bet_to_call) if bet_to_call > 0 else float('inf')
            
            # 期望值计算
            expected_value = self._calculate_expected_value(
                hand_strength, pot_odds, len([p for p in players.values() if p.get('state') == 'active']), phase
            )
            
            # 决策
            decision = self._make_strategic_decision(
                hand_strength=hand_strength,
                expected_value=expected_value,
                position=position,
                pot_odds=pot_odds,
                bet_to_call=bet_to_call,
                my_chips=my_chips,
                available_actions=available_actions,
                game_state=game_state,
                phase=phase
            )
            
            return decision
            
        except Exception as e:
            # 安全回退到弃牌
            return self._safe_fold(valid_actions)
    
    def _parse_valid_actions(self, valid_actions: List[Dict]) -> Dict[str, Optional[Dict]]:
        """解析可用行动"""
        actions = {
            'fold': None,
            'check': None,
            'call': None,
            'raise': None,
            'all_in': None
        }
        
        for action in valid_actions:
            action_type = action.get('action')
            if action_type in actions:
                actions[action_type] = action
                
        return actions
    
    def _make_strategic_decision(self, hand_strength: float, expected_value: float, 
                               position: str, pot_odds: float, bet_to_call: int,
                               my_chips: int, available_actions: Dict, 
                               game_state: Dict, phase: str) -> Dict[str, Any]:
        """
        高级战略决策逻辑
        
        结合手牌强度、期望值、位置、对手模型等多个因素做出决策。
        """
        # 获取当前活跃玩家数量
        active_players = len([p for p in game_state['players'].values() if p.get('state') == 'active'])
        
        # 位置调整因子
        position_factor = self._get_position_factor(position, active_players)
        
        # 对手调整因子（基于对手的松紧程度）
        opponent_factor = self._get_opponent_adjustment_factor(game_state)
        
        # 调整后手牌强度
        adjusted_strength = min(hand_strength * position_factor * opponent_factor, 1.0)
        
        # 阶段特定的阈值
        if phase == 'preflop':
            very_strong_threshold = 0.85
            strong_threshold = 0.70
            playable_threshold = 0.50
            weak_threshold = 0.30
        elif phase == 'flop':
            very_strong_threshold = 0.80
            strong_threshold = 0.60
            playable_threshold = 0.40
            weak_threshold = 0.25
        elif phase == 'turn':
            very_strong_threshold = 0.75
            strong_threshold = 0.55
            playable_threshold = 0.35
            weak_threshold = 0.20
        else:  # river
            very_strong_threshold = 0.70
            strong_threshold = 0.50
            playable_threshold = 0.30
            weak_threshold = 0.15
        
        # 非常强的手牌 - 总是激进（价值下注）
        if adjusted_strength >= very_strong_threshold:
            if available_actions['raise']:
                amount = self._calculate_strategic_raise_amount(
                    game_state, 'value_bet', hand_strength, position
                )
                return {"action": "raise", "amount": amount}
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        # 强手牌 - 价值下注或跟注
        elif adjusted_strength >= strong_threshold:
            if available_actions['raise'] and (
                position in ['late', 'button'] or 
                (active_players <= 2 and pot_odds < 4)
            ):
                amount = self._calculate_strategic_raise_amount(
                    game_state, 'value_bet', hand_strength, position
                )
                return {"action": "raise", "amount": amount}
            elif available_actions['call'] and pot_odds > 2:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        # 可玩手牌 - 根据情况决定
        elif adjusted_strength >= playable_threshold:
            if available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 3:
                return available_actions['call']
            # 虚张声势机会
            elif (position in ['late', 'button'] and 
                  self._should_bluff_strategically(game_state, phase) and 
                  available_actions['raise']):
                amount = self._calculate_strategic_raise_amount(
                    game_state, 'bluff', hand_strength, position
                )
                return {"action": "raise", "amount": amount}
        
        # 弱手牌 - 大多数情况下弃牌，除非底池赔率极好
        else:
            if available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 8:
                return available_actions['call']
        
        # 默认弃牌
        if available_actions['fold']:
            return available_actions['fold']
        
        # 后备选择
        for action_name in ['check', 'call', 'raise']:
            if available_actions[action_name]:
                return available_actions[action_name]
        
        return {"action": "fold"}
    
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        评估手牌强度
        
        使用更精确的算法，包括：
        1. 翻牌前：基于预计算的强度表
        2. 翻牌后：基于可能的最佳手牌和听牌潜力
        """
        cache_key = (tuple(sorted(hole_cards)), tuple(sorted(community_cards)))
        if cache_key in self._hand_strength_cache:
            return self._hand_strength_cache[cache_key]
        
        if len(community_cards) == 0:
            strength = self._evaluate_preflop_strength_precise(hole_cards)
        else:
            strength = self._evaluate_postflop_strength_advanced(hole_cards, community_cards)
        
        # 缓存结果
        self._hand_strength_cache[cache_key] = strength
        return strength
    
    def _evaluate_preflop_strength_precise(self, hole_cards: List[str]) -> float:
        """精确的翻牌前手牌强度评估"""
        if len(hole_cards) != 2:
            return 0.0
        
        # 标准化手牌表示（高牌在前）
        card1, card2 = hole_cards
        # Handle 10s properly (they are represented as '10s', '10h', etc.)
        if card1.startswith('10'):
            rank1 = '10'
            suit1 = card1[2]
        else:
            rank1 = card1[:-1]
            suit1 = card1[-1]
            
        if card2.startswith('10'):
            rank2 = '10'
            suit2 = card2[2]
        else:
            rank2 = card2[:-1]
            suit2 = card2[-1]
        
        val1 = self.rank_values[rank1]
        val2 = self.rank_values[rank2]
        
        if val1 < val2:
            val1, val2 = val2, val1
            rank1, rank2 = rank2, rank1
            suit1, suit2 = suit2, suit1
        
        is_suited = (suit1 == suit2)
        is_pair = (val1 == val2)
        gap = val1 - val2
        
        # 使用预计算的强度表
        key = (val1, val2, is_suited)
        if key in self._preflop_strength_table:
            base_strength = self._preflop_strength_table[key]
        else:
            # 动态计算
            base_strength = self._calculate_dynamic_preflop_strength(val1, val2, is_suited, gap)
        
        return min(base_strength, 0.95)
    
    def _build_preflop_strength_table(self) -> Dict:
        """构建翻牌前手牌强度表"""
        table = {}
        
        # 对子强度
        for rank in range(2, 15):  # 2-A
            strength = 0.4 + (rank - 2) * 0.045
            if rank >= 11:  # J及以上
                strength += 0.1
            table[(rank, rank, False)] = min(strength, 0.95)
            table[(rank, rank, True)] = min(strength, 0.95)  # 对子同花不影响
        
        # 非对子强度
        for high_rank in range(3, 15):
            for low_rank in range(2, high_rank):
                gap = high_rank - low_rank
                
                # 基础强度
                base = (high_rank + low_rank - 2) / 24.0  # 标准化到0-1
                
                # 同花加成
                suited_bonus = 0.12 if True else 0  # 同花
                unsuited_bonus = 0.0  # 非同花
                
                # 连牌加成
                connector_bonus = 0.0
                if gap == 1:  # 连牌
                    connector_bonus = 0.08
                elif gap == 2:  # 单gap连牌
                    connector_bonus = 0.04
                elif gap == 3:  # 双gap连牌
                    connector_bonus = 0.02
                
                # 高牌加成
                high_card_bonus = 0.0
                if high_rank == 14:  # A
                    high_card_bonus = 0.15
                elif high_rank >= 12:  # K, Q
                    high_card_bonus = 0.08
                elif high_rank >= 11:  # J
                    high_card_bonus = 0.04
                
                # 计算最终强度
                suited_strength = base + suited_bonus + connector_bonus + high_card_bonus
                unsuited_strength = base + unsuited_bonus + connector_bonus + high_card_bonus
                
                table[(high_rank, low_rank, True)] = min(suited_strength, 0.92)
                table[(high_rank, low_rank, False)] = min(unsuited_strength, 0.85)
        
        return table
    
    def _calculate_dynamic_preflop_strength(self, high_val: int, low_val: int, 
                                          is_suited: bool, gap: int) -> float:
        """动态计算翻牌前强度"""
        base = (high_val + low_val - 2) / 24.0
        
        if is_suited:
            base += 0.12
        
        if gap == 1:
            base += 0.08
        elif gap == 2:
            base += 0.04
        elif gap == 3:
            base += 0.02
        
        if high_val == 14:  # A
            base += 0.15
        elif high_val >= 12:  # K, Q
            base += 0.08
        
        return min(base, 0.95)
    
    def _evaluate_postflop_strength_advanced(self, hole_cards: List[str], 
                                           community_cards: List[str]) -> float:
        """高级翻牌后手牌强度评估"""
        all_cards = hole_cards + community_cards
        
        # 如果只有2张公共牌，还处于翻牌前
        if len(community_cards) < 3:
            return self._evaluate_preflop_strength_precise(hole_cards)
        
        # 评估当前最佳手牌
        current_hand_rank = self._get_current_hand_rank(all_cards)
        
        # 手牌等级到强度的映射
        rank_to_strength = {
            10: 1.0,    # 皇家同花顺
            9: 0.95,    # 同花顺
            8: 0.90,    # 四条
            7: 0.85,    # 葫芦
            6: 0.75,    # 同花
            5: 0.65,    # 顺子
            4: 0.55,    # 三条
            3: 0.45,    # 两对
            2: 0.35,    # 一对
            1: 0.20     # 高牌
        }
        
        base_strength = rank_to_strength.get(current_hand_rank, 0.2)
        
        # 添加听牌潜力（仅在翻牌和转牌阶段）
        if len(community_cards) in [3, 4]:  # flop or turn
            draw_potential = self._calculate_draw_potential(hole_cards, community_cards)
            base_strength += draw_potential * 0.3  # 最多增加30%强度
        
        return min(base_strength, 0.95)
    
    def _get_current_hand_rank(self, all_cards: List[str]) -> int:
        """获取当前手牌等级（简化实现）"""
        # 在实际比赛中，这里应该使用完整的手牌评估器
        # 但为了性能考虑，我们使用启发式方法
        
        if len(all_cards) < 5:
            return 1  # 高牌
        
        # 简单的启发式评估
        ranks = []
        suits = []
        
        for card in all_cards:
            # Handle 10s properly
            if card.startswith('10'):
                rank_str = '10'
                suit_str = card[2]
            else:
                rank_str = card[:-1]
                suit_str = card[-1]
            ranks.append(self.rank_values[rank_str])
            suits.append(suit_str)
        
        rank_counts = Counter(ranks)
        suit_counts = Counter(suits)
        
        # 检查同花
        is_flush = any(count >= 5 for count in suit_counts.values())
        
        # 检查顺子
        unique_ranks = sorted(set(ranks))
        is_straight = False
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    is_straight = True
                    break
            # 检查A-5顺子
            if set([14, 2, 3, 4, 5]).issubset(set(ranks)):
                is_straight = True
        
        # 检查牌型
        count_values = sorted(rank_counts.values(), reverse=True)
        
        if is_straight and is_flush:
            return 9 if max(ranks) < 14 else 10  # 同花顺或皇家同花顺
        elif 4 in count_values:
            return 8  # 四条
        elif 3 in count_values and 2 in count_values:
            return 7  # 葫芦
        elif is_flush:
            return 6  # 同花
        elif is_straight:
            return 5  # 顺子
        elif 3 in count_values:
            return 4  # 三条
        elif count_values.count(2) >= 2:
            return 3  # 两对
        elif 2 in count_values:
            return 2  # 一对
        else:
            return 1  # 高牌
    
    def _calculate_draw_potential(self, hole_cards: List[str], 
                                 community_cards: List[str]) -> float:
        """计算听牌潜力"""
        # 简化的听牌评估
        all_cards = hole_cards + community_cards
        ranks = []
        suits = []
        
        for card in all_cards:
            rank_str = card[:-1]
            suit_str = card[-1]
            ranks.append(self.rank_values[rank_str])
            suits.append(suit_str)
        
        suit_counts = Counter(suits)
        rank_counts = Counter(ranks)
        
        draw_score = 0.0
        
        # 同花听牌
        for suit, count in suit_counts.items():
            if count == 4:
                draw_score += 0.4  # 同花听牌
            elif count == 3 and len(community_cards) == 3:
                draw_score += 0.2  # 双头同花听牌
        
        # 顺子听牌
        unique_ranks = sorted(set(ranks))
        if len(unique_ranks) >= 4:
            # 检查开放式顺子听牌
            for i in range(len(unique_ranks) - 3):
                if unique_ranks[i+3] - unique_ranks[i] == 3:
                    draw_score += 0.35
                    break
            # 检查双头顺子听牌
            for i in range(len(unique_ranks) - 3):
                if unique_ranks[i+3] - unique_ranks[i] == 4:
                    draw_score += 0.25
                    break
        
        return min(draw_score, 0.6)
    
    def analyze_position(self, current_player: str, players: Dict, dealer_index: int) -> str:
        """分析玩家位置"""
        active_players = [pid for pid, pinfo in players.items() 
                         if pinfo.get('state') == 'active']
        
        if current_player not in active_players:
            return 'unknown'
        
        player_count = len(active_players)
        current_index = active_players.index(current_player)
        
        # 小盲和大盲位置
        if player_count >= 2:
            sb_index = (dealer_index + 1) % player_count
            bb_index = (dealer_index + 2) % player_count
            
            if current_index == sb_index:
                return 'small_blind'
            elif current_index == bb_index:
                return 'big_blind'
        
        # 其他位置
        if player_count <= 3:
            if current_index == (dealer_index + 1) % player_count:
                return 'early'
            else:
                return 'late'
        else:
            early_positions = min(2, player_count // 3)
            late_positions = min(2, player_count // 3)
            
            relative_pos = (current_index - dealer_index - 1) % player_count
            
            if relative_pos < early_positions:
                return 'early'
            elif relative_pos >= player_count - late_positions:
                return 'late'
            else:
                return 'middle'
    
    def calculate_pot_odds(self, pot_size: int, bet_to_call: int) -> float:
        """计算底池赔率"""
        if bet_to_call <= 0:
            return float('inf')
        return pot_size / bet_to_call
    
    def _calculate_expected_value(self, hand_strength: float, pot_odds: float, 
                                 num_opponents: int, phase: str) -> float:
        """计算期望值"""
        # 简化的期望值计算
        if pot_odds == float('inf'):
            return hand_strength
        
        # 考虑对手数量的影响
        opponent_factor = 1.0 / (1 + (num_opponents - 1) * 0.3)
        
        # 阶段调整
        phase_factor = 1.0
        if phase == 'preflop':
            phase_factor = 0.8
        elif phase == 'river':
            phase_factor = 1.2
        
        ev = hand_strength * pot_odds * opponent_factor * phase_factor
        return ev
    
    def _get_position_factor(self, position: str, num_players: int) -> float:
        """获取位置调整因子"""
        if num_players <= 2:
            # heads-up
            if position in ['late', 'button']:
                return 1.2
            else:
                return 0.9
        
        position_factors = {
            'late': 1.15,
            'middle': 1.0,
            'early': 0.85,
            'small_blind': 0.8,
            'big_blind': 0.9,
            'button': 1.2
        }
        
        return position_factors.get(position, 1.0)
    
    def _get_opponent_adjustment_factor(self, game_state: Dict) -> float:
        """获取对手调整因子"""
        # 分析对手的平均松紧程度
        opponents = []
        current_player = game_state.get('current_player')
        players = game_state.get('players', {})
        
        for player_id, player_info in players.items():
            if (player_id != current_player and 
                player_info.get('state') == 'active' and
                player_id in self.opponent_stats):
                vpip = self.opponent_stats[player_id]['vpip']
                if vpip > 0:
                    opponents.append(vpip)
        
        if not opponents:
            return 1.0
        
        avg_vpip = sum(opponents) / len(opponents)
        
        # 对手越松，我们越紧；对手越紧，我们越松
        if avg_vpip > 0.4:  # 松的对手
            return 0.9
        elif avg_vpip < 0.2:  # 紧的对手
            return 1.1
        else:
            return 1.0
    
    def _calculate_strategic_raise_amount(self, game_state: Dict, raise_type: str, 
                                        hand_strength: float, position: str) -> int:
        """计算战略性加注金额"""
        pot = game_state.get('pot', 0)
        current_bet = game_state.get('current_bet', 0)
        players = game_state.get('players', {})
        current_player = game_state.get('current_player')
        
        # 基础倍数
        base_multiplier = {
            'value_bet': 0.75,
            'bluff': 0.6,
            'protection': 0.8
        }.get(raise_type, 0.7)
        
        # 位置调整
        if position in ['late', 'button']:
            base_multiplier *= 1.1
        elif position in ['early', 'small_blind']:
            base_multiplier *= 0.9
        
        # 手牌强度调整
        if hand_strength > 0.8:
            base_multiplier *= 1.2
        elif hand_strength < 0.4:
            base_multiplier *= 0.8
        
        # 对手数量调整
        active_players = len([p for p in players.values() if p.get('state') == 'active'])
        if active_players == 2:
            base_multiplier *= 0.8  # heads-up时更小的下注
        elif active_players >= 5:
            base_multiplier *= 1.1  # 多人池时更大的下注
        
        raise_amount = int(pot * base_multiplier)
        
        # 确保最小加注额
        min_raise = max(current_bet * 2, current_bet + 10)
        max_raise = game_state.get('players', {}).get(current_player, {}).get('chips', 0) + current_bet
        
        return max(min_raise, min(raise_amount, max_raise))
    
    def _should_bluff_strategically(self, game_state: Dict, phase: str) -> bool:
        """战略性虚张声势判断"""
        # 基础虚张声势概率
        base_chance = self.bluff_frequency
        
        # 阶段调整
        if phase == 'preflop':
            base_chance *= 0.8  # 翻牌前较少虚张声势
        elif phase == 'river':
            base_chance *= 1.5  # 河牌更多虚张声势
        
        # 对手调整
        opponents_fold_to_bet = []
        current_player = game_state.get('current_player')
        players = game_state.get('players', {})
        
        for player_id, player_info in players.items():
            if (player_id != current_player and 
                player_info.get('state') == 'active' and
                player_id in self.opponent_stats):
                fold_rate = self.opponent_stats[player_id]['fold_to_bet']
                if fold_rate > 0:
                    opponents_fold_to_bet.append(fold_rate)
        
        if opponents_fold_to_bet:
            avg_fold_rate = sum(opponents_fold_to_bet) / len(opponents_fold_to_bet)
            if avg_fold_rate > 0.6:  # 对手容易弃牌
                base_chance *= 1.5
            elif avg_fold_rate < 0.3:  # 对手不容易弃牌
                base_chance *= 0.5
        
        return random.random() < base_chance
    
    def _update_opponent_stats(self, game_state: Dict):
        """更新对手统计数据"""
        try:
            current_player = game_state.get('current_player')
            players = game_state.get('players', {})
            
            # 更新当前会话手牌数
            self.current_session_hands += 1
            
            # 记录所有活跃玩家
            self.table_players = [pid for pid in players.keys() 
                                if players[pid].get('state') == 'active']
            
            # 这里可以添加更多复杂的对手建模逻辑
            # 由于游戏状态信息有限，我们主要依赖历史数据
            
        except Exception:
            pass  # 安全处理统计更新错误
    
    def _safe_fold(self, valid_actions: List[Dict]) -> Dict[str, Any]:
        """安全弃牌"""
        fold_action = next((a for a in valid_actions if a.get('action') == 'fold'), None)
        if fold_action:
            return fold_action
        return {"action": "fold"}
    
    def reset(self):
        """重置AI状态"""
        self.opponent_stats.clear()
        self.hand_history.clear()
        self.current_session_hands = 0
        self.table_players = []
        self._hand_strength_cache.clear()


# ============================================================================
# 测试代码
# ============================================================================
if __name__ == "__main__":
    # 创建AI实例
    ai = QwenCodeAI()
    
    # 测试AI信息
    print("AI Info:", ai.get_info())
    
    # 测试决策
    test_game_state = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 20},
            {'action': 'raise', 'min_amount': 40, 'max_amount': 200}
        ],
        'players': {
            'player1': {
                'hole_cards': ['As', 'Kh'],
                'chips': 1000,
                'current_bet': 10,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': [],
        'pot': 30,
        'current_bet': 20,
        'phase': 'preflop',
        'dealer_index': 0
    }
    
    decision = ai.make_move(test_game_state)
    print("Decision:", decision)
    
    # 测试手牌评估
    strength = ai.evaluate_hand_strength(['As', 'Kh'], [])
    print(f"Hand strength: {strength:.3f}")
    
    # 测试不同手牌
    test_hands = [['As', 'Ad'], ['Ks', 'Qs'], ['7h', '2c'], ['Js', 'Ts']]
    for hand in test_hands:
        strength = ai.evaluate_hand_strength(hand, [])
        print(f"Hand {hand}: {strength:.3f}")