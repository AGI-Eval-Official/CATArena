#!/usr/bin/env python3
"""
Comprehensive test for Qwen Hold'em AI
"""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ai_player import QwenHoldemAI

def test_various_scenarios():
    """Test AI with various game scenarios"""
    ai = QwenHoldemAI()
    
    print("=== Testing Qwen Hold'em AI ===\n")
    
    # Test 1: Preflop with premium hand
    print("Test 1: Preflop with AA")
    game_state1 = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 10},
            {'action': 'raise', 'min_amount': 20, 'max_amount': 1000}
        ],
        'players': {
            'player1': {
                'hole_cards': ['As', 'Ah'],
                'chips': 1000,
                'current_bet': 0,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': [],
        'pot': 10,
        'current_bet': 10,
        'phase': 'preflop',
        'dealer_index': 0
    }
    decision1 = ai.make_move(game_state1)
    print(f"Decision: {decision1}\n")
    
    # Test 2: Flop with strong hand
    print("Test 2: Flop with top pair")
    game_state2 = {
        'valid_actions': [
            {'action': 'check'},
            {'action': 'bet', 'min_amount': 20, 'max_amount': 500}
        ],
        'players': {
            'player1': {
                'hole_cards': ['As', 'Kh'],
                'chips': 990,
                'current_bet': 10,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': ['Ad', '7c', '2h'],
        'pot': 20,
        'current_bet': 10,
        'phase': 'flop',
        'dealer_index': 0
    }
    decision2 = ai.make_move(game_state2)
    print(f"Decision: {decision2}\n")
    
    # Test 3: River with weak hand
    print("Test 3: River with weak hand")
    game_state3 = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 50}
        ],
        'players': {
            'player1': {
                'hole_cards': ['2s', '3h'],
                'chips': 900,
                'current_bet': 0,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': ['Kd', 'Qc', 'Jh', '10s', '9d'],
        'pot': 100,
        'current_bet': 50,
        'phase': 'river',
        'dealer_index': 0
    }
    decision3 = ai.make_move(game_state3)
    print(f"Decision: {decision3}\n")
    
    # Test 4: Late position steal attempt
    print("Test 4: Late position steal attempt")
    game_state4 = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 5},
            {'action': 'raise', 'min_amount': 10, 'max_amount': 1000}
        ],
        'players': {
            'player1': {
                'hole_cards': ['7s', '8h'],
                'chips': 1000,
                'current_bet': 0,
                'state': 'active'
            },
            'player2': {
                'hole_cards': [],
                'chips': 995,
                'current_bet': 5,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': [],
        'pot': 10,
        'current_bet': 5,
        'phase': 'preflop',
        'dealer_index': 1  # We are in late position
    }
    decision4 = ai.make_move(game_state4)
    print(f"Decision: {decision4}\n")
    
    print("=== All tests completed ===")

if __name__ == "__main__":
    test_various_scenarios()