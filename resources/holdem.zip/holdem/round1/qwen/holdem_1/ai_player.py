"""
Qwen德州扑克AI - Traditional模式
============================================================================
这是一个高级的德州扑克AI实现，包含以下核心功能：
1. 精确的手牌评估和强度计算
2. 位置感知策略
3. 底池赔率和期望值计算
4. 动态对手建模
5. 智能虚张声势
6. 风险管理和资金管理

该AI采用紧凶策略（TAG），但在后期位置会变得更加激进。
============================================================================
"""

import random
import math
import logging
from typing import Dict, List, Any, Tuple, Optional
from collections import defaultdict, Counter
from itertools import combinations

# 导入游戏引擎的核心逻辑
from GamesEnv.games.holdem.engines.poker_logic import (
    create_card_from_string, HandEvaluator, PokerHand, HandRank
)

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('qwen_holdem_ai')


class QwenHoldemAI:
    """
    Qwen德州扑克AI - Traditional模式
    
    这个类实现了一个高级的德州扑克AI，具有完整的战略决策能力。
    """
    
    def __init__(self):
        """
        初始化AI
        """
        # ====================================================================
        # 基本信息 (必需) - 与ai_config.yaml保持一致
        # ====================================================================
        self.ai_id = "Qwen_1"
        self.name = "Qwen Hold'em AI"
        self.version = "1.0"
        self.description = "A strategic Texas Hold'em AI developed by Qwen"
        
        # ====================================================================
        # 策略参数
        # ====================================================================
        self.aggression_level = 0.7      # 激进程度
        self.bluff_frequency = 0.18      # 虚张声势频率
        self.tight_aggressive = True     # 紧凶策略
        
        # 手牌强度阈值
        self.very_strong_threshold = 0.85
        self.strong_threshold = 0.65
        self.playable_threshold = 0.35
        self.weak_threshold = 0.20
        
        # ====================================================================
        # 游戏状态追踪
        # ====================================================================
        self.opponent_stats = defaultdict(lambda: {
            'hands_played': 0,
            'vpip': 0,  # Voluntarily Put money In Pot
            'pfr': 0,   # Pre-Flop Raise
            'aggression': 0,
            'fold_to_bet': 0,
            'recent_actions': [],
            'betting_patterns': []
        })
        self.hand_history = []
        self.current_hand_actions = []
        self.game_phase_stats = defaultdict(int)
        
        logger.info(f"AI {self.name} initialized successfully")
    
    def get_info(self) -> Dict[str, Any]:
        """
        获取AI信息 (必需方法)
        """
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "capabilities": [
                "hand_evaluation",
                "decision_making", 
                "position_awareness",
                "pot_odds_calculation",
                "bluffing",
                "opponent_modeling"
            ]
        }
    
    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        核心决策方法 (必需方法)
        """
        try:
            # 验证输入和获取基本信息
            valid_actions = game_state.get('valid_actions', [])
            if not valid_actions:
                logger.warning("No valid actions available, folding")
                return {"action": "fold"}
            
            current_player = game_state.get('current_player')
            players = game_state.get('players', {})
            
            if current_player not in players:
                logger.error(f"Current player {current_player} not found in players")
                return self._safe_fold(valid_actions)
            
            player_info = players[current_player]
            hole_cards = player_info.get('hole_cards', [])
            my_chips = player_info.get('chips', 0)
            my_current_bet = player_info.get('current_bet', 0)
            
            community_cards = game_state.get('community_cards', [])
            pot = game_state.get('pot', 0)
            current_bet = game_state.get('current_bet', 0)
            phase = game_state.get('phase', 'preflop')
            dealer_index = game_state.get('dealer_index', 0)
            
            # 更新统计信息
            self._update_opponent_stats(game_state)
            
            # 解析可用行动
            available_actions = self._parse_valid_actions(valid_actions)
            
            # 手牌评估
            hand_strength = self.evaluate_hand_strength(hole_cards, community_cards)
            
            # 位置分析
            position = self.analyze_position(current_player, players, dealer_index)
            
            # 底池赔率计算
            bet_to_call = current_bet - my_current_bet
            pot_odds = self.calculate_pot_odds(pot, bet_to_call) if bet_to_call > 0 else float('inf')
            
            # 计算期望值
            expected_value = self._calculate_expected_value(hand_strength, pot_odds, position, phase)
            
            # 决策逻辑
            decision = self._make_strategic_decision(
                hand_strength=hand_strength,
                expected_value=expected_value,
                position=position,
                pot_odds=pot_odds,
                available_actions=available_actions,
                game_state=game_state,
                phase=phase
            )
            
            # 记录决策
            self.current_hand_actions.append({
                'decision': decision,
                'hand_strength': hand_strength,
                'expected_value': expected_value,
                'position': position,
                'phase': phase
            })
            
            logger.info(f"Decision: {decision}, Hand: {hole_cards}, Strength: {hand_strength:.3f}, EV: {expected_value:.3f}, Position: {position}, Phase: {phase}")
            return decision
            
        except Exception as e:
            logger.error(f"Error in make_move: {e}")
            return self._safe_fold(valid_actions)
    
    def _parse_valid_actions(self, valid_actions: List[Dict]) -> Dict[str, Optional[Dict]]:
        """
        解析可用行动
        """
        actions = {
            'fold': None,
            'check': None,
            'call': None,
            'raise': None,
            'all_in': None
        }
        
        for action in valid_actions:
            action_type = action.get('action')
            if action_type in actions:
                actions[action_type] = action
                
        return actions
    
    def _make_strategic_decision(self, hand_strength: float, expected_value: float, 
                                position: str, pot_odds: float, available_actions: Dict, 
                                game_state: Dict, phase: str) -> Dict[str, Any]:
        """
        高级战略决策逻辑
        """
        current_player = game_state.get('current_player')
        players = game_state.get('players', {})
        player_info = players[current_player]
        my_chips = player_info.get('chips', 0)
        my_current_bet = player_info.get('current_bet', 0)
        current_bet = game_state.get('current_bet', 0)
        pot = game_state.get('pot', 0)
        
        # 获取对手信息
        opponents = [pid for pid, pinfo in players.items() 
                    if pid != current_player and pinfo.get('state') == 'active']
        opponent_count = len(opponents)
        
        # 非常强的手牌 - 总是激进
        if hand_strength >= self.very_strong_threshold:
            if available_actions['raise']:
                # 对于超强手牌，根据对手数量调整下注大小
                if opponent_count <= 1:
                    # 头对头时下注较小以诱导对手跟注
                    amount = min(int(pot * 0.5), my_chips + my_current_bet)
                else:
                    # 多人局时下注较大以减少对手数量
                    amount = min(int(pot * 0.8), my_chips + my_current_bet)
                return {"action": "raise", "amount": max(amount, current_bet * 2)}
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        # 强手牌 - 价值下注和保护
        elif hand_strength >= self.strong_threshold:
            if phase == 'preflop':
                # 翻牌前强手牌总是加注或跟注大额加注
                if available_actions['raise']:
                    amount = min(int(pot * 0.7), my_chips + my_current_bet)
                    return {"action": "raise", "amount": max(amount, current_bet * 2)}
                elif available_actions['call']:
                    return available_actions['call']
            else:
                # 翻牌后，根据公共牌面决定
                if self._is_dangerous_board(game_state.get('community_cards', [])) and opponent_count > 1:
                    # 危险牌面且多人时保护性下注
                    if available_actions['raise']:
                        amount = min(int(pot * 0.6), my_chips + my_current_bet)
                        return {"action": "raise", "amount": max(amount, current_bet * 2)}
                elif available_actions['raise'] and (position == 'late' or pot_odds < 2.5):
                    # 安全牌面或有利位置时价值下注
                    amount = min(int(pot * 0.5), my_chips + my_current_bet)
                    return {"action": "raise", "amount": max(amount, current_bet * 2)}
                elif available_actions['call'] and pot_odds > 1.5:
                    return available_actions['call']
                elif available_actions['check']:
                    return available_actions['check']
        
        # 可玩手牌 - 根据情况灵活应对
        elif hand_strength >= self.playable_threshold:
            if available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 3.0:
                # 有利的底池赔率时跟注
                return available_actions['call']
            elif (position == 'late' and opponent_count <= 2 and 
                  self._should_bluff_late_position(opponents) and available_actions['raise']):
                # 后期位置对抗少数对手时虚张声势
                amount = min(int(pot * 0.4), my_chips + my_current_bet)
                return {"action": "raise", "amount": max(amount, current_bet * 2)}
            elif (phase in ['turn', 'river'] and hand_strength >= 0.45 and 
                  available_actions['raise'] and pot_odds < 4.0):
                # 转牌/河牌阶段中等强度手牌进行半诈唬
                amount = min(int(pot * 0.5), my_chips + my_current_bet)
                return {"action": "raise", "amount": max(amount, current_bet * 2)}
        
        # 弱手牌处理
        else:
            if available_actions['check']:
                return available_actions['check']
            elif (available_actions['call'] and pot_odds > 5.0 and 
                  phase == 'flop' and len(game_state.get('community_cards', [])) == 3):
                # 翻牌阶段超好的底池赔率时可以投机
                return available_actions['call']
            elif (phase == 'preflop' and hand_strength >= 0.15 and 
                  position == 'late' and opponent_count <= 1 and available_actions['call']):
                # 后期位置对抗单个对手时可以用较弱手牌偷盲
                return available_actions['call']
        
        # 默认弃牌
        if available_actions['fold']:
            return available_actions['fold']
        
        # 后备选择
        for action_name in ['check', 'call', 'raise']:
            if available_actions[action_name]:
                if action_name == 'raise':
                    min_amount = available_actions['raise'].get('min_amount', current_bet * 2)
                    return {"action": "raise", "amount": min_amount}
                return available_actions[action_name]
        
        return {"action": "fold"}
    
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        精确评估手牌强度
        
        使用蒙特卡洛模拟来估算胜率
        """
        if len(hole_cards) != 2:
            return 0.0
        
        if len(community_cards) == 0:
            # 翻牌前使用预计算的强度表
            return self._evaluate_preflop_strength(hole_cards)
        else:
            # 翻牌后使用蒙特卡洛模拟
            return self._monte_carlo_hand_strength(hole_cards, community_cards)
    
    def _evaluate_preflop_strength(self, hole_cards: List[str]) -> float:
        """
        评估翻牌前手牌强度
        
        使用德州扑克起手牌强度排名
        """
        card1, card2 = hole_cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(rank1, 0)
        val2 = rank_values.get(rank2, 0)
        
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        is_suited = (suit1 == suit2)
        is_pair = (val1 == val2)
        gap = high_card - low_card
        
        # 基础强度计算
        base_strength = 0.0
        
        if is_pair:
            # 对子强度
            if high_card >= 13:  # AA, KK
                base_strength = 0.95
            elif high_card >= 12:  # QQ
                base_strength = 0.90
            elif high_card >= 11:  # JJ
                base_strength = 0.85
            elif high_card >= 10:  # TT
                base_strength = 0.80
            elif high_card >= 9:   # 99
                base_strength = 0.70
            elif high_card >= 8:   # 88
                base_strength = 0.65
            elif high_card >= 7:   # 77
                base_strength = 0.60
            elif high_card >= 6:   # 66
                base_strength = 0.55
            elif high_card >= 5:   # 55
                base_strength = 0.50
            elif high_card >= 4:   # 44
                base_strength = 0.45
            elif high_card >= 3:   # 33
                base_strength = 0.40
            else:  # 22
                base_strength = 0.35
        else:
            # 非对子强度
            if high_card == 14:  # A
                if low_card >= 13:  # AK
                    base_strength = 0.95 if is_suited else 0.90
                elif low_card >= 12:  # AQ
                    base_strength = 0.90 if is_suited else 0.85
                elif low_card >= 11:  # AJ
                    base_strength = 0.85 if is_suited else 0.80
                elif low_card >= 10:  # AT
                    base_strength = 0.80 if is_suited else 0.75
                elif low_card >= 9:   # A9
                    base_strength = 0.70 if is_suited else 0.60
                elif low_card >= 8:   # A8
                    base_strength = 0.65 if is_suited else 0.55
                elif low_card >= 7:   # A7
                    base_strength = 0.60 if is_suited else 0.50
                else:
                    base_strength = 0.55 if is_suited else 0.45
            elif high_card == 13:  # K
                if low_card >= 12:  # KQ
                    base_strength = 0.85 if is_suited else 0.80
                elif low_card >= 11:  # KJ
                    base_strength = 0.80 if is_suited else 0.75
                elif low_card >= 10:  # KT
                    base_strength = 0.75 if is_suited else 0.70
                elif low_card >= 9:   # K9
                    base_strength = 0.65 if is_suited else 0.55
                else:
                    base_strength = 0.50 if is_suited else 0.40
            elif high_card == 12:  # Q
                if low_card >= 11:  # QJ
                    base_strength = 0.75 if is_suited else 0.70
                elif low_card >= 10:  # QT
                    base_strength = 0.70 if is_suited else 0.65
                elif low_card >= 9:   # Q9
                    base_strength = 0.60 if is_suited else 0.50
                else:
                    base_strength = 0.45 if is_suited else 0.35
            elif high_card == 11:  # J
                if low_card >= 10:  # JT
                    base_strength = 0.65 if is_suited else 0.60
                elif low_card >= 9:   # J9
                    base_strength = 0.55 if is_suited else 0.45
                else:
                    base_strength = 0.40 if is_suited else 0.30
            else:
                # 中小牌
                base_strength = (high_card + low_card) / 28.0
                if is_suited:
                    base_strength += 0.1
                if gap <= 1:
                    base_strength += 0.08
                elif gap <= 2:
                    base_strength += 0.05
                elif gap <= 3:
                    base_strength += 0.02
        
        return min(base_strength, 0.98)
    
    def _monte_carlo_hand_strength(self, hole_cards: List[str], community_cards: List[str], 
                                  simulations: int = 1000) -> float:
        """
        使用蒙特卡洛模拟评估手牌强度
        
        这是一个简化的版本，实际应用中可能需要更多优化
        """
        try:
            from GamesEnv.games.holdem.engines.poker_logic import PokerDeck
            
            # 创建标准牌组
            deck = PokerDeck("standard")
            
            # 移除已知的牌
            known_cards = hole_cards + community_cards
            known_card_objects = []
            for card_str in known_cards:
                card_obj = create_card_from_string(card_str)
                known_card_objects.append(card_obj)
            
            # 从牌组中移除已知牌
            deck.cards = [card for card in deck.cards if str(card) not in known_cards]
            
            wins = 0
            total_simulations = min(simulations, len(deck.cards) // 2)
            
            if total_simulations <= 0:
                # 如果没有足够的牌进行模拟，使用简化评估
                return self._simple_postflop_evaluation(hole_cards, community_cards)
            
            # 转换我们的手牌为Card对象
            our_hole_cards = [create_card_from_string(card) for card in hole_cards]
            our_community_cards = [create_card_from_string(card) for card in community_cards]
            
            for _ in range(total_simulations):
                # 洗牌并发牌
                deck.shuffle()
                
                # 发剩余的公共牌（如果需要）
                remaining_community_needed = 5 - len(community_cards)
                additional_community = deck.deal_cards(remaining_community_needed)
                all_community = our_community_cards + additional_community
                
                # 发对手手牌
                opponent_hole = deck.deal_cards(2)
                if len(opponent_hole) != 2:
                    continue
                
                # 评估手牌
                our_full_hand = our_hole_cards + all_community
                opponent_full_hand = opponent_hole + all_community
                
                our_evaluated = HandEvaluator.evaluate_hand(our_full_hand)
                opponent_evaluated = HandEvaluator.evaluate_hand(opponent_full_hand)
                
                if our_evaluated > opponent_evaluated:
                    wins += 1
                elif our_evaluated == opponent_evaluated:
                    wins += 0.5  # 平局算半胜
            
            return wins / total_simulations if total_simulations > 0 else 0.0
            
        except Exception as e:
            logger.warning(f"Monte Carlo simulation failed: {e}, using simple evaluation")
            return self._simple_postflop_evaluation(hole_cards, community_cards)
    
    def _simple_postflop_evaluation(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        简化的翻牌后手牌评估
        """
        try:
            all_cards = hole_cards + community_cards
            card_objects = [create_card_from_string(card) for card in all_cards]
            
            if len(card_objects) >= 5:
                hand = HandEvaluator.evaluate_hand(card_objects)
                rank_to_strength = {
                    HandRank.ROYAL_FLUSH: 1.0,
                    HandRank.STRAIGHT_FLUSH: 0.95,
                    HandRank.FOUR_OF_A_KIND: 0.90,
                    HandRank.FULL_HOUSE: 0.85,
                    HandRank.FLUSH: 0.75,
                    HandRank.STRAIGHT: 0.65,
                    HandRank.THREE_OF_A_KIND: 0.55,
                    HandRank.TWO_PAIR: 0.45,
                    HandRank.PAIR: 0.35,
                    HandRank.HIGH_CARD: 0.20
                }
                base_strength = rank_to_strength.get(hand.rank, 0.2)
                
                # 根据踢脚和其他因素微调
                if hand.rank == HandRank.PAIR:
                    # 一对时，高对更强
                    pair_rank = hand.rank_values[0]
                    if pair_rank >= 12:  # QQ+
                        base_strength += 0.1
                    elif pair_rank >= 10:  # TT-JJ
                        base_strength += 0.05
                
                return min(base_strength, 0.98)
            else:
                return self._evaluate_preflop_strength(hole_cards) * 0.7
                
        except Exception as e:
            logger.warning(f"Simple postflop evaluation failed: {e}")
            return 0.2
    
    def analyze_position(self, current_player: str, players: Dict, dealer_index: int) -> str:
        """
        分析玩家位置
        """
        active_players = [pid for pid, pinfo in players.items() 
                         if pinfo.get('state') == 'active']
        
        if current_player not in active_players:
            return 'unknown'
        
        player_count = len(active_players)
        current_index = active_players.index(current_player)
        
        # 找到庄家在活跃玩家中的位置
        dealer_pid = list(players.keys())[dealer_index % len(players)]
        if dealer_pid in active_players:
            dealer_active_index = active_players.index(dealer_pid)
        else:
            # 如果庄家不活跃，找到下一个活跃的庄家
            dealer_active_index = 0
        
        # 计算相对于庄家的位置
        position_from_dealer = (current_index - dealer_active_index) % player_count
        
        if player_count <= 2:
            return 'heads_up'
        elif player_count <= 3:
            return 'late' if position_from_dealer >= player_count - 1 else 'early'
        elif player_count <= 6:
            if position_from_dealer == 0:
                return 'small_blind'
            elif position_from_dealer == 1:
                return 'big_blind'
            elif position_from_dealer <= 2:
                return 'early'
            elif position_from_dealer <= player_count - 2:
                return 'middle'
            else:
                return 'late'
        else:
            if position_from_dealer <= 1:
                return 'blind' if position_from_dealer <= 1 else 'early'
            elif position_from_dealer <= 3:
                return 'early'
            elif position_from_dealer <= player_count - 2:
                return 'middle'
            else:
                return 'late'
    
    def calculate_pot_odds(self, pot_size: int, bet_to_call: int) -> float:
        """
        计算底池赔率
        """
        if bet_to_call <= 0:
            return float('inf')
        return pot_size / bet_to_call
    
    def _calculate_expected_value(self, hand_strength: float, pot_odds: float, 
                                 position: str, phase: str) -> float:
        """
        计算期望值
        """
        # 基础EV基于手牌强度和底池赔率
        if pot_odds == float('inf'):
            # 无需跟注时，EV就是手牌强度
            base_ev = hand_strength
        else:
            # EV = P(win) * pot_size - P(lose) * bet_to_call
            # 简化为：EV = hand_strength * (1 + pot_odds) - (1 - hand_strength)
            base_ev = hand_strength * (1 + pot_odds) - (1 - hand_strength)
        
        # 位置调整
        position_multiplier = {
            'late': 1.1,
            'middle': 1.0,
            'early': 0.9,
            'blind': 0.85,
            'heads_up': 1.05
        }.get(position, 1.0)
        
        # 阶段调整
        phase_multiplier = {
            'preflop': 0.8,
            'flop': 1.0,
            'turn': 1.1,
            'river': 1.2
        }.get(phase, 1.0)
        
        adjusted_ev = base_ev * position_multiplier * phase_multiplier
        
        return adjusted_ev
    
    def _is_dangerous_board(self, community_cards: List[str]) -> bool:
        """
        判断公共牌面是否危险
        """
        if len(community_cards) < 3:
            return False
        
        # 转换为Card对象
        try:
            cards = [create_card_from_string(card) for card in community_cards]
            
            # 检查同花听牌
            suits = [card.suit for card in cards]
            suit_counts = Counter(suits)
            if any(count >= 3 for count in suit_counts.values()):
                return True
            
            # 检查顺子听牌
            ranks = sorted([card.rank.numeric_value for card in cards])
            if len(set(ranks)) >= 3:
                # 检查是否有连续的牌
                for i in range(len(ranks) - 2):
                    if ranks[i+2] - ranks[i] <= 4:
                        return True
            
            # 检查高牌面（容易被统治）
            high_ranks = [r for r in ranks if r >= 12]  # Q, K, A
            if len(high_ranks) >= 2:
                return True
                
        except Exception as e:
            logger.warning(f"Board danger assessment failed: {e}")
        
        return False
    
    def _should_bluff_late_position(self, opponents: List[str]) -> bool:
        """
        判断是否应该在后期位置虚张声势
        """
        # 基础虚张声势概率
        bluff_chance = self.bluff_frequency
        
        # 根据对手类型调整
        for opponent in opponents:
            stats = self.opponent_stats[opponent]
            if stats['hands_played'] > 10:
                # 对抗紧弱玩家时增加虚张声势频率
                if stats['vpip'] < 0.3 and stats['aggression'] < 0.5:
                    bluff_chance *= 1.5
                # 对抗松凶玩家时减少虚张声势频率
                elif stats['vpip'] > 0.5 and stats['aggression'] > 0.7:
                    bluff_chance *= 0.5
        
        return random.random() < bluff_chance
    
    def _update_opponent_stats(self, game_state: Dict[str, Any]):
        """
        更新对手统计数据
        """
        try:
            current_player = game_state.get('current_player')
            players = game_state.get('players', {})
            phase = game_state.get('phase', 'preflop')
            
            # 这里可以添加更复杂的对手建模逻辑
            # 目前只做简单的记录
            
        except Exception as e:
            logger.warning(f"Failed to update opponent stats: {e}")
    
    def _parse_card(self, card: str) -> Tuple[str, str]:
        """
        解析牌面
        """
        if len(card) == 2:
            return card[0], card[1]
        elif len(card) == 3 and card[:2] == '10':
            return '10', card[2]
        else:
            return card[:-1], card[-1]
    
    def _safe_fold(self, valid_actions: List[Dict]) -> Dict[str, Any]:
        """
        安全弃牌
        """
        fold_action = next((a for a in valid_actions if a.get('action') == 'fold'), None)
        if fold_action:
            return fold_action
        return {"action": "fold"}
    
    def reset(self):
        """
        重置AI状态
        """
        self.opponent_stats.clear()
        self.hand_history.append(self.current_hand_actions.copy())
        self.current_hand_actions.clear()
        logger.info(f"AI {self.name} reset successfully")
    
    def get_thinking_time(self) -> float:
        """
        获取思考时间
        """
        return random.uniform(0.3, 2.0)


# ============================================================================
# 测试代码
# ============================================================================
if __name__ == "__main__":
    # 创建AI实例
    ai = QwenHoldemAI()
    
    # 测试AI信息
    print("AI Info:", ai.get_info())
    
    # 测试决策
    test_game_state = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 20},
            {'action': 'raise', 'min_amount': 40, 'max_amount': 200}
        ],
        'players': {
            'player1': {
                'hole_cards': ['As', 'Kh'],
                'chips': 1000,
                'current_bet': 10,
                'state': 'active'
            },
            'player2': {
                'hole_cards': ['Qd', 'Js'],
                'chips': 980,
                'current_bet': 20,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': [],
        'pot': 30,
        'current_bet': 20,
        'phase': 'preflop',
        'dealer_index': 0
    }
    
    decision = ai.make_move(test_game_state)
    print("Decision:", decision)
    
    # 测试手牌评估
    strength = ai.evaluate_hand_strength(['As', 'Kh'], [])
    print(f"Preflop Hand strength: {strength:.3f}")
    
    strength2 = ai.evaluate_hand_strength(['As', 'Kh'], ['Qd', 'Jc', '10s'])
    print(f"Flop Hand strength: {strength2:.3f}")