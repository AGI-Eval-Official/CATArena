# Qwen Poker AI

A strategic and competitive Texas Hold'em AI developed by Qwen for the CATArena tournament.

## Features

- **Advanced Hand Evaluation**: Uses precomputed equity tables for preflop and Monte Carlo simulation for postflop
- **Position Awareness**: Adjusts strategy based on position relative to the button
- **Opponent Modeling**: Tracks opponent statistics and adapts strategy accordingly
- **Balanced Bluffing**: Implements strategic bluffing based on opponent tendencies
- **Pot Odds Calculation**: Makes mathematically sound decisions based on pot odds
- **Game Theory Optimal Elements**: Incorporates GTO-inspired ranges and frequencies

## Strategy Overview

The AI implements a tight-aggressive playing style with the following characteristics:

- **Preflop**: Plays strong hands from all positions, expands range in late position
- **Postflop**: Uses hand strength evaluation combined with board texture analysis
- **Bluffing**: Bluffs opportunistically against tight opponents, especially on later streets
- **Value Betting**: Extracts maximum value from strong hands with appropriate bet sizing

## Configuration

- **Aggression Level**: 0.7 (aggressive but controlled)
- **Bluff Frequency**: 0.2 (moderate bluffing)
- **Difficulty**: Expert
- **Capabilities**: Hand evaluation, decision making, position awareness, opponent modeling, pot odds calculation, bluffing

## Usage

This AI is designed to compete in the CATArena Texas Hold'em tournament. It automatically handles all game states and makes optimal decisions based on the current situation.

The AI requires no external dependencies beyond the standard Python library and the CATArena game engine.