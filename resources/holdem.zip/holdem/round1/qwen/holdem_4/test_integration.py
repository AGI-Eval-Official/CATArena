#!/usr/bin/env python3
"""
Integration test for Qwen Hold'em AI
This test verifies that the AI implements the required interface correctly
and can handle various game states.
"""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_ai_interface():
    """Test that the AI implements the required interface"""
    try:
        from ai_player import QwenHoldemAI
        
        # Create AI instance
        ai = QwenHoldemAI()
        
        # Test get_info method
        info = ai.get_info()
        required_fields = ['ai_id', 'name', 'version', 'description']
        for field in required_fields:
            assert field in info, f"Missing required field: {field}"
        
        assert info['ai_id'] == 'qwen_holdem_ai', f"Wrong ai_id: {info['ai_id']}"
        print("✓ get_info() method works correctly")
        
        # Test make_move method with various game states
        
        # Test 1: Preflop with strong hand
        game_state_1 = {
            'valid_actions': [
                {'action': 'fold'},
                {'action': 'call', 'amount': 10},
                {'action': 'raise', 'min_amount': 20, 'max_amount': 100}
            ],
            'players': {
                'player1': {
                    'hole_cards': ['As', 'Kh'],
                    'chips': 1000,
                    'current_bet': 0,
                    'state': 'active'
                }
            },
            'current_player': 'player1',
            'community_cards': [],
            'pot': 10,
            'current_bet': 10,
            'phase': 'preflop',
            'dealer_index': 0
        }
        
        decision_1 = ai.make_move(game_state_1)
        assert 'action' in decision_1, "Decision must contain 'action' field"
        print(f"✓ Preflop decision: {decision_1}")
        
        # Test 2: Postflop with medium hand
        game_state_2 = {
            'valid_actions': [
                {'action': 'check'},
                {'action': 'bet', 'min_amount': 20, 'max_amount': 200},
                {'action': 'fold'}
            ],
            'players': {
                'player1': {
                    'hole_cards': ['Qs', 'Js'],
                    'chips': 800,
                    'current_bet': 0,
                    'state': 'active'
                }
            },
            'current_player': 'player1',
            'community_cards': ['Kd', '10h', '2c'],
            'pot': 50,
            'current_bet': 0,
            'phase': 'flop',
            'dealer_index': 0
        }
        
        decision_2 = ai.make_move(game_state_2)
        assert 'action' in decision_2, "Decision must contain 'action' field"
        print(f"✓ Postflop decision: {decision_2}")
        
        # Test 3: River with weak hand
        game_state_3 = {
            'valid_actions': [
                {'action': 'call', 'amount': 50},
                {'action': 'fold'}
            ],
            'players': {
                'player1': {
                    'hole_cards': ['7s', '2h'],
                    'chips': 500,
                    'current_bet': 0,
                    'state': 'active'
                }
            },
            'current_player': 'player1',
            'community_cards': ['Ah', 'Kd', 'Qc', 'Jh', '10s'],
            'pot': 200,
            'current_bet': 50,
            'phase': 'river',
            'dealer_index': 0
        }
        
        decision_3 = ai.make_move(game_state_3)
        assert 'action' in decision_3, "Decision must contain 'action' field"
        print(f"✓ River decision: {decision_3}")
        
        print("\n✅ All integration tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Integration test failed: {e}")
        return False

if __name__ == "__main__":
    success = test_ai_interface()
    sys.exit(0 if success else 1)