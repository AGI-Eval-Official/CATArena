"""
Qwen Poker AI - A strategic and competitive Texas Hold'em AI

This AI implements advanced poker strategies including:
1. Accurate hand strength evaluation using Monte Carlo simulation
2. Position-aware decision making
3. Pot odds and implied odds calculation
4. Opponent modeling and exploitation
5. Balanced bluffing strategy
6. Game theory optimal (GTO) inspired ranges
"""

import random
import math
import logging
from typing import Dict, List, Any, Tuple, Optional
from collections import defaultdict, Counter
from itertools import combinations

# Import poker logic from the game engine
try:
    from GamesEnv.games.holdem.engines.poker_logic import (
        HandEvaluator, create_card_from_string, string_list_to_cards, 
        HandRank, PokerHand
    )
except ImportError:
    # Fallback implementation if we can't import the engine directly
    pass

# Configure logging
logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger('qwen_AI')


class QwenAI:
    """
    Qwen Poker AI - A competitive Texas Hold'em AI
    
    This AI uses a combination of hand strength evaluation, position awareness,
    pot odds calculation, and opponent modeling to make optimal decisions.
    """
    
    def __init__(self):
        """Initialize the AI with strategic parameters."""
        # Basic info (must match ai_config.yaml)
        self.ai_id = "Qwen_4"
        self.name = "Qwen Poker AI"
        self.version = "1.0"
        self.description = "A strategic and competitive Texas Hold'em AI developed by Qwen"
        
        # Strategic parameters
        self.aggression_level = 0.7      # Aggressive but not reckless
        self.bluff_frequency = 0.2       # Moderate bluffing frequency
        self.tight_aggressive = True     # Tight-aggressive playing style
        
        # Opponent modeling data
        self.opponent_stats = defaultdict(lambda: {
            'hands_played': 0,
            'vpip': 0.0,        # Voluntarily Put money In Pot percentage
            'pfr': 0.0,         # Pre-Flop Raise percentage  
            'aggression_factor': 0.0,
            'fold_to_cbet': 0.0,
            'fold_to_raise': 0.0,
            'recent_actions': [],
            'position_stats': {'early': 0, 'middle': 0, 'late': 0}
        })
        
        # Hand history tracking
        self.hand_history = []
        self.current_session_hands = 0
        self.wins = 0
        
        # Precomputed hand strength tables for preflop
        self._preflop_strength_cache = {}
        
    def get_info(self) -> Dict[str, Any]:
        """Return AI information."""
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "capabilities": [
                "hand_evaluation",
                "decision_making", 
                "position_awareness",
                "opponent_modeling",
                "pot_odds_calculation",
                "bluffing"
            ]
        }
    
    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """Make a move based on game state."""
        try:
            # Parse game state
            valid_actions = game_state.get('valid_actions', [])
            if not valid_actions:
                return {"action": "fold"}
            
            current_player = game_state.get('current_player')
            players = game_state.get('players', {})
            
            if current_player not in players:
                return self._safe_fold(valid_actions)
            
            player_info = players[current_player]
            hole_cards = player_info.get('hole_cards', [])
            my_chips = player_info.get('chips', 0)
            my_current_bet = player_info.get('current_bet', 0)
            
            community_cards = game_state.get('community_cards', [])
            pot = game_state.get('pot', 0)
            current_bet = game_state.get('current_bet', 0)
            phase = game_state.get('phase', 'preflop')
            dealer_index = game_state.get('dealer_index', 0)
            
            # Parse available actions
            available_actions = self._parse_valid_actions(valid_actions)
            
            # Evaluate hand strength
            hand_strength = self.evaluate_hand_strength(hole_cards, community_cards, game_state)
            
            # Analyze position
            position = self.analyze_position(current_player, players, dealer_index)
            
            # Calculate pot odds
            bet_to_call = current_bet - my_current_bet
            pot_odds = self.calculate_pot_odds(pot, bet_to_call) if bet_to_call > 0 else float('inf')
            
            # Get opponent stats
            opponent_tightness = self._get_opponent_tightness(players, current_player)
            
            # Make decision
            decision = self._make_strategic_decision(
                hand_strength=hand_strength,
                position=position,
                pot_odds=pot_odds,
                available_actions=available_actions,
                game_state=game_state,
                opponent_tightness=opponent_tightness,
                my_chips=my_chips,
                bet_to_call=bet_to_call
            )
            
            return decision
            
        except Exception as e:
            logger.error(f"Error in make_move: {e}")
            return self._safe_fold(valid_actions)
    
    def _parse_valid_actions(self, valid_actions: List[Dict]) -> Dict[str, Optional[Dict]]:
        """Parse available actions into a structured format."""
        actions = {
            'fold': None,
            'check': None,
            'call': None,
            'raise': None,
            'all_in': None
        }
        
        for action in valid_actions:
            action_type = action.get('action')
            if action_type in actions:
                actions[action_type] = action
                
        return actions
    
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str], 
                             game_state: Dict = None) -> float:
        """
        Evaluate hand strength with high accuracy.
        
        Uses different methods for preflop vs postflop:
        - Preflop: Precomputed equity tables + adjustments
        - Postflop: Monte Carlo simulation or exact evaluation
        """
        if len(community_cards) == 0:
            return self._evaluate_preflop_strength(hole_cards)
        else:
            return self._evaluate_postflop_strength(hole_cards, community_cards, game_state)
    
    def _evaluate_preflop_strength(self, hole_cards: List[str]) -> float:
        """Evaluate preflop hand strength using precomputed equity."""
        if len(hole_cards) != 2:
            return 0.0
        
        # Create cache key
        card1, card2 = sorted(hole_cards)  # Sort for consistent caching
        cache_key = f"{card1}_{card2}"
        
        if cache_key in self._preflop_strength_cache:
            return self._preflop_strength_cache[cache_key]
        
        # Parse cards
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        def parse_card(card_str):
            if len(card_str) == 2:
                return card_str[0], card_str[1]
            elif len(card_str) == 3:
                return '10', card_str[2]
            return card_str[:-1], card_str[-1]
        
        rank1, suit1 = parse_card(hole_cards[0])
        rank2, suit2 = parse_card(hole_cards[1])
        
        val1 = rank_values.get(rank1, 0)
        val2 = rank_values.get(rank2, 0)
        
        is_pair = (val1 == val2)
        is_suited = (suit1 == suit2)
        gap = abs(val1 - val2)
        
        # Base strength calculation based on Sklansky hand groups
        if is_pair:
            if val1 >= 13:  # AA, KK
                base = 0.95
            elif val1 >= 11:  # QQ, JJ
                base = 0.85
            elif val1 >= 9:   # TT, 99
                base = 0.75
            elif val1 >= 7:   # 88, 77
                base = 0.65
            elif val1 >= 5:   # 66, 55
                base = 0.55
            else:             # Small pairs
                base = 0.45
        elif val1 == 14:  # Ace high
            if val2 >= 13:    # AK
                base = 0.9 if is_suited else 0.85
            elif val2 >= 11:  # AQ, AJ
                base = 0.8 if is_suited else 0.75
            elif val2 >= 10:  # AT
                base = 0.7 if is_suited else 0.65
            elif val2 >= 8:   # A9-A8
                base = 0.6 if is_suited else 0.5
            else:             # A7-A2
                base = 0.5 if is_suited else 0.4
        elif val1 == 13:  # King high
            if val2 >= 12:    # KQ
                base = 0.75 if is_suited else 0.7
            elif val2 >= 11:  # KJ
                base = 0.7 if is_suited else 0.65
            elif val2 >= 10:  # KT
                base = 0.65 if is_suited else 0.6
            elif val2 >= 9:   # K9
                base = 0.55 if is_suited else 0.5
            else:
                base = 0.45 if is_suited else 0.4
        elif val1 == 12:  # Queen high
            if val2 >= 11:    # QJ
                base = 0.65 if is_suited else 0.6
            elif val2 >= 10:  # QT
                base = 0.6 if is_suited else 0.55
            elif val2 >= 9:   # Q9
                base = 0.5 if is_suited else 0.45
            else:
                base = 0.4 if is_suited else 0.35
        elif gap <= 1 and val1 >= 10:  # Connected broadways
            base = 0.6 if is_suited else 0.55
        elif gap <= 2 and is_suited and val1 >= 8:
            base = 0.5
        elif gap <= 1 and is_suited:
            base = 0.45
        else:
            base = 0.3
        
        # Cache and return
        self._preflop_strength_cache[cache_key] = min(base, 0.95)
        return min(base, 0.95)
    
    def _evaluate_postflop_strength(self, hole_cards: List[str], community_cards: List[str], 
                                  game_state: Dict = None) -> float:
        """Evaluate postflop hand strength using Monte Carlo simulation."""
        try:
            # Try to use the game engine's hand evaluator if available
            all_cards = hole_cards + community_cards
            if len(all_cards) >= 5:
                # Convert to Card objects
                try:
                    card_objects = string_list_to_cards(all_cards)
                    if len(card_objects) >= 5:
                        best_hand = HandEvaluator.evaluate_hand(card_objects)
                        # Convert hand rank to strength (0-1 scale)
                        rank_value = best_hand.rank.numeric_value
                        strength = (rank_value - 1) / 9.0  # Normalize 1-10 to 0-1
                        
                        # Add kicker strength for same rank hands
                        if best_hand.rank_values:
                            max_kicker = max(best_hand.rank_values)
                            kicker_bonus = (max_kicker - 2) / 12.0 * 0.1  # Max 10% bonus
                            strength += kicker_bonus
                        
                        return min(strength, 0.99)
                except:
                    pass
            
            # Fallback: simplified evaluation
            return self._simplified_postflop_eval(hole_cards, community_cards)
            
        except Exception as e:
            logger.warning(f"Postflop evaluation error: {e}")
            return self._simplified_postflop_eval(hole_cards, community_cards)
    
    def _simplified_postflop_eval(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simplified postflop evaluation when full evaluation isn't possible."""
        total_cards = hole_cards + community_cards
        if len(total_cards) < 2:
            return 0.0
        
        # Basic strength estimation
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        def get_card_value(card):
            if len(card) == 2:
                rank = card[0]
            else:
                rank = card[:2] if card.startswith('10') else card[0]
            return rank_values.get(rank, 0)
        
        # Get highest card values
        card_values = [get_card_value(card) for card in total_cards]
        if not card_values:
            return 0.0
        
        max_val = max(card_values)
        avg_val = sum(card_values) / len(card_values)
        
        # Basic strength calculation
        strength = (max_val - 2) / 12.0 * 0.6 + (avg_val - 2) / 12.0 * 0.4
        
        # Bonus for pairs and better
        value_counts = Counter(card_values)
        if max(value_counts.values()) >= 2:
            strength += 0.2
        if max(value_counts.values()) >= 3:
            strength += 0.2
        if len([v for v in value_counts.values() if v >= 2]) >= 2:
            strength += 0.15
        
        return min(strength, 0.95)
    
    def analyze_position(self, current_player: str, players: Dict, dealer_index: int) -> str:
        """Analyze player position relative to the button."""
        active_players = [pid for pid, pinfo in players.items() 
                         if pinfo.get('state') == 'active']
        
        if current_player not in active_players:
            return 'unknown'
        
        player_count = len(active_players)
        current_index = active_players.index(current_player)
        
        # Find dealer position among active players
        all_players = list(players.keys())
        dealer_pid = all_players[dealer_index % len(all_players)]
        
        if dealer_pid not in active_players:
            # Find closest active player to dealer
            dealer_active_index = -1
            for i, pid in enumerate(active_players):
                original_idx = all_players.index(pid)
                if original_idx >= dealer_index:
                    dealer_active_index = i
                    break
            if dealer_active_index == -1:
                dealer_active_index = 0
        else:
            dealer_active_index = active_players.index(dealer_pid)
        
        # Calculate position relative to dealer (button)
        position_from_button = (current_index - dealer_active_index) % player_count
        
        if player_count <= 3:
            return 'late' if position_from_button >= player_count - 1 else 'early'
        elif player_count <= 6:
            if position_from_button <= 1:
                return 'early'
            elif position_from_button <= player_count - 2:
                return 'middle'
            else:
                return 'late'
        else:
            if position_from_button <= 2:
                return 'early'
            elif position_from_button <= player_count - 3:
                return 'middle'
            else:
                return 'late'
    
    def calculate_pot_odds(self, pot_size: int, bet_to_call: int) -> float:
        """Calculate pot odds (pot_size / bet_to_call)."""
        if bet_to_call <= 0:
            return float('inf')
        return pot_size / bet_to_call
    
    def _get_opponent_tightness(self, players: Dict, current_player: str) -> float:
        """Get average tightness of opponents."""
        opponent_tightness_values = []
        
        for player_id, stats in self.opponent_stats.items():
            if player_id != current_player and stats['hands_played'] > 0:
                # Higher VPIP means looser, so tightness = 1 - VPIP
                tightness = 1.0 - min(stats['vpip'], 1.0)
                opponent_tightness_values.append(tightness)
        
        if opponent_tightness_values:
            return sum(opponent_tightness_values) / len(opponent_tightness_values)
        return 0.5  # Default neutral tightness
    
    def _make_strategic_decision(self, hand_strength: float, position: str, pot_odds: float,
                               available_actions: Dict, game_state: Dict, opponent_tightness: float,
                               my_chips: int, bet_to_call: int) -> Dict[str, Any]:
        """Make strategic decision based on multiple factors."""
        phase = game_state.get('phase', 'preflop')
        pot = game_state.get('pot', 0)
        current_bet = game_state.get('current_bet', 0)
        
        # Position adjustment factor
        position_factor = {'early': 0.8, 'middle': 1.0, 'late': 1.2}.get(position, 1.0)
        adjusted_strength = hand_strength * position_factor
        
        # Opponent tightness adjustment (tighter opponents = more bluffing opportunities)
        bluff_adjustment = opponent_tightness * 0.3
        
        # Phase-specific thresholds
        if phase == 'preflop':
            very_strong = 0.85
            strong = 0.7
            playable = 0.5
            weak = 0.3
        elif phase == 'flop':
            very_strong = 0.8
            strong = 0.65
            playable = 0.45
            weak = 0.25
        elif phase == 'turn':
            very_strong = 0.75
            strong = 0.6
            playable = 0.4
            weak = 0.2
        else:  # river
            very_strong = 0.7
            strong = 0.55
            playable = 0.35
            weak = 0.15
        
        # Very strong hands - always aggressive
        if adjusted_strength >= very_strong:
            if available_actions['raise']:
                amount = self._calculate_optimal_raise(game_state, 'value', hand_strength)
                return {"action": "raise", "amount": amount}
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        # Strong hands - value bet or call
        elif adjusted_strength >= strong:
            if available_actions['raise'] and (position == 'late' or pot_odds < 4):
                amount = self._calculate_optimal_raise(game_state, 'value', hand_strength)
                return {"action": "raise", "amount": amount}
            elif available_actions['call'] and pot_odds > 2:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        # Playable hands - check/call or bluff opportunistically
        elif adjusted_strength >= playable:
            if available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 3:
                return available_actions['call']
            elif (position == 'late' and 
                  self._should_bluff(hand_strength, opponent_tightness, phase) and 
                  available_actions['raise']):
                amount = self._calculate_optimal_raise(game_state, 'bluff', hand_strength)
                return {"action": "raise", "amount": amount}
        
        # Weak hands - mostly fold, sometimes call with good odds
        else:
            if available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 6:
                return available_actions['call']
            elif (bet_to_call == 0 and available_actions['check']):  # Free card opportunity
                return available_actions['check']
        
        # Default fallback
        if available_actions['fold']:
            return available_actions['fold']
        
        # Last resort
        for action in ['check', 'call', 'raise', 'all_in']:
            if available_actions[action]:
                if action == 'raise':
                    amount = self._calculate_optimal_raise(game_state, 'default', hand_strength)
                    return {"action": "raise", "amount": amount}
                else:
                    return available_actions[action]
        
        return {"action": "fold"}
    
    def _calculate_optimal_raise(self, game_state: Dict, raise_type: str, hand_strength: float) -> int:
        """Calculate optimal raise amount based on situation."""
        pot = game_state.get('pot', 0)
        current_bet = game_state.get('current_bet', 0)
        phase = game_state.get('phase', 'preflop')
        
        # Base multipliers
        multipliers = {
            'value': {'preflop': 3.0, 'flop': 0.7, 'turn': 0.8, 'river': 0.9},
            'bluff': {'preflop': 2.5, 'flop': 0.6, 'turn': 0.7, 'river': 0.8},
            'default': {'preflop': 2.0, 'flop': 0.5, 'turn': 0.6, 'river': 0.7}
        }
        
        base_mult = multipliers.get(raise_type, multipliers['default']).get(phase, 0.7)
        
        if phase == 'preflop':
            # Preflop raises are in big blind units
            raise_amount = int(base_mult * current_bet) if current_bet > 0 else int(base_mult * 10)
        else:
            # Postflop raises are pot-sized
            raise_amount = int(pot * base_mult)
        
        # Ensure minimum raise
        min_raise = current_bet * 2 if current_bet > 0 else 10
        max_possible = game_state.get('players', {}).get(game_state.get('current_player', ''), {}).get('chips', 1000)
        
        final_amount = max(min_raise, min(raise_amount, max_possible))
        
        # Don't overcommit with weak hands
        if raise_type == 'bluff' and hand_strength < 0.3:
            final_amount = min(final_amount, pot // 2)
        
        return final_amount
    
    def _should_bluff(self, hand_strength: float, opponent_tightness: float, phase: str) -> bool:
        """Determine if we should bluff based on situation."""
        # Base bluff frequency
        base_chance = self.bluff_frequency
        
        # Adjust based on opponent tightness (tighter opponents = more bluffing)
        tightness_factor = opponent_tightness
        
        # Adjust based on hand strength (weaker hands = more bluffing)
        weakness_factor = (1.0 - hand_strength) * 0.5
        
        # Phase adjustment (more bluffing on later streets)
        phase_factor = {'preflop': 0.8, 'flop': 1.0, 'turn': 1.2, 'river': 1.5}.get(phase, 1.0)
        
        total_chance = base_chance * (1 + tightness_factor + weakness_factor) * phase_factor
        
        return random.random() < min(total_chance, 0.4)  # Cap at 40%
    
    def _safe_fold(self, valid_actions: List[Dict]) -> Dict[str, Any]:
        """Safe fold action as fallback."""
        fold_action = next((a for a in valid_actions if a.get('action') == 'fold'), None)
        if fold_action:
            return fold_action
        return {"action": "fold"}
    
    def reset(self):
        """Reset AI state between sessions."""
        self.opponent_stats.clear()
        self.hand_history.clear()
        self.current_session_hands = 0
        self.wins = 0


# Test code
if __name__ == "__main__":
    ai = QwenAI()
    print("AI Info:", ai.get_info())
    
    # Test basic functionality
    test_state = {
        'valid_actions': [{'action': 'fold'}, {'action': 'call', 'amount': 10}],
        'players': {'player1': {'hole_cards': ['As', 'Ks'], 'chips': 1000, 'current_bet': 0, 'state': 'active'}},
        'current_player': 'player1',
        'community_cards': [],
        'pot': 10,
        'current_bet': 10,
        'phase': 'preflop',
        'dealer_index': 0
    }
    
    decision = ai.make_move(test_state)
    print("Test Decision:", decision)