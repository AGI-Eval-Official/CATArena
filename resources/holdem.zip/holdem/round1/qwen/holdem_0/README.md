# Qwen Hold'em AI

## Overview
This is an advanced Texas Hold'em AI implementation developed by Qwen Code. It features strategic decision making based on accurate hand evaluation, position awareness, pot odds calculation, and opponent modeling.

## Key Features

### 1. Advanced Hand Evaluation
- Uses the poker logic engine for accurate hand strength assessment when available
- Falls back to sophisticated heuristic evaluation when poker logic isn't accessible
- Implements Monte Carlo simulation concepts for equity estimation

### 2. Strategic Decision Making
- **Position-aware play**: Adjusts strategy based on early/middle/late position
- **Pot odds calculation**: Makes mathematically sound decisions based on pot odds
- **Value betting**: Extracts maximum value from strong hands
- **Strategic bluffing**: Bluffs at optimal frequencies based on situation

### 3. Opponent Modeling
- Tracks opponent statistics (VPIP, PFR, aggression, fold-to-bet)
- Adapts strategy based on opponent tightness/looseness
- Implements exploitative play against specific opponent types

### 4. Phase-Specific Strategy
- **Preflop**: Tight-aggressive play with strong starting hands
- **Flop**: Categorizes hands and makes appropriate continuation bets
- **Turn/River**: Adjusts bet sizing and bluffing frequency based on board texture

## Strategy Details

### Hand Strength Thresholds
The AI uses dynamic thresholds based on game phase:
- **Preflop**: Very Strong (0.75+), Strong (0.60+), Playable (0.40+)
- **Flop**: Very Strong (0.65+), Strong (0.50+), Playable (0.35+)
- **Turn**: Very Strong (0.60+), Strong (0.45+), Playable (0.30+)
- **River**: Very Strong (0.55+), Strong (0.40+), Playable (0.25+)

### Position Factors
- **Early position**: 15% more conservative (factor: 0.85)
- **Middle position**: Standard play (factor: 1.0)
- **Late position**: 15% more aggressive (factor: 1.15)

### Bluffing Strategy
- Bluff frequency: 18% base rate
- Adjusted by phase: Preflop (30%), Flop (60%), Turn (80%), River (120%)
- Reduced against loose opponents (calling stations)
- Increased against tight opponents from late position

## Technical Implementation

### Dependencies
- Python 3.7+
- GamesEnv poker logic engine (optional but recommended)

### Fallback Mechanism
The AI gracefully handles cases where the poker logic engine is not available by using sophisticated string-based hand evaluation and heuristic methods.

### Performance
- Thinking time: 0.3-2.5 seconds (configurable)
- Memory usage: Minimal, with opponent statistics tracking
- Error handling: Robust fallback to safe folding on errors

## Configuration
See `ai_config.yaml` for detailed configuration options including:
- Aggression level (0.0-1.0)
- Bluff frequency (0.0-1.0)
- Position awareness toggle
- Performance parameters
- Advanced strategy options

## Testing
The AI includes built-in test code that can be run with:
```bash
python ai_player.py
```

## Tournament Ready
This AI is designed to compete in AI tournaments with:
- Competitive strategic depth
- Adaptive opponent exploitation
- Robust error handling
- Consistent performance under pressure

## Author
Developed by Qwen Code as part of the CATArena AI competition.