#!/usr/bin/env python3
"""
Validation script for Qwen Holdem AI
This script verifies that the AI meets all requirements and can be loaded by the game engine.
"""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def validate_ai():
    """Validate that the AI implementation is correct."""
    try:
        # Import the AI module
        from ai_player import QwenHoldemAI
        
        # Create AI instance
        ai = QwenHoldemAI()
        
        # Test get_info method
        info = ai.get_info()
        required_fields = ['ai_id', 'name', 'version', 'description']
        for field in required_fields:
            if field not in info:
                print(f"ERROR: Missing required field '{field}' in get_info()")
                return False
        
        # Verify ai_id matches config
        if info['ai_id'] != 'qwen_holdem_3':
            print(f"ERROR: ai_id mismatch. Expected 'qwen_holdem_3', got '{info['ai_id']}'")
            return False
        
        # Test make_move method with minimal game state
        test_game_state = {
            'valid_actions': [{'action': 'fold'}, {'action': 'check'}],
            'players': {
                'test_player': {
                    'hole_cards': ['As', 'Kh'],
                    'chips': 1000,
                    'current_bet': 0,
                    'state': 'active'
                }
            },
            'current_player': 'test_player',
            'community_cards': [],
            'pot': 0,
            'current_bet': 0,
            'phase': 'preflop',
            'dealer_index': 0
        }
        
        decision = ai.make_move(test_game_state)
        if not isinstance(decision, dict) or 'action' not in decision:
            print(f"ERROR: Invalid decision format: {decision}")
            return False
        
        print("SUCCESS: Qwen Holdem AI validation passed!")
        print(f"AI Info: {info}")
        print(f"Test Decision: {decision}")
        return True
        
    except Exception as e:
        print(f"ERROR: Validation failed with exception: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = validate_ai()
    sys.exit(0 if success else 1)