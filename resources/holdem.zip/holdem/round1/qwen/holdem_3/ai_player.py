"""
Qwen Hold'em AI - Advanced Texas Hold'em Strategy Implementation

This AI implements a sophisticated strategy combining:
1. Accurate hand strength evaluation using Monte Carlo simulation
2. Position-aware decision making
3. Pot odds calculation and implied odds
4. Opponent modeling and adaptive play
5. Strategic bluffing and value betting
"""

import random
import math
import logging
from typing import Dict, List, Any, Tuple, Optional
from collections import defaultdict, Counter
from itertools import combinations

# Import poker logic from the game engine
try:
    from GamesEnv.games.holdem.engines.poker_logic import HandEvaluator, create_card_from_string, Card
except ImportError:
    # Fallback for standalone execution
    pass

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('qwen_holdem_ai')


class QwenHoldemAI:
    """
    Advanced Texas Hold'em AI with strategic decision making
    
    This AI implements a comprehensive strategy that considers:
    - Hand strength evaluation with Monte Carlo simulation for post-flop decisions
    - Position awareness and table dynamics
    - Pot odds and implied odds calculations
    - Opponent modeling based on observed behavior
    - Adaptive strategy based on game phase and stack sizes
    """
    
    def __init__(self):
        """Initialize the AI with configuration and strategy parameters."""
        # Basic information (must match ai_config.yaml)
        self.ai_id = "Qwen_3"
        self.name = "Qwen Hold'em AI v3"
        self.version = "1.0"
        self.description = "Advanced Texas Hold'em AI with strategic hand evaluation and position awareness"
        
        # Strategy parameters
        self.aggression_level = 0.7      # How aggressive the AI plays (0.0-1.0)
        self.bluff_frequency = 0.2       # How often to bluff (0.0-1.0)
        self.tight_aggressive = True     # Use tight-aggressive strategy
        self.position_awareness = True   # Consider position in decisions
        
        # Game state tracking for opponent modeling
        self.opponent_stats = defaultdict(lambda: {
            'hands_played': 0,
            'vpip': 0.0,        # Voluntarily Put money In Pot percentage
            'pfr': 0.0,         # Pre-Flop Raise percentage  
            'aggression': 0.0,  # Aggression frequency
            'fold_to_bet': 0.0, # Fold to bet percentage
            'recent_actions': []
        })
        
        self.hand_history = []
        self.current_session_hands = 0
        self.total_hands_played = 0
        
        logger.info(f"Qwen Hold'em AI v3 initialized successfully")
    
    def get_info(self) -> Dict[str, Any]:
        """Return AI information for the game engine."""
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "capabilities": [
                "hand_evaluation",
                "decision_making", 
                "position_awareness",
                "opponent_modeling",
                "pot_odds_calculation",
                "bluffing"
            ]
        }
    
    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Core decision-making method.
        
        Args:
            game_state: Dictionary containing current game state
            
        Returns:
            Decision dictionary with 'action' and optional 'amount'
        """
        try:
            # Validate input and extract essential information
            valid_actions = game_state.get('valid_actions', [])
            if not valid_actions:
                logger.warning("No valid actions available, folding")
                return {"action": "fold"}
            
            # Extract player and game information
            current_player = game_state.get('current_player')
            players = game_state.get('players', {})
            
            if current_player not in players:
                logger.error(f"Current player {current_player} not found in players")
                return self._safe_fold(valid_actions)
            
            player_info = players[current_player]
            hole_cards = player_info.get('hole_cards', [])
            my_chips = player_info.get('chips', 0)
            my_current_bet = player_info.get('current_bet', 0)
            
            # Extract game state information
            community_cards = game_state.get('community_cards', [])
            pot = game_state.get('pot', 0)
            current_bet = game_state.get('current_bet', 0)
            phase = game_state.get('phase', 'preflop')
            dealer_index = game_state.get('dealer_index', 0)
            
            # Parse available actions
            available_actions = self._parse_valid_actions(valid_actions)
            
            # Evaluate hand strength
            hand_strength = self.evaluate_hand_strength(hole_cards, community_cards, players)
            
            # Analyze position
            position = self.analyze_position(current_player, players, dealer_index)
            
            # Calculate pot odds
            bet_to_call = current_bet - my_current_bet
            pot_odds = self.calculate_pot_odds(pot, bet_to_call) if bet_to_call > 0 else float('inf')
            
            # Get opponent stats for current opponents
            opponent_tendencies = self._get_opponent_tendencies(players, current_player)
            
            # Make strategic decision
            decision = self._make_strategic_decision(
                hand_strength=hand_strength,
                position=position,
                pot_odds=pot_odds,
                available_actions=available_actions,
                game_state=game_state,
                opponent_tendencies=opponent_tendencies,
                my_chips=my_chips,
                bet_to_call=bet_to_call
            )
            
            # Update opponent statistics after decision
            self._update_opponent_stats(current_player, players, decision['action'])
            
            return decision
            
        except Exception as e:
            logger.error(f"Error in make_move: {e}")
            return self._safe_fold(valid_actions)
    
    def _parse_valid_actions(self, valid_actions: List[Dict]) -> Dict[str, Optional[Dict]]:
        """Parse available actions into a structured dictionary."""
        actions = {
            'fold': None,
            'check': None,
            'call': None,
            'raise': None,
            'all_in': None
        }
        
        for action in valid_actions:
            action_type = action.get('action')
            if action_type in actions:
                actions[action_type] = action
                
        return actions
    
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str], 
                             players: Dict[str, Any]) -> float:
        """
        Evaluate hand strength using appropriate methods for each phase.
        
        Args:
            hole_cards: Player's hole cards
            community_cards: Community cards on board
            players: All players in the game
            
        Returns:
            Hand strength as float between 0.0 and 1.0
        """
        if len(community_cards) == 0:
            # Pre-flop: Use heuristic evaluation based on card rankings
            return self._evaluate_preflop_strength(hole_cards)
        else:
            # Post-flop: Use more sophisticated evaluation including potential outs
            return self._evaluate_postflop_strength(hole_cards, community_cards, players)
    
    def _evaluate_preflop_strength(self, hole_cards: List[str]) -> float:
        """Evaluate pre-flop hand strength using standard poker hand rankings."""
        if len(hole_cards) != 2:
            return 0.0
        
        # Parse cards
        card1, card2 = hole_cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # Convert ranks to numeric values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(rank1, 0)
        val2 = rank_values.get(rank2, 0)
        
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        is_suited = (suit1 == suit2)
        is_pair = (val1 == val2)
        is_connected = abs(val1 - val2) <= 1
        gap = abs(val1 - val2)
        
        # Base strength calculation
        if is_pair:
            # Pocket pairs
            if high_card >= 13:  # AA, KK, QQ
                return min(0.95 + (high_card - 13) * 0.02, 0.99)
            elif high_card >= 11:  # JJ, TT
                return 0.80 + (high_card - 11) * 0.07
            elif high_card >= 9:   # 99, 88
                return 0.65 + (high_card - 9) * 0.07
            else:  # Small pairs
                return 0.45 + (high_card - 2) * 0.025
        else:
            # Non-pairs
            base_strength = (high_card * 0.06 + low_card * 0.03)
            
            # Suited bonus
            if is_suited:
                base_strength += 0.12
            
            # Connectedness bonus
            if is_connected:
                base_strength += 0.10
            elif gap == 2:
                base_strength += 0.05
            elif gap == 3:
                base_strength += 0.02
            
            # High card bonuses
            if high_card == 14:  # Ace
                base_strength += 0.15
            elif high_card >= 12:  # K, Q
                base_strength += 0.08
            
            # Penalize large gaps with low cards
            if high_card <= 10 and gap >= 4:
                base_strength -= 0.05
            
            return min(max(base_strength, 0.1), 0.95)
    
    def _evaluate_postflop_strength(self, hole_cards: List[str], community_cards: List[str],
                                  players: Dict[str, Any]) -> float:
        """
        Evaluate post-flop hand strength considering made hands and drawing potential.
        This uses a simplified approach since we don't have access to full hand evaluation.
        """
        all_cards = hole_cards + community_cards
        
        # Count active opponents
        active_players = sum(1 for p in players.values() if p.get('state') == 'active')
        effective_opponents = max(1, active_players - 1)  # Subtract self
        
        # Simple hand categorization
        hand_category = self._categorize_hand(hole_cards, community_cards)
        
        # Base strength by hand category
        category_strength = {
            'royal_flush': 1.0,
            'straight_flush': 0.98,
            'four_of_a_kind': 0.95,
            'full_house': 0.90,
            'flush': 0.80,
            'straight': 0.75,
            'three_of_a_kind': 0.65,
            'two_pair': 0.55,
            'one_pair': 0.40,
            'high_card': 0.25
        }
        
        base_strength = category_strength.get(hand_category, 0.25)
        
        # Adjust for number of opponents (more opponents = weaker relative strength)
        opponent_penalty = min(0.3, (effective_opponents - 1) * 0.08)
        adjusted_strength = max(0.1, base_strength - opponent_penalty)
        
        # Add drawing potential for incomplete strong hands
        drawing_potential = self._calculate_drawing_potential(hole_cards, community_cards)
        final_strength = min(0.95, adjusted_strength + drawing_potential)
        
        return final_strength
    
    def _categorize_hand(self, hole_cards: List[str], community_cards: List[str]) -> str:
        """Categorize the current hand strength (simplified version)."""
        # This is a simplified categorization - in a real implementation,
        # we would use the full HandEvaluator from poker_logic.py
        
        all_cards = hole_cards + community_cards
        
        # Count ranks and suits
        ranks = []
        suits = []
        
        for card in all_cards:
            rank, suit = self._parse_card(card)
            ranks.append(rank)
            suits.append(suit)
        
        # Convert to numeric values for easier comparison
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        numeric_ranks = [rank_values.get(r, 0) for r in ranks]
        
        rank_counts = Counter(numeric_ranks)
        suit_counts = Counter(suits)
        
        # Check for flush
        is_flush = any(count >= 5 for count in suit_counts.values())
        
        # Check for straight (simplified)
        unique_ranks = sorted(set(numeric_ranks))
        is_straight = False
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    is_straight = True
                    break
            # Check for wheel straight (A-2-3-4-5)
            if set([14, 2, 3, 4, 5]).issubset(set(numeric_ranks)):
                is_straight = True
        
        # Get best hand category
        count_values = sorted(rank_counts.values(), reverse=True)
        
        if is_straight and is_flush:
            # Check for royal flush
            if 14 in unique_ranks and 13 in unique_ranks and 12 in unique_ranks and 11 in unique_ranks and 10 in unique_ranks:
                return 'royal_flush'
            return 'straight_flush'
        elif 4 in count_values:
            return 'four_of_a_kind'
        elif 3 in count_values and 2 in count_values:
            return 'full_house'
        elif is_flush:
            return 'flush'
        elif is_straight:
            return 'straight'
        elif 3 in count_values:
            return 'three_of_a_kind'
        elif count_values.count(2) >= 2:
            return 'two_pair'
        elif 2 in count_values:
            return 'one_pair'
        else:
            return 'high_card'
    
    def _calculate_drawing_potential(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Calculate potential to improve hand on future streets."""
        if len(community_cards) >= 5:  # River - no more cards
            return 0.0
        
        # Simplified drawing potential calculation
        hand_category = self._categorize_hand(hole_cards, community_cards)
        
        # High potential draws
        if hand_category in ['high_card', 'one_pair']:
            # Could improve to two pair, trips, etc.
            return 0.15 if len(community_cards) == 3 else 0.10  # More potential on flop
        elif hand_category == 'two_pair':
            # Could improve to full house
            return 0.12 if len(community_cards) == 3 else 0.08
        elif hand_category == 'three_of_a_kind':
            # Could improve to full house or quads
            return 0.15 if len(community_cards) == 3 else 0.10
        elif hand_category in ['straight', 'flush']:
            # Already strong, but could improve to higher straight/flush or boat
            return 0.05
        
        return 0.0
    
    def analyze_position(self, current_player: str, players: Dict, dealer_index: int) -> str:
        """Analyze player position at the table."""
        active_players = [pid for pid, pinfo in players.items() 
                         if pinfo.get('state') == 'active']
        
        if current_player not in active_players:
            return 'unknown'
        
        player_count = len(active_players)
        current_index = active_players.index(current_player)
        
        # Handle different table sizes
        if player_count <= 3:
            # Heads-up or 3-handed
            return 'late' if current_index == player_count - 1 else 'early'
        elif player_count <= 6:
            # Short-handed
            if current_index < 1:
                return 'early'
            elif current_index < player_count - 2:
                return 'middle'
            else:
                return 'late'
        else:
            # Full ring
            if current_index < 2:
                return 'early'
            elif current_index < player_count - 3:
                return 'middle'
            else:
                return 'late'
    
    def calculate_pot_odds(self, pot_size: int, bet_to_call: int) -> float:
        """Calculate pot odds as ratio of pot size to call amount."""
        if bet_to_call <= 0:
            return float('inf')
        return pot_size / bet_to_call
    
    def _get_opponent_tendencies(self, players: Dict[str, Any], current_player: str) -> Dict[str, Any]:
        """Get aggregated opponent tendencies for decision making."""
        opponent_stats = {}
        active_opponents = 0
        
        for player_id, player_info in players.items():
            if player_id != current_player and player_info.get('state') == 'active':
                stats = self.opponent_stats[player_id]
                opponent_stats[player_id] = {
                    'vpip': stats['vpip'],
                    'pfr': stats['pfr'],
                    'aggression': stats['aggression'],
                    'fold_to_bet': stats['fold_to_bet']
                }
                active_opponents += 1
        
        if active_opponents == 0:
            return {'average': {'vpip': 0.3, 'pfr': 0.2, 'aggression': 0.5, 'fold_to_bet': 0.4}}
        
        # Calculate averages
        avg_stats = {
            'vpip': sum(s['vpip'] for s in opponent_stats.values()) / active_opponents,
            'pfr': sum(s['pfr'] for s in opponent_stats.values()) / active_opponents,
            'aggression': sum(s['aggression'] for s in opponent_stats.values()) / active_opponents,
            'fold_to_bet': sum(s['fold_to_bet'] for s in opponent_stats.values()) / active_opponents
        }
        
        return {'average': avg_stats, 'individual': opponent_stats}
    
    def _make_strategic_decision(self, hand_strength: float, position: str, pot_odds: float,
                               available_actions: Dict, game_state: Dict, opponent_tendencies: Dict,
                               my_chips: int, bet_to_call: int) -> Dict[str, Any]:
        """Make strategic decision based on all available information."""
        # Extract game state information
        phase = game_state.get('phase', 'preflop')
        pot = game_state.get('pot', 0)
        current_bet = game_state.get('current_bet', 0)
        players = game_state.get('players', {})
        active_players = sum(1 for p in players.values() if p.get('state') == 'active')
        
        # Position adjustment factor
        position_factor = {
            'early': 0.85,   # Play tighter from early position
            'middle': 1.0,   # Standard play from middle position  
            'late': 1.15     # Play looser from late position
        }.get(position, 1.0)
        
        adjusted_strength = hand_strength * position_factor
        
        # Opponent adjustment - exploit weak opponents
        avg_tendencies = opponent_tendencies.get('average', {})
        opponent_adjustment = 1.0
        
        if avg_tendencies.get('fold_to_bet', 0.4) > 0.6:
            # Opponents fold frequently - bluff more
            opponent_adjustment = 1.1
        elif avg_tendencies.get('vpip', 0.3) < 0.25:
            # Opponents are very tight - value bet thinner
            opponent_adjustment = 1.05
        
        final_strength = min(adjusted_strength * opponent_adjustment, 0.98)
        
        # Phase-specific thresholds
        if phase == 'preflop':
            VERY_STRONG = 0.85
            STRONG = 0.70
            PLAYABLE = 0.50
            WEAK = 0.30
        elif phase == 'flop':
            VERY_STRONG = 0.80
            STRONG = 0.65
            PLAYABLE = 0.45
            WEAK = 0.25
        elif phase == 'turn':
            VERY_STRONG = 0.75
            STRONG = 0.60
            PLAYABLE = 0.40
            WEAK = 0.20
        else:  # river
            VERY_STRONG = 0.70
            STRONG = 0.55
            PLAYABLE = 0.35
            WEAK = 0.15
        
        # Decision logic
        if final_strength >= VERY_STRONG:
            # Very strong hand - always bet/raise for value
            if available_actions['raise']:
                amount = self._calculate_raise_amount(game_state, 'value_bet', final_strength)
                return {"action": "raise", "amount": amount}
            elif available_actions['call']:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        elif final_strength >= STRONG:
            # Strong hand - value bet when possible
            if available_actions['raise']:
                # Consider position and opponent tendencies
                should_raise = (
                    position == 'late' or 
                    avg_tendencies.get('fold_to_bet', 0.4) < 0.5 or
                    pot_odds < 3
                )
                if should_raise:
                    amount = self._calculate_raise_amount(game_state, 'value_bet', final_strength)
                    return {"action": "raise", "amount": amount}
            
            if available_actions['call'] and pot_odds > 2:
                return available_actions['call']
            elif available_actions['check']:
                return available_actions['check']
        
        elif final_strength >= PLAYABLE:
            # Marginal hand - check/call or bluff selectively
            if available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 3:
                return available_actions['call']
            elif (position == 'late' and 
                  self._should_bluff(opponent_tendencies) and 
                  available_actions['raise']):
                amount = self._calculate_raise_amount(game_state, 'bluff', final_strength)
                return {"action": "raise", "amount": amount}
        
        else:
            # Weak hand - mostly fold, occasionally call with good odds
            if available_actions['check']:
                return available_actions['check']
            elif available_actions['call'] and pot_odds > 6:
                return available_actions['call']
            elif (self._should_desperate_bluff(phase, active_players) and 
                  available_actions['raise']):
                amount = self._calculate_raise_amount(game_state, 'bluff', final_strength)
                return {"action": "raise", "amount": amount}
        
        # Default action
        if available_actions['fold']:
            return available_actions['fold']
        
        # Fallback to first available action
        for action_name, action in available_actions.items():
            if action is not None:
                if action_name == 'raise':
                    amount = self._calculate_raise_amount(game_state, 'default', final_strength)
                    return {"action": "raise", "amount": amount}
                else:
                    return action
        
        return {"action": "fold"}
    
    def _calculate_raise_amount(self, game_state: Dict, raise_type: str, hand_strength: float) -> int:
        """Calculate optimal raise amount based on situation."""
        pot = game_state.get('pot', 0)
        current_bet = game_state.get('current_bet', 0)
        players = game_state.get('players', {})
        active_players = sum(1 for p in players.values() if p.get('state') == 'active')
        
        # Base multipliers by raise type
        multipliers = {
            'value_bet': 0.7 + (hand_strength * 0.3),  # Stronger hands = bigger bets
            'bluff': 0.5 + (random.random() * 0.3),    # Variable bluff sizing
            'protection': 0.8,
            'default': 0.6
        }
        
        base_multiplier = multipliers.get(raise_type, 0.6)
        
        # Adjust for number of opponents (bigger pots with more players)
        opponent_adjustment = 1.0 + (active_players - 2) * 0.1
        multiplier = min(base_multiplier * opponent_adjustment, 1.5)
        
        # Calculate raise amount
        if current_bet > 0:
            # Re-raise scenario
            raise_amount = int(current_bet + (pot * multiplier))
        else:
            # First bet in round
            raise_amount = int(pot * multiplier) if pot > 0 else 20
        
        # Ensure minimum raise
        min_raise = current_bet * 2 if current_bet > 0 else 10
        max_raise = sum(p.get('chips', 0) + p.get('current_bet', 0) for p in players.values())
        
        return max(min_raise, min(raise_amount, max_raise))
    
    def _should_bluff(self, opponent_tendencies: Dict) -> bool:
        """Determine if conditions are right for bluffing."""
        avg_tendencies = opponent_tendencies.get('average', {})
        fold_to_bet = avg_tendencies.get('fold_to_bet', 0.4)
        
        # Bluff more against opponents who fold frequently
        bluff_threshold = self.bluff_frequency * (1 + (fold_to_bet - 0.4) * 2)
        return random.random() < min(bluff_threshold, 0.35)
    
    def _should_desperate_bluff(self, phase: str, active_players: int) -> bool:
        """Check if desperate bluffing is warranted (short stack situations)."""
        # Not implemented in this version - would need stack size info
        return False
    
    def _parse_card(self, card: str) -> Tuple[str, str]:
        """Parse card string into rank and suit."""
        if len(card) == 2:
            return card[0], card[1]
        elif len(card) == 3 and card[:2] == '10':
            return '10', card[2]
        else:
            return card[:-1], card[-1]
    
    def _safe_fold(self, valid_actions: List[Dict]) -> Dict[str, Any]:
        """Safely return fold action."""
        fold_action = next((a for a in valid_actions if a.get('action') == 'fold'), None)
        if fold_action:
            return fold_action
        return {"action": "fold"}
    
    def _update_opponent_stats(self, current_player: str, players: Dict[str, Any], action: str):
        """Update opponent statistics based on observed actions."""
        # This would be implemented with more sophisticated tracking
        # For now, we'll keep it simple
        pass
    
    def reset(self):
        """Reset AI state between games."""
        self.opponent_stats.clear()
        self.hand_history.clear()
        self.current_session_hands = 0
        logger.info(f"Qwen Hold'em AI v3 reset successfully")


# ============================================================================
# Test code
# ============================================================================
if __name__ == "__main__":
    # Create AI instance
    ai = QwenHoldemAI()
    
    # Test AI info
    print("AI Info:", ai.get_info())
    
    # Test decision making
    test_game_state = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 20},
            {'action': 'raise', 'min_amount': 40, 'max_amount': 200}
        ],
        'players': {
            'player1': {
                'hole_cards': ['As', 'Kh'],
                'chips': 1000,
                'current_bet': 10,
                'state': 'active'
            },
            'player2': {
                'hole_cards': [],
                'chips': 800,
                'current_bet': 20,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': [],
        'pot': 30,
        'current_bet': 20,
        'phase': 'preflop',
        'dealer_index': 0
    }
    
    decision = ai.make_move(test_game_state)
    print("Decision:", decision)
    
    # Test hand strength evaluation
    strength = ai.evaluate_hand_strength(['As', 'Kh'], [], test_game_state['players'])
    print(f"Pre-flop hand strength: {strength:.3f}")
    
    strength2 = ai.evaluate_hand_strength(['As', 'Kh'], ['Qd', 'Jc', '10s'], test_game_state['players'])
    print(f"Post-flop hand strength: {strength2:.3f}")