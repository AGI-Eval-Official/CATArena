#!/usr/bin/env python3
"""
Comprehensive test for Qwen Holdem AI v3
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ai_player import QwenHoldemAI

def test_ai_comprehensive():
    """Run comprehensive tests on the AI"""
    ai = QwenHoldemAI()
    
    print("=== Qwen Holdem AI v3 - Comprehensive Test ===\n")
    
    # Test 1: Basic info
    info = ai.get_info()
    print("Test 1 - AI Info:")
    print(f"  AI ID: {info['ai_id']}")
    print(f"  Name: {info['name']}")
    print(f"  Version: {info['version']}")
    print(f"  Capabilities: {len(info['capabilities'])} features\n")
    
    # Test 2: Preflop decision with strong hand
    test_state_1 = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 10},
            {'action': 'raise', 'min_amount': 20, 'max_amount': 100}
        ],
        'players': {
            'player1': {
                'hole_cards': ['As', 'Ah'],  # Pocket Aces
                'chips': 1000,
                'current_bet': 0,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': [],
        'pot': 10,
        'current_bet': 10,
        'phase': 'preflop',
        'dealer_index': 0
    }
    
    decision_1 = ai.make_move(test_state_1)
    print("Test 2 - Preflop with AA:")
    print(f"  Decision: {decision_1}\n")
    
    # Test 3: Flop decision with made hand
    test_state_2 = {
        'valid_actions': [
            {'action': 'check'},
            {'action': 'bet', 'min_amount': 10, 'max_amount': 50}
        ],
        'players': {
            'player1': {
                'hole_cards': ['Ks', 'Qs'],
                'chips': 990,
                'current_bet': 10,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': ['Kd', '7c', '2h'],  # Top pair
        'pot': 20,
        'current_bet': 10,
        'phase': 'flop',
        'dealer_index': 0
    }
    
    decision_2 = ai.make_move(test_state_2)
    print("Test 3 - Flop with Top Pair:")
    print(f"  Decision: {decision_2}\n")
    
    # Test 4: River decision with weak hand
    test_state_3 = {
        'valid_actions': [
            {'action': 'fold'},
            {'action': 'call', 'amount': 30}
        ],
        'players': {
            'player1': {
                'hole_cards': ['7c', '2d'],
                'chips': 970,
                'current_bet': 10,
                'state': 'active'
            }
        },
        'current_player': 'player1',
        'community_cards': ['Ah', 'Kd', 'Qs', 'Jc', '10h'],  # Straight on board
        'pot': 60,
        'current_bet': 40,
        'phase': 'river',
        'dealer_index': 0
    }
    
    decision_3 = ai.make_move(test_state_3)
    print("Test 4 - River with Weak Hand vs Strong Board:")
    print(f"  Decision: {decision_3}\n")
    
    print("=== All tests completed successfully! ===")

if __name__ == "__main__":
    test_ai_comprehensive()