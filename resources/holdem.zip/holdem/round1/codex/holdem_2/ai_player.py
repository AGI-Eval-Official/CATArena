"""
codex_AI - Texas Hold'em (Traditional) Bot
==========================================
Tight-aggressive, position-aware AI with draw odds and value betting.

Implements the expected interface used by the holdem engine templates:
  - get_info() -> Dict[str, Any]
  - make_move(game_state: Dict[str, Any]) -> Dict[str, Any]
  - reset() (optional)
  - get_thinking_time() (optional)
"""

from typing import Any, Dict, List, Optional, Tuple
import logging
import math
import random


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("codex_holdem_2_ai")


class CodexHoldem2AI:
    """Texas Hold'em AI (Traditional) — codex_AI

    Core ideas:
      - Preflop: starting hand tiering (pairs, high cards, suited connectors)
      - Postflop: made-hand category + draws (flush/straight, OESD, gutshot)
      - Pot odds vs. draw odds; value-bet strong hands; semi-bluff good draws
      - Position-aware thresholds; light bluffing on late position
    """

    def __init__(self) -> None:
        # Basic info — must align with ai_config.yaml
        self.ai_id = "codex_holdem_2_ai"
        self.name = "codex_AI"
        self.version = "1.0.0"
        self.description = (
            "Tight-aggressive, position-aware Hold'em AI with draw and pot-odds logic"
        )

        # Style parameters
        self.aggression = 0.65
        self.bluff_freq = 0.12
        self.position_awareness = True

    # ---------------------------- Public API ----------------------------
    def get_info(self) -> Dict[str, Any]:
        return {
            "ai_id": self.ai_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "capabilities": [
                "hand_evaluation",
                "decision_making",
                "position_awareness",
                "pot_odds_calculation",
                "bluffing",
            ],
        }

    def make_move(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        try:
            valid_actions = game_state.get("valid_actions", [])
            if not valid_actions:
                return {"action": "fold", "amount": 0}

            current_player = game_state.get("current_player")
            players = game_state.get("players", {})
            if current_player not in players:
                return self._safe_fold(valid_actions)

            pinfo = players[current_player]
            hole = pinfo.get("hole_cards", [])
            chips = max(0, int(pinfo.get("chips", 0)))
            my_bet = int(pinfo.get("current_bet", 0))

            community = game_state.get("community_cards", [])
            pot = int(game_state.get("pot", 0))
            current_bet = int(game_state.get("current_bet", 0))
            dealer_index = int(game_state.get("dealer_index", 0))

            actions = self._parse_valid_actions(valid_actions)

            # Hand strength (0..1)
            strength = self._hand_strength(hole, community)

            # Position
            position = self._position(current_player, players, dealer_index)
            pos_factor = {"early": 0.92, "middle": 1.0, "late": 1.08}.get(position, 1.0)
            adj_strength = strength * (pos_factor if self.position_awareness else 1.0)

            # Pot odds
            to_call = max(0, current_bet - my_bet)
            pot_odds = self._pot_odds(pot, to_call) if to_call > 0 else float("inf")

            decision = self._decide(actions, hole, community, chips, pot, current_bet, to_call,
                                     adj_strength, position, pot_odds)

            logger.info(
                f"codex_AI decision={decision} hole={hole} comm={community} "
                f"str={strength:.3f}/{adj_strength:.3f} pos={position} pot={pot} to_call={to_call}"
            )
            return decision
        except Exception as e:
            logger.error(f"make_move error: {e}")
            return self._safe_fold(game_state.get("valid_actions", []))

    def reset(self) -> None:
        pass

    def get_thinking_time(self) -> float:
        return random.uniform(0.2, 0.8)

    # ---------------------------- Decision Logic ----------------------------
    def _decide(
        self,
        actions: Dict[str, Optional[Dict[str, Any]]],
        hole: List[str],
        community: List[str],
        chips: int,
        pot: int,
        current_bet: int,
        to_call: int,
        strength: float,
        position: str,
        pot_odds: float,
    ) -> Dict[str, Any]:
        phase = self._phase_by_community(len(community))

        # Thresholds by phase
        if phase == "preflop":
            tiers = self._preflop_tier(hole)
            return self._preflop_decision(actions, tiers, position, pot, to_call, chips)

        # Postflop: include draws
        made_rank = self._made_hand_rank(hole + community)
        draw = self._draw_info(hole, community)

        # Convert draw odds to required pot odds threshold
        call_allowed = actions.get("call") is not None
        check_allowed = actions.get("check") is not None
        raise_allowed = actions.get("raise") is not None

        # Value regions
        very_strong = made_rank >= 6  # straight or better
        strong = made_rank >= 4       # two pair or trips
        medium = made_rank == 3       # one pair

        # Draw odds
        has_oesd = draw["oesd"]
        has_fd = draw["flush_draw"]
        has_gutshot = draw["gutshot"]

        # Approximate outs
        outs = 0
        if has_fd:
            outs += 9
        if has_oesd:
            outs += 8
        if has_gutshot:
            outs += 4
        implied = 1.0 + 0.2 * (1 if position == "late" else 0)
        win_prob = self._outs_to_win_prob(outs, streets_left=self._streets_left(community))
        required_odds = (1.0 / max(win_prob, 1e-6)) - 1.0

        # Playbook
        if very_strong:
            if raise_allowed:
                amount = self._value_bet_amount(pot, current_bet)
                return {"action": "raise", "amount": amount}
            if call_allowed:
                return actions["call"]
            if check_allowed:
                return actions["check"]

        if strong:
            if raise_allowed and (position == "late" or pot_odds < 3):
                return {"action": "raise", "amount": self._value_bet_amount(pot, current_bet)}
            if call_allowed and pot_odds > 2:
                return actions["call"]
            if check_allowed:
                return actions["check"]

        if medium:
            # One pair — control pot unless cheap
            if check_allowed:
                return actions["check"]
            if call_allowed and pot_odds > 3:
                return actions["call"]

        # Draws and semi-bluffs
        if outs >= 8:  # strong draw
            if raise_allowed and position == "late" and random.random() < (self.aggression * 0.6):
                return {"action": "raise", "amount": self._semi_bluff_amount(pot, current_bet)}
            if call_allowed and (pot_odds * implied) > required_odds:
                return actions["call"]
            if check_allowed:
                return actions["check"]

        if outs >= 4:  # weak draw
            if check_allowed:
                return actions["check"]
            if call_allowed and (pot_odds * implied) > required_odds * 1.4:
                return actions["call"]

        # Bluff occasionally in late position when nothing
        if raise_allowed and position == "late" and random.random() < self.bluff_freq:
            return {"action": "raise", "amount": self._bluff_amount(pot, current_bet)}

        if check_allowed:
            return actions["check"]
        if call_allowed and pot_odds > 6:
            return actions["call"]
        return actions.get("fold", {"action": "fold", "amount": 0})

    # ---------------------------- Hand Evaluation ----------------------------
    def _hand_strength(self, hole: List[str], community: List[str]) -> float:
        if len(community) == 0:
            return self._preflop_strength(hole)
        return self._postflop_strength(hole, community)

    def _preflop_strength(self, hole: List[str]) -> float:
        if len(hole) != 2:
            return 0.0
        (r1, s1), (r2, s2) = self._parse(hole[0]), self._parse(hole[1])
        v1, v2 = self._rank_val(r1), self._rank_val(r2)
        hi, lo = max(v1, v2), min(v1, v2)
        suited = s1 == s2
        pair = v1 == v2

        if pair:
            if hi >= 13:  # AA, KK, QQ
                return 0.92 + (hi - 13) * 0.03
            if hi >= 10:  # JJ, TT
                return 0.78 + (hi - 10) * 0.05
            return 0.45 + (hi - 2) * 0.035

        base = (hi + lo) / 28.0
        if suited:
            base += 0.08
        gap = abs(v1 - v2)
        if gap == 1:
            base += 0.05
        elif gap <= 3:
            base += 0.02
        if hi == 14:
            base += 0.08
        elif hi >= 12:
            base += 0.04
        return max(0.15, min(0.95, base))

    def _postflop_strength(self, hole: List[str], community: List[str]) -> float:
        made_rank = self._made_hand_rank(hole + community)
        # Map to [0,1] roughly
        scale = {
            0: 0.18,  # high card
            1: 0.32,  # one pair
            2: 0.44,  # two pair
            3: 0.56,  # trips
            4: 0.68,  # straight
            5: 0.78,  # flush
            6: 0.86,  # full house
            7: 0.93,  # quads+
        }
        val = scale.get(made_rank, 0.2)
        draw = self._draw_info(hole, community)
        # Boost for draws
        if draw["flush_draw"]:
            val = max(val, 0.5)
        if draw["oesd"]:
            val = max(val, 0.48)
        if draw["gutshot"]:
            val = max(val, 0.38)
        return min(1.0, val)

    def _made_hand_rank(self, cards: List[str]) -> int:
        # Lightweight heuristic ranking: 0..7 (high card..quads+)
        ranks = [self._rank_val(self._parse(c)[0]) for c in cards]
        suits = [self._parse(c)[1] for c in cards]
        counts = {}
        for v in ranks:
            counts[v] = counts.get(v, 0) + 1
        has_pair = max(counts.values(), default=1) >= 2
        trips = any(c == 3 for c in counts.values())
        quads = any(c == 4 for c in counts.values())
        pairs = sum(1 for c in counts.values() if c == 2)

        flush = False
        for s in set(suits):
            if suits.count(s) >= 5:
                flush = True
                break

        straight = self._has_straight(sorted(set(ranks)))

        if quads:
            return 7
        if trips and pairs >= 1:
            return 6  # full house
        if flush and straight:
            return 5  # treat straight-flush as flush tier here
        if flush:
            return 5
        if straight:
            return 4
        if trips:
            return 3
        if pairs >= 2:
            return 2
        if has_pair:
            return 1
        return 0

    def _draw_info(self, hole: List[str], community: List[str]) -> Dict[str, bool]:
        all_cards = hole + community
        suits = [self._parse(c)[1] for c in all_cards]
        flush_draw = any(suits.count(s) == 4 for s in set(suits)) and len(community) >= 3

        ranks = sorted(set(self._rank_val(self._parse(c)[0]) for c in all_cards))
        oesd = self._has_oesd(ranks)
        gutshot = self._has_gutshot(ranks)
        return {"flush_draw": flush_draw, "oesd": oesd, "gutshot": gutshot}

    # ---------------------------- Utilities ----------------------------
    def _parse_valid_actions(self, valid_actions: List[Dict[str, Any]]) -> Dict[str, Optional[Dict[str, Any]]]:
        out: Dict[str, Optional[Dict[str, Any]]] = {k: None for k in ["fold", "check", "call", "raise", "all_in"]}
        for a in valid_actions:
            t = a.get("action")
            if t in out:
                out[t] = a
        return out

    def _position(self, current_player: str, players: Dict[str, Any], dealer_index: int) -> str:
        active_ids = [pid for pid, info in players.items() if info.get("state") == "active"]
        if current_player not in active_ids or not active_ids:
            return "middle"
        # Order players by dealer_index rotation if provided
        # Fall back to active order if seat indexes are unavailable
        idx = active_ids.index(current_player)
        n = len(active_ids)
        if n <= 3:
            return "late" if idx == n - 1 else ("early" if idx == 0 else "middle")
        if idx <= (n // 3):
            return "early"
        if idx >= (2 * n // 3):
            return "late"
        return "middle"

    def _pot_odds(self, pot: int, to_call: int) -> float:
        if to_call <= 0:
            return float("inf")
        return pot / to_call

    def _value_bet_amount(self, pot: int, current_bet: int) -> int:
        size = max(current_bet * 2, int(pot * 0.65))
        return max(1, size)

    def _semi_bluff_amount(self, pot: int, current_bet: int) -> int:
        size = max(current_bet * 2, int(pot * 0.55))
        return max(1, size)

    def _bluff_amount(self, pot: int, current_bet: int) -> int:
        size = max(current_bet * 2, int(pot * 0.45))
        return max(1, size)

    def _phase_by_community(self, n: int) -> str:
        return {0: "preflop", 3: "flop", 4: "turn", 5: "river"}.get(n, "preflop")

    def _preflop_tier(self, hole: List[str]) -> int:
        """Return 0..4 (worse..best) for starting hand tiering."""
        if len(hole) != 2:
            return 0
        (r1, s1), (r2, s2) = self._parse(hole[0]), self._parse(hole[1])
        v1, v2 = self._rank_val(r1), self._rank_val(r2)
        hi, lo = max(v1, v2), min(v1, v2)
        suited = s1 == s2
        pair = v1 == v2
        gap = abs(v1 - v2)

        if pair:
            if hi >= 13:
                return 4  # AA, KK, QQ
            if hi >= 10:
                return 3  # JJ, TT
            if hi >= 7:
                return 2  # 99, 88, 77
            return 1

        # Premium high cards
        if {hi, lo} >= {14, 13}:  # AK
            return 3 if suited else 2
        if hi == 14 and lo == 12:  # AQ
            return 3 if suited else 2
        if hi == 14 and lo == 11:  # AJ
            return 2 if suited else 1
        if hi == 13 and lo == 12:  # KQ
            return 2 if suited else 1

        # Suited connectors
        if suited and gap == 1 and hi >= 11:
            return 2
        if suited and gap == 1 and hi >= 9:
            return 1

        # Other suited aces/kings
        if suited and hi == 14 and lo >= 9:
            return 2
        if suited and hi == 13 and lo >= 10:
            return 1
        return 0

    def _preflop_decision(
        self,
        actions: Dict[str, Optional[Dict[str, Any]]],
        tier: int,
        position: str,
        pot: int,
        to_call: int,
        chips: int,
    ) -> Dict[str, Any]:
        check_allowed = actions.get("check") is not None
        call_allowed = actions.get("call") is not None
        raise_allowed = actions.get("raise") is not None

        if tier >= 3:
            if raise_allowed:
                return {"action": "raise", "amount": self._value_bet_amount(pot, max(1, to_call))}
            if call_allowed:
                return actions["call"]
            if check_allowed:
                return actions["check"]

        if tier == 2:
            if position == "late" and raise_allowed:
                return {"action": "raise", "amount": self._value_bet_amount(pot, max(1, to_call))}
            if call_allowed and (to_call == 0 or pot / max(1, to_call) > 3):
                return actions["call"]
            if check_allowed:
                return actions["check"]

        if tier == 1:
            if check_allowed:
                return actions["check"]
            if call_allowed and pot / max(1, to_call) > 5:
                return actions["call"]

        if check_allowed:
            return actions["check"]
        if call_allowed and pot / max(1, to_call) > 6:
            return actions["call"]
        return actions.get("fold", {"action": "fold", "amount": 0})

    def _streets_left(self, community: List[str]) -> int:
        n = len(community)
        if n <= 2:
            return 2  # before or on flop -> two streets (turn, river)
        if n == 3:
            return 2
        if n == 4:
            return 1
        return 0

    def _outs_to_win_prob(self, outs: int, streets_left: int) -> float:
        # Approximate: rule of 2 and 4 (coarse but effective)
        if outs <= 0:
            return 0.0
        if streets_left >= 2:
            return min(0.95, outs * 4 / 100.0)
        return min(0.95, outs * 2 / 100.0)

    def _has_straight(self, ranks: List[int]) -> bool:
        if not ranks:
            return False
        # Handle wheel straight A-2-3-4-5 (A as 1)
        rset = set(ranks)
        if 14 in rset:
            rset.add(1)
        seq = sorted(rset)
        run = 1
        for i in range(1, len(seq)):
            if seq[i] == seq[i - 1] + 1:
                run += 1
                if run >= 5:
                    return True
            elif seq[i] != seq[i - 1]:
                run = 1
        return False

    def _has_oesd(self, ranks: List[int]) -> bool:
        # Consecutive 4-length window within unique ranks
        if 14 in ranks:
            ranks = sorted(set(ranks + [1]))
        else:
            ranks = sorted(set(ranks))
        for i in range(len(ranks) - 3):
            if ranks[i + 3] - ranks[i] == 3 and len(set(ranks[i:i+4])) == 4:
                return True
        return False

    def _has_gutshot(self, ranks: List[int]) -> bool:
        # Any 5-long span with 4 distinct ranks implying a single missing rank
        base = sorted(set(ranks))
        if 14 in base:
            base = sorted(set(base + [1]))
        for i in range(len(base) - 4):
            window = base[i:i+5]
            if window[-1] - window[0] == 5 and len(window) == 5:
                continue
            if window[-1] - window[0] <= 5 and len(window) >= 4:
                # Missing exactly one in span of 5
                if len(window) == 4 and window[-1] - window[0] <= 4:
                    return True
        return False

    def _parse(self, card: str) -> Tuple[str, str]:
        if len(card) == 2:
            return card[0], card[1]
        if len(card) == 3 and card[:2] == "10":
            return "10", card[2]
        return card[:-1], card[-1]

    def _rank_val(self, r: str) -> int:
        table = {"2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8,
                 "9": 9, "10": 10, "J": 11, "Q": 12, "K": 13, "A": 14}
        return table.get(r, 0)

    def _safe_fold(self, valid_actions: List[Dict[str, Any]]) -> Dict[str, Any]:
        for a in valid_actions:
            if a.get("action") == "fold":
                return a
        return {"action": "fold", "amount": 0}


if __name__ == "__main__":
    ai = CodexHoldem2AI()
    print("AI Info:", ai.get_info())
    # Minimal smoke tests
    game_state = {
        "valid_actions": [
            {"action": "fold"},
            {"action": "call", "amount": 20},
            {"action": "raise", "min_amount": 40, "max_amount": 200},
        ],
        "players": {
            "me": {"hole_cards": ["As", "Kh"], "chips": 1000, "current_bet": 10, "state": "active"}
        },
        "current_player": "me",
        "community_cards": [],
        "pot": 30,
        "current_bet": 20,
        "phase": "preflop",
        "dealer_index": 0,
    }
    print("Preflop decision:", ai.make_move(game_state))

    game_state_flop = dict(game_state)
    game_state_flop.update({
        "community_cards": ["Qs", "Jd", "10s"],
        "pot": 120,
        "current_bet": 40,
        "players": {
            "me": {"hole_cards": ["As", "Kh"], "chips": 920, "current_bet": 0, "state": "active"}
        },
    })
    print("Flop decision:", ai.make_move(game_state_flop))

